define('TipMessage', [
	'Utility',
	//'echartbase/EchartsBase',
	'BaseQueryComponent',
	'log/Log',
	'Event',
	'echartbase/Echart_cda',
	'utility/Layout',
	'utility/runtime',
	'underscore',
	'template/compile',
	'lib/saiku.data.convert',
	'Base.Panel',
	'echartbase/EchartsBase.Panel',
	'render/Base',
	'render/Renderer'
], function(
	Utility,
	Base,
	Log,
	Event,
	CDA,
	Layout,
	runtime,
	_,
	compiler,
	SaikuConvert,
	BasePanel,
	Echarts,
	Renderer
) {
	var instance = new BasePanel();

	if (!runtime.getClassify('ipsos')) {
		runtime.classifyAdd({
			classify: 'ipsos',
			classifyLabel: 'IPSOS自定义组件',
			priority: 5
		});
	}


	var component = Base.extend({
		/**
		 * @description: 根据指定数据配置的组件类里重写该方法
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2018-1-10下午16:32:10
		 */
		checkQm: function(rows, columns, measures) {
			this.model.hslice('COLUMNS', 0);
			this.model.hslice('ROWS', 0);
			this.model.mslice(1);
			return null;
		},

		/**
		 * 组件类型名称，一个唯一识别字符串
		 */
		type: 'CustomTipMessageComponent',

		/**
		 * 组件的显示名称
		 */
		name: '信息框',

		classify: '_custom',

		/**
		 * 组件的描述
		 */
		description: '信息提示框组件',

		/**
		 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
		 *
		 * @author: 美神猎手
		 * @time: 2017-3-31上午11:52:49
		 */
		queryExtend: function() {
			var checkQueryModel = this.model.isValidQueryModel.bind(
				this.model
			);
			var _render = this.render.bind(this);
			var myself = this;
			var rows = this.model.getAxesLevels('ROWS');
			var cube = this.model.get('query').cube;
			this.datasets = new Array();
			this.model.isValidQueryModel = function() {
				return checkQueryModel(true);
			};
			this.options = {
				title: {}
			};
			this.render = function(resize) {
				_render(resize);
				return this;
			};
			return this;
		},

		/**
		 * @description: 系统通知~~~~
		 * 				 组件的数据准备就绪
		 * @param _data: 转换后的cde格式数据，并将结果保存到组件UI渲染的配置对象里。
		 * @param raw: 原始数据
		 * @param summary:
		 * @param details:
		 * @author: 美神猎手
		 * @time: 2017-4-6下午4:03:31
		 */
		dataFormatter: function(_data, raw, summary, details) {
			var configs = this.model.getCustomizations();
			var list = new Array();
			if (!_data) {
				return this;
			}
			this.details = details;
			CDA.travelDeeply(details, null, function(route, node, parent) {
				if (Array.isArray(node.measures)) {
					node.measures.every(function(m) {
						list.push(m);
						return true;
					});
				}
			});
			//console.log(list);
			this.datasets = list;
			return this;
		},

		/**
		 *
		 * @return    {[type]}                 [description]
		 * @time      2018-11-29T15:39:06+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		clearContent: function() {
			this.$el.children().remove();
			return this;
		},

		/**
		 * @description: 重写系统代理方法~~~~
		 * 				组件即将请求数据前的回调
		 * @param msg:
		 * @returns {Boolean} 返回值为false，则提前取消这次数据请求
		 * @author: 美神猎手
		 * @time: 2017-5-10上午10:01:48
		 */
		beforeQuery: function(msg) {
			var preFetch = this.getCustomizeFunction('action', '_preFetch');
			return _.isFunction(preFetch) ? preFetch.call(this, msg) : msg;
		},


		draw: function() {
			var cellRender = this.getCustomizeFunction('action', '_numberUnitDef');
			var list = Utility.deepCopy(this.datasets);
			var myself = this;
			var status = _.find(list, function(o) {
				return o.caption == 'StatusMeasureCalculated';
			});
			var container;
			var title = this.options.title || {};
			try {
				this.$el.find('i.cmsg').popover('destroy');
				this.$el.children().remove();
			} catch (e) {
				//TODO
			}
			this.$el.css('cursor', 'pointer').parent().find('i.menu').addClass('inner-off');
			this.$el.append(compiler.plainCompile([{
				class: 'symbol_mode',
				style: 'display:flex;align-items:center;justify-content:center;',
				html: [{
					tagName: 'span',
					html: title.text || '',
					style: 'display:' + (!!title.show ? 'block' : 'none') + ';'
				}, {
					tagName: 'i',
					class: 'cmsg glyphicon glyphicon-info-sign'
				}]
			}]));
			container = this.$el.find('i.cmsg').css('font-size', this.options.size);
			if (status) {
				if (status.formatted == 'false') {
					container.css('color', this.options.normal);
				} else {
					container.css('color', this.options.warn);
				}
			} else {
				container.css('color', this.options.normal);
			}
			this.$el.find('i.cmsg').popover({
				container: 'body',
				html: true,
				content: function() {
					return compiler.listCompile(myself.datasets, function(item) {
						var value = item.value;
						if (_.isFunction(cellRender)) {
							item.formatted = cellRender.call(myself, item.value, item.formatted);
						}
						return [{
							tagName: 'label',
							style: 'display:table-cell;text-align:right;padding-right:5px;',
							html: item.caption
						}, {
							tagName: 'span',
							style: 'display:table-cell;text-align:left;padding-left:5px;',
							html: item.formatted
						}]
					}, {
						style: 'display:table;table-layout:fixed;border-spacing:5px;margin:0px;'
					}, {
						style: 'display:table-row;'
					}, function(item) {
						if (item.caption == 'TargetMeasure') {
							item.caption = '对标值';
						}
						if (item.caption == 'StatusMeasureCalculated') {
							return false;
						}
						return true;
					});
				},
				placement: 'auto',
				trigger: 'hover'
			});
			return this;
		}

	}, {
		thumbnail: 'icon glyphicon glyphicon-info-sign',

		_sort_order: 3,

		symbol: 'info.svg',

		/**
		 * 组件类的基本面板配置
		 */
		staticPanelOptions: _.extend(
			[], [{
				name: 'data',
				label: Utility.locale('panel', 'data'),
				active: true,
				datasets: [
					instance.datasource(),
					instance.line(),
					instance.measures(null, 'mul', false),
					instance.line(),
					instance.dimensionDate(),
					instance.line(),
					instance.filters(),
					instance.line()
				]
			}, {

				name: 'style',
				label: Utility.locale('panel', 'styles'),
				active: false,
				datasets: [
					Echarts.titleParimary('标题内容'),
					_.extend(Renderer.getRendererBaseAttrs('RadioBox'), {
						name: '_titleOn',
						value: false,
						tooltip: Utility.locale('panel', 'style panel', 'title', 'shown description'),
						label: '显示标题',
						execute: function(value, options, ui) {
							options.title.show = !!value;
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('ColorPicker'), {
						name: '_warnColor',
						tooltip: '预警色颜色',
						value: 'red',
						label: '预警色',
						execute: function(value, options, ui) {
							options.warn = value;
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('ColorPicker'), {
						name: '_normalColor',
						tooltip: '阈值范围内颜色',
						value: 'gray',
						label: '常规色',
						execute: function(value, options, ui) {
							options.normal = value;
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('SingleSelect'), {
						name: '_borderRadius',
						search: false,
						available: [{
							value: 12,
							label: '12px'
						}, {
							value: 14,
							label: '14px'
						}, {
							value: 16,
							label: '16px'
						}, {
							value: 18,
							label: '18px'
						}],
						value: 12,
						singleRequireSelected: true,
						label: '尺寸',
						tooltip: '信息图标尺寸大小',
						execute: function(value, options, ui) {
							value = Array.isArray(value) ? value[0] : value;
							options.size = value;
						}
					})
				]
			}, {
				name: 'action',
				active: false,
				label: Utility.locale('panel', 'actions'),
				datasets: [
					instance.label(Utility.locale('panel', 'action panel', 'custom blocks')),
					{
						name: '_numberUnitDef',
						disable: false,
						type: 'Function',
						tooltip: '数据量化单位过程定义',
						value: 'function numberUnitDef(value, formatted){\n\treturn formatted;\n}',
						label: '量化过程'
					},
					instance.preFetch(),
				]
			}]
		)
	});

	Base.register(component);

	return component;
});