define('IpsosFunnelBlueChart', [
 	 	'Utility',
 	 	'./IpsosFunnelGreenChart',
 	 	'template/compile',
 	 	'model/Component',
 	 	'log/Log',
 	 	'Event',
 	 	'underscore',
 	 	'utility/runtime',
 	 	'Base.Panel',
 	 	'numeral',
 	 	'promise',
 	 	'echartbase/EchartsBase.Panel',
 	 	'render/Base',
 	 	'render/Renderer'
], function(Utility, Base, compiler, Component, Log, Event, _, runtime, BasePanel, numeral, promise, EchartsPanel, Renderer) {

 	 	var instance = new BasePanel();

 	 	if (!runtime.getClassify('ipsos')) {
 	 	 	 	runtime.classifyAdd({
 	 	 	 	 	 	classify: 'ipsos',
 	 	 	 	 	 	classifyLabel: 'IPSOS自定义组件',
 	 	 	 	 	 	priority: 5
 	 	 	 	});
 	 	}

 	 	var Chart = Base.extend({
 	 	 	 	/**
 	 	 	 	 * 组件类型名称，一个唯一识别字符串
 	 	 	 	 */
 	 	 	 	type: 'IpsosFunnelBlueChart',

 	 	 	 	classify: '_custom',

 	 	 	 	/**
 	 	 	 	 * 组件的显示名称
 	 	 	 	 */
 	 	 	 	name: '蓝色漏斗图',

 	 	 	 	/**
 	 	 	 	 * 组件的描述，鼠标放置在组件图标上时显示的提示内容
 	 	 	 	 */
 	 	 	 	description: '自定义蓝色邀约漏斗图，Ipsos专用',



 	 	 	 	/**
 	 	 	 	 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
 	 	 	 	 *
 	 	 	 	 * @author: 美神猎手
 	 	 	 	 * @time: 2017-3-31上午11:52:49
 	 	 	 	 */
 	 	 	 	funnelExtend: function() {
 	 	 	 	 	 	//TODO
 	 	 	 	 	 	return this;
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * @return    {[type]}                        [description]
 	 	 	 	 * @time      2018-09-25T13:36:57+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	draw: function() {
 	 	 	 	 	 	var data = this.options.data || new Array();
 	 	 	 	 	 	var container = this.$el;
 	 	 	 	 	 	var size;
 	 	 	 	 	 	var zhlc = this.options.zhlc;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	this.$el.css({
 	 	 	 	 	 	 	 	'background-image': 'url(' + Utility.getWebAppName() + '/content/datafor/ui/extend%20components/images/funnel_blue.svg)',
 	 	 	 	 	 	 	 	'background-size': 'auto 100%',
 	 	 	 	 	 	 	 	'background-repeat': 'no-repeat',
 	 	 	 	 	 	 	 	'background-position-x': '50%'
 	 	 	 	 	 	});

 	 	 	 	 	 	container.children().remove();
 	 	 	 	 	 	size = this.options.data.length;
 	 	 	 	 	 	list = [{
 	 	 	 	 	 	 	 	formatted: data[0] ? data[0].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont')
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[1] ? data[1].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont', {
 	 	 	 	 	 	 	 	 	 	'width': '34%'
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[2] ? data[2].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont', {
 	 	 	 	 	 	 	 	 	 	'width': '37%'
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[3] ? data[3].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont', {
 	 	 	 	 	 	 	 	 	 	'width': '40%'
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[4] ? data[4].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('keyFont')
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[4] ? data[4].caption : '',
 	 	 	 	 	 	 	 	style: "color:white;font-size:14px"
 	 	 	 	 	 	}];
 	 	 	 	 	 	container.append(compiler.listCompile(list, function(item, i) {
 	 	 	 	 	 	 	 	if (item.right) {
 	 	 	 	 	 	 	 	 	 	return [{
 	 	 	 	 	 	 	 	 	 	 	 	style: item.style,
 	 	 	 	 	 	 	 	 	 	 	 	class: 'center-text-value',
 	 	 	 	 	 	 	 	 	 	 	 	html: item.formatted
 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	style: item.style,
 	 	 	 	 	 	 	 	 	 	 	 	class: 'right-label-name',
 	 	 	 	 	 	 	 	 	 	 	 	html: [{
 	 	 	 	 	 	 	 	 	 	 	 	 	 	tagName: 'i'
 	 	 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	tagName: 'span',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	html: item.right
 	 	 	 	 	 	 	 	 	 	 	 	}]
 	 	 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	return [{
 	 	 	 	 	 	 	 	 	 	 	 	style: item.style,
 	 	 	 	 	 	 	 	 	 	 	 	class: 'center-text-value',
 	 	 	 	 	 	 	 	 	 	 	 	html: item.formatted
 	 	 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	class: 'funnel-blue-text-ul',
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	style: 'min-height:{{sizey}};max-height:{{sizey}};flex-direction:{{h?"row":"column"}};'
 	 	 	 	 	 	}, function(item, i) {
 	 	 	 	 	 	 	 	var childy = ['13%', '3%', '17%', '2%', '16%', '3%', '14%', '3%', '14%', '14%', ];
 	 	 	 	 	 	 	 	item.sizey = childy[i];
 	 	 	 	 	 	 	 	item.element_index = i;
 	 	 	 	 	 	 	 	item.h = !!item.right;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}));
 	 	 	 	 	 	list = Utility.deepCopy(this.options.zhl.slice(0, this.options.zhl.length - 1));
 	 	 	 	 	 	container.append(compiler.listCompile(list, function(item, i) {
 	 	 	 	 	 	 	 	var margin = 3 + 4.5 * i;
 	 	 	 	 	 	 	 	var ss = zhlc[i] || {
 	 	 	 	 	 	 	 	 	 	value: 0,
 	 	 	 	 	 	 	 	 	 	formatted: 0
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	var color = myself.options.dataFont.color;
 	 	 	 	 	 	 	 	var _color = ss.value < 0 ? 'red' : 'green';
 	 	 	 	 	 	 	 	var symbol = '';
 	 	 	 	 	 	 	 	if (ss.value > 0) {
 	 	 	 	 	 	 	 	 	 	symbol = '+';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return [{
 	 	 	 	 	 	 	 	 	 	html: [{
 	 	 	 	 	 	 	 	 	 	 	 	html: item.formatted,
 	 	 	 	 	 	 	 	 	 	 	 	style: 'position:relative;top:5px;color:' + color
 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	style: 'color:' + _color,
 	 	 	 	 	 	 	 	 	 	 	 	html: symbol + ss.formatted
 	 	 	 	 	 	 	 	 	 	}]
 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	class: 'changed-label-text',
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont') + ';top:{{y}};justify-content:center;position:absolute;left:{{x}}'
 	 	 	 	 	 	}, function(item, i) {
 	 	 	 	 	 	 	 	var x = ['9%', '13%', '17%'];
 	 	 	 	 	 	 	 	var y = ['12%', '31%', '49%'];
 	 	 	 	 	 	 	 	item.x = x[i];
 	 	 	 	 	 	 	 	item.y = y[i];
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}));
 	 	 	 	 	 	return this;
 	 	 	 	},




 	 	 	 	/**
 	 	 	 	 * 系统消息，修改了页面的默认颜色
 	 	 	 	 * @param                          {Array} colors [description]
 	 	 	 	 * @return                         {[type]}        [description]
 	 	 	 	 * @author:美神猎手
 	 	 	 	 * @email:meishenlieshou@gmail.com
 	 	 	 	 */
 	 	 	 	colorsUpdated: function(colors) {
 	 	 	 	 	 	//TODO
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	}, {
 	 	 	 	/**
 	 	 	 	 * 组件图标，请指标一个可用的字体图标
 	 	 	 	 * 默认
 	 	 	 	 * 1. Bootstrap字体图标
 	 	 	 	 * 2. Font-awesome字体图标
 	 	 	 	 * 已经可用
 	 	 	 	 * @type {String}
 	 	 	 	 */
 	 	 	 	thumbnail: 'icon iconfont icon-datafor-funnel',

 	 	 	 	menus: [{
 	 	 	 	 	 	value: 'image',
 	 	 	 	 	 	label: Utility.locale('components', 'universal', 'save as image'),
 	 	 	 	 	 	enable: false
 	 	 	 	}, {
 	 	 	 	 	 	value: 'drillReset',
 	 	 	 	 	 	label: Utility.locale('components', 'universal', 'component reset drill'),
 	 	 	 	 	 	enable: false,
 	 	 	 	 	 	icon: 'fa fa-undo drill',
 	 	 	 	 	 	dy: 5,
 	 	 	 	 	 	top: true
 	 	 	 	}],


 	 	 	 	/**
 	 	 	 	 * 组件位于组件列表中的顺序，值越大越靠后
 	 	 	 	 * @type {Number}
 	 	 	 	 */
 	 	 	 	_sort_order: 24,

 	 	 	 	/**
 	 	 	 	 * 无数据时，组件渲染的内容，请指定了一个可用的svg文件，
 	 	 	 	 * 该文件放置在components_symbol目录下
 	 	 	 	 * @type {String}
 	 	 	 	 */
 	 	 	 	symbol: 'indicate.svg',

 	 	 	 	/**
 	 	 	 	 * 组件类的基本面板配置
 	 	 	 	 */
 	 	 	 	staticPanelOptions: _.extend([], [{
 	 	 	 	 	 	name: 'data',
 	 	 	 	 	 	label: Utility.locale('panel', 'data'),
 	 	 	 	 	 	active: true,
 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	instance.datasource(null, ['measures', 'date_dim', 'filter']),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.measures(null, 'mul', false),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.dimensionDate(),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.filters(),
 	 	 	 	 	 	 	 	instance.line()
 	 	 	 	 	 	]
 	 	 	 	}, {
 	 	 	 	 	 	name: 'style',
 	 	 	 	 	 	label: Utility.locale('panel', 'styles'),
 	 	 	 	 	 	active: false,
 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	instance.background(Utility.locale('panel', 'background color')),
 	 	 	 	 	 	 	 	instance.border(Utility.locale('panel', 'border')),
 	 	 	 	 	 	 	 	instance.shadow(),
 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	name: '_mainfont',
 	 	 	 	 	 	 	 	 	 	label: '指标字体',
 	 	 	 	 	 	 	 	 	 	value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	sizes: [12, 14, 16, 18, 20],
 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	//color: null,
 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	tooltip: '漏斗图指标值的字体',
 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	var normal = this.options.dataFont = {};
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-size'] = Number(value[0]) + 'px';
 	 	 	 	 	 	 	 	 	 	 	 	normal['color'] = value[1];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-family'] = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-weight'] = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-style'] = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	name: '_lastfont',
 	 	 	 	 	 	 	 	 	 	label: '关键指标字体',
 	 	 	 	 	 	 	 	 	 	value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	sizes: [12, 14, 16, 18, 20, 24, 28],
 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	//color: null,
 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	tooltip: '漏斗图最后一个指标的字体样式',
 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	var normal = this.options.keyFont = {};
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-size'] = Number(value[0]) + 'px';
 	 	 	 	 	 	 	 	 	 	 	 	normal['color'] = value[1];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-family'] = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-weight'] = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-style'] = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	]
 	 	 	 	}, {
 	 	 	 	 	 	name: 'action',
 	 	 	 	 	 	label: Utility.locale('panel', 'actions'),
 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	//这一块需要抽象，不能让开发者随意修改
 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'refresh')),
 	 	 	 	 	 	 	 	instance.refresh(),
 	 	 	 	 	 	 	 	instance.period(),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'custom blocks')),
 	 	 	 	 	 	 	 	instance.preExecution(),
 	 	 	 	 	 	 	 	instance.preFetch(),
 	 	 	 	 	 	 	 	instance.postFetch(),
 	 	 	 	 	 	 	 	instance.postExecution()
 	 	 	 	 	 	]
 	 	 	 	}])
 	 	});

 	 	Base.register(Chart);

 	 	return Chart;
});