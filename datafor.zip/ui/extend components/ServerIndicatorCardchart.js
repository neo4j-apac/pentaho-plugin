define('ServerIndicatorCardchart', [
	'Utility',
	'BaseQueryComponent',
	'template/compile',
	'model/Component',
	'log/Log',
	'Event',
	'underscore',
	'utility/runtime',
	'Base.Panel',
	'numeral',
	'promise',
	'echartbase/EchartsBase.Panel',
	'render/Base',
	'render/Renderer'
], function(Utility, Base, compiler, Component, Log, Event, _, runtime, BasePanel, numeral, promise, EchartsPanel, Renderer) {

	var instance = new BasePanel();

	if (!runtime.getClassify('ipsos')) {
		runtime.classifyAdd({
			classify: 'ipsos',
			classifyLabel: 'IPSOS自定义组件',
			priority: 5
		});
	}
	var formatsArray = Utility.getNumericFormats(function(o) {
		o.label = o.text;
		o.value = o.id;
		delete o.id;
		delete o.text;
		return true;
	});
	var Promise = promise.Promise;
	formatsArray.unshift({
		value: 'default',
		label: Utility.locale('others', 'default')
	});
	var percentArray = [{
		value: '#%',
		label: '#%'
	}, {
		value: '#.0%',
		label: '#.0%'
	}, {
		value: '#.00%',
		label: '#.00%'
	}, {
		value: '#.000%',
		label: '#.000%'
	}, {
		value: '#,###%',
		label: '#,###%'
	}, {
		value: '#,###.0%',
		label: '#,###.0%'
	}, {
		value: '#,###.00%',
		label: '#,###.00%',
		selected: true
	}, {
		value: '#,###.000%',
		label: '#,###.000%'
	}];

	var localeLabels = {
		'year': Utility.locale('components', 'system default', 'indicator', 'year tongbi'),
		'quarter': Utility.locale('components', 'system default', 'indicator', 'quarter tongbi'),
		'month': Utility.locale('components', 'system default', 'indicator', 'month tongbi'),
		'week': Utility.locale('components', 'system default', 'indicator', 'week tongbi')
	};



	var _baseOptions = {
		value: 0,
		formatted: '-',
		formattedOrigin: '-',
		label: 'Untitle',
		textStyle: {
			color: '#888',
			fontSize: 24,
			fontFamily: ''
		},
		tongbi: {
			show: true,
			value: null,
			formatted: '-',
			formattedOrigin: '-',
			positive: true,
			percent: '-',
			formatString: '',
			style: {
				fontSize: 18,
				fontFamily: ''
			}
		},
		huanbi: {
			show: true,
			value: null,
			positive: true,
			formatted: '-',
			formattedOrigin: '-',
			percent: '-',
			formatString: '',
			style: {
				fontSize: 18,
				fontFamily: ''
			}
		},
		title: {
			show: true,
			textStyle: {},
			text: 'Untitle'
		},
		positiveColor: 'red',
		negativeColor: 'green'
	};

	var Chart = Base.extend({
		/**
		 * 组件类型名称，一个唯一识别字符串
		 */
		type: 'ServerIndicatorCardchart',


		classify: '_custom',

		/**
		 * 组件的显示名称
		 */
		name: '同环比卡',

		/**
		 * 组件的描述，鼠标放置在组件图标上时显示的提示内容
		 */
		description: '同环比计算指标卡',




		/**
		 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
		 *
		 * @author: 美神猎手
		 * @time: 2017-3-31上午11:52:49
		 */
		queryExtend: function() {
			var checkQueryModel = this.model.isValidQueryModel.bind(this.model);
			var myself = this;
			this.model.isValidQueryModel = function() {
				return checkQueryModel(true);
			};
			/**
			 * 保存指标卡相关的数据
			 * @type {Object}
			 */
			this.options = Utility.deepCopy(_baseOptions);
			return this;
		},

		/**
		 * {
		 *      value: '',
		 *      formatted: '',
		 *      label: '',
		 *      tongbi: {
		 * 			value: '',
		 * 			formatted: ''
		 *      },
		 *      huanbi: {
		 * 			value: '',
		 * 			formatted: ''
		 *      }
		 * }
		 * @type {[type]}
		 */
		options: null,


		/**
		 * @description: 根据指定数据配置的组件类里重写该方法
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2018-1-10上午10:41:03
		 */
		checkQm: function(rows, columns, measures) {
			this.model.hslice('COLUMNS', 0);
			this.model.hslice('ROWS', 0);
			this.model.mslice(1);
			return null;
		},

		events: {
			'click': 'clickEvent'
		},

		/**
		 * 指标卡单击事件
		 * @param     {[type]}                 event [description]
		 * @return    {[type]}                       [description]
		 * @time      2018-12-11T10:53:17+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		clickEvent: function(event) {
			var func = this.getCustomizeFunction('action', '_viewclick');
			var ret = true;
			if (_.isFunction(func)) {
				ret = func.call(this, event);
			}
			if (!ret) {
				event.stopPropagation();
			}
			return this;
		},

		/**
		 * 重写系统接口，当数据响应成功之后，系统将自动调用该方法
		 * 格式化响应数据，封装成Echarts组件能识别的数据格式
		 * @param     {Object}                 _data   [description]
		 * @param     {Object}                 raw     null
		 * @param     {Object}                 summary null
		 * @param     {Object}                 details null
		 * @return    {[type]}                         [description]
		 * @time      2018-09-14T17:07:42+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		dataFormatter: function(_data, raw, summary, details) {
			var customs = this.model.getCustomizations();
			var node;
			var baseValue;
			var ms = this.details.children[0].details.measures;
			this.options = Utility.deepCopy(_baseOptions);
			if (Array.isArray(ms)) {
				node = ms[0];
				this.options.value = node.value;
				this.options.formatted = node.formatted;
				this.options.formattedOrigin = node.formatted;
				this.options.label = node.caption;
				baseValue = node.value;
				node = ms[1];
				if (node) {
					this.options.tongbi.value = node.value;
					this.options.tongbi.formatted = node.formatted;
					this.options.tongbi.formattedOrigin = node.formatted;
					this.options.tongbi.positive = (node.value >= 0);
					this.options.tongbi.label = node.caption;
				}
				node = ms[2];
				if (node) {
					this.options.huanbi.value = node.value;
					this.options.huanbi.formatted = node.formatted;
					this.options.huanbi.formattedOrigin = node.formatted;
					this.options.huanbi.positive = (node.value >= 0);
					this.options.huanbi.label = node.caption;
				}
			}
			return this;
		},

		clearContent: function() {
			this.$el.children().remove();
			return this;
		},


		/**
		 * @return    {[type]}                        [description]
		 * @time      2018-09-25T13:36:57+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		draw: function() {
			var tbLabel;
			var icon; //箭头图标
			var layout = this.options.layout || 'default';
			var icon_color; //箭头颜色
			var container = this.$el;
			this.$el.css('overflow', 'visible');
			var tongbi = this.options.tongbi || {};
			var huanbi = this.options.huanbi || {};
			var hbLabel = Utility.locale('components', 'system default', 'indicator', 'huanbi');
			var tb = 'N/A';
			var hb = 'N/A';
			var config;
			if (Utility.isNumeric(tongbi.value)) {
				tb = tongbi.formatted;
			}
			if (Utility.isNumeric(huanbi.value)) {
				hb = huanbi.formatted;
			}
			container.css('padding', 5).children().remove();
			if (layout == 'vertical') {
				var rowStyle = 'width:100%;white-space:nowrap;overflow:visible;';
				container.append(compiler.plainCompile([{
					class: 'header',
					html: this.options.title.text,
					style: 'width:100%;display:' + (this.options.title.show ? 'block' : 'none') + ';'
				}, {
					class: 'indicator-main',
					html: this.options.formatted == null ? 'N/A' : this.options.formatted,
					style: rowStyle
				}, {
					style: rowStyle + ';display:table;width:100%;table-layout:fixed;',
					html: [{
						class: 'indicator-hb',
						html: [{
							tagName: 'span',
							class: 'bijiao',
							style: 'padding-right:5px;color:#666',
							html: huanbi.label || '环比'
						}, {
							class: 'jsc icon',
							tagName: 'i'
						}, {
							class: 'jsc',
							tagName: 'span',
							html: hb,
						}],
						//style: 'display:table-cell;'
						style: 'display:' + (!!huanbi.show ? 'table-cell;' : 'none;')
					}, {
						class: 'indicator-tb',
						html: [{
							tagName: 'span',
							class: 'bijiao',
							style: 'padding-right:5px;color:#666',
							html: tongbi.label || '同比'
						}, {
							class: 'jsc icon',
							tagName: 'i'
						}, {
							class: 'jsc',
							tagName: 'span',
							html: tb
						}],
						style: 'display:' + (!!tongbi.show ? 'table-cell;' : 'none;')
					}]
				}]));
			} else if (layout == 'horizontal') {
				container.append(compiler.plainCompile([{
					class: 'header',
					html: this.options.title.text,
					style: 'width:100%;display:' + (this.options.title.show ? 'block' : 'none') + ';'
				}, {
					style: 'display:table;width:100%;table-layout:fixed;',
					html: [{
						class: 'indicator-main',
						html: this.options.formatted == null ? 'N/A' : this.options.formatted,
						style: 'white-space:nowrap;overflow:visible;display:table-cell;vertical-align:middle;'
					}, {
						style: 'white-space:nowrap;overflow:visible;display:table-cell;',
						html: [{
							class: 'indicator-hb',
							html: [{
								tagName: 'span',
								class: 'bijiao',
								style: 'padding-right:5px;color:#666',
								html: huanbi.label || '环比'
							}, {
								class: 'jsc icon',
								tagName: 'i'
							}, {
								class: 'jsc',
								tagName: 'span',
								html: hb,
							}],
							//		style: 'display:block'
							style: 'display:' + (!!huanbi.show ? 'block;' : 'none;')
						}, {
							class: 'indicator-tb',
							html: [{
								tagName: 'span',
								class: 'bijiao',
								style: 'padding-right:5px;color:#666',
								html: tongbi.label || '同比'
							}, {
								class: 'jsc icon',
								tagName: 'i'
							}, {
								class: 'jsc',
								tagName: 'span',
								html: tb
							}],
							style: 'display:' + (!!tongbi.show ? 'block;' : 'none;')
						}]
					}]
				}]));
			} else {
				var rowStyle = 'width:100%;white-space:nowrap;overflow:visible;';
				container.append(compiler.plainCompile([{
					class: 'header',
					html: this.options.title.text,
					style: 'width:100%;display:' + (this.options.title.show ? 'block' : 'none') + ';'
				}, {
					class: 'indicator-main',
					html: this.options.formatted == null ? 'N/A' : this.options.formatted,
					style: rowStyle
				}, {
					class: 'indicator-hb',
					html: [{
						tagName: 'span',
						class: 'bijiao',
						style: 'padding-right:5px;color:#666',
						html: huanbi.label || '环比'
					}, {
						class: 'jsc icon',
						tagName: 'i'
					}, {
						class: 'jsc',
						tagName: 'span',
						html: hb,
					}],
					//style: 'display:block'
					style: 'display:' + (!!huanbi.show ? 'block;' : 'none;')
				}, {
					class: 'indicator-tb',
					html: [{
						tagName: 'span',
						class: 'bijiao',
						style: 'padding-right:5px;color:#666',
						html: tongbi.label || '同比'
					}, {
						class: 'jsc icon',
						tagName: 'i'
					}, {
						class: 'jsc',
						tagName: 'span',
						html: tb
					}],
					style: 'display:' + (!!tongbi.show ? 'block;' : 'none;')
				}]));
				!!huanbi.show && container.find('.indicator-hb').css(rowStyle);
				!!tongbi.show && container.find('.indicator-tb').css(rowStyle);
			}
			container.find('.indicator-main').css(this.options.textStyle);
			if (this.options.title.show) {
				config = this.options.title.textStyle;
				config.textAlign = this.options.title.left;
				container.find('.header').css(config);
			}
			if (!!huanbi.show) {
				if (this.options.huanbi.positive) {
					icon = 'glyphicon glyphicon-triangle-top';
					icon_color = this.options.increaseColor;
				} else {
					icon = 'glyphicon glyphicon-triangle-bottom';
					icon_color = this.options.decreaseColor;
				}
				container.find('.indicator-hb').css('color', icon_color);
				container.find('.indicator-hb').css('text-align', huanbi.textStyle.textAlign);
				container.find('.indicator-hb .jsc').css(huanbi.textStyle);
				container.find('.indicator-hb .bijiao').css('font-size', huanbi.textStyle.fontSize);
				container.find('.indicator-hb .jsc.icon').addClass(icon).css({
					'font-family': 'Glyphicons Halflings',
					'font-size': 12,
					'transform': 'scale(0.7)'
				});
			}
			if (!!tongbi.show) {
				if (this.options.tongbi.positive) {
					icon = 'glyphicon glyphicon-triangle-top';
					icon_color = this.options.increaseColor;
				} else {
					icon = 'glyphicon glyphicon-triangle-bottom';
					icon_color = this.options.decreaseColor;
				}
				container.find('.indicator-tb').css('color', icon_color);
				container.find('.indicator-tb').css('text-align', tongbi.textStyle.textAlign);
				container.find('.indicator-tb .jsc').css(tongbi.textStyle);
				container.find('.indicator-tb .bijiao').css('font-size', tongbi.textStyle.fontSize);
				container.find('.indicator-tb .jsc.icon').addClass(icon).css({
					'font-family': 'Glyphicons Halflings',
					'font-size': 12,
					'transform': 'scale(0.7)'
				});
			}
			return this;
		},


		/**
		 * 系统消息，修改了页面的默认颜色
		 * @param                          {Array} colors [description]
		 * @return                         {[type]}        [description]
		 * @author:美神猎手
		 * @email:meishenlieshou@gmail.com
		 */
		colorsUpdated: function(colors) {
			//TODO
			return this;
		},

	}, {
		/**
		 * 组件图标，请指标一个可用的字体图标
		 * 默认
		 * 1. Bootstrap字体图标
		 * 2. Font-awesome字体图标
		 * 已经可用
		 * @type {String}
		 */
		thumbnail: 'icon iconfont icon-datafor-zhibiaoka',

		menus: [{
			value: 'image',
			label: Utility.locale(
				'components',
				'universal',
				'save as image'
			),
			enable: true
		}, {
			value: 'drillReset',
			label: Utility.locale(
				'components',
				'universal',
				'component reset drill'
			),
			enable: true,
			icon: 'fa fa-undo drill',
			dy: 5,
			top: true
		}],


		/**
		 * 组件位于组件列表中的顺序，值越大越靠后
		 * @type {Number}
		 */
		_sort_order: 21,

		/**
		 * 无数据时，组件渲染的内容，请指定了一个可用的svg文件，
		 * 该文件放置在components_symbol目录下
		 * @type {String}
		 */
		symbol: 'indicate.svg',

		/**
		 * 组件类的基本面板配置
		 */
		staticPanelOptions: _.extend([], [{
				name: 'data',
				label: Utility.locale('panel', 'data'),
				active: true,
				datasets: [
					instance.datasource(),
					instance.line(),
					instance.measures(null, 'single', false),
					instance.line(),
					instance.filters(),
				]
			},
			{
				name: 'style',
				label: Utility.locale('panel', 'styles'),
				active: false,
				datasets: [
					/*整体配置*/
					instance.label(Utility.locale('panel', 'frame style')),
					instance.background(Utility.locale('panel', 'background color')),
					instance.border(Utility.locale('panel', 'border')),
					instance.shadow(),
					instance.line(),

					/*标题配置*/
					instance.label(Utility.locale('panel', 'title style')),
					EchartsPanel.titleSwitch(Utility.locale('panel', 'shown')),
					EchartsPanel.titleParimary(Utility.locale('panel', 'content')),
					EchartsPanel.titlePrimaryAlign(null, 'left'),
					EchartsPanel.titlePrimaryStyle(null, 14),
					instance.line(),

					/*内容设置*/
					instance.label(Utility.locale('components', 'system default', 'indicator', 'main value style')),
					_.extend(Renderer.getRendererBaseAttrs('Font'), {
						name: 'mainFont',
						label: Utility.locale('components', 'system default', 'indicator', 'main value font'),
						value: [28, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
						sizes: [12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 42, 48, 60],
						bold: true,
						italic: true,
						tooltip: Utility.locale('components', 'system default', 'indicator', 'main value font description'),
						execute: function(value, options, ui) {
							options.textStyle = _.extend(options.textStyle || {}, {
								color: value[1],
								fontSize: Number(value[0]),
								fontFamily: value[2],
								fontWeight: value[3] ? 'bold' : 'normal',
								fontStyle: value[4] ? 'italic' : 'normal'
							});
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('QuickPicker'), {
						name: '_mainAlign',
						value: 'left',
						tooltip: Utility.locale('components', 'system default', 'indicator', 'value align description'),
						label: Utility.locale('components', 'system default', 'indicator', 'value align'),
						execute: function(value, options, $el) {
							options.textStyle.textAlign = value;
						}
					}),
					// _.extend(Renderer.getRendererBaseAttrs('SingleSelect'), {
					// 	name: '_mainFormat',
					// 	search: false,
					// 	available: formatsArray,
					// 	value: ['default'],
					// 	singleRequireSelected: true,
					// 	label: Utility.locale('components', 'system default', 'indicator', 'main value format'),
					// 	tooltip: Utility.locale('components', 'system default', 'indicator', 'main value format description'),
					// 	execute: function(value, options, ui) {
					// 		var val = Array.isArray(value) ? value[0] : value;
					// 		if (val == 'default') {
					// 			options.formatted = options.formattedOrigin;
					// 		} else {
					// 			options.formatted = numeral(options.value).format(val);
					// 		}
					// 	}
					// }),

					instance.line(),
					instance.label(Utility.locale('components', 'system default', 'indicator', 'huanbi value style')),
					_.extend(Renderer.getRendererBaseAttrs('Font'), {
						name: 'huanbiFont',
						label: Utility.locale('components', 'system default', 'indicator', 'huanbi font'),
						value: [14, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
						sizes: [12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 42, 48],
						bold: true,
						color: null,
						italic: true,
						tooltip: Utility.locale('components', 'system default', 'indicator', 'huanbi font description'),
						execute: function(value, options, ui) {
							options.huanbi.textStyle = _.extend(options.huanbi.textStyle || {}, {
								fontSize: Number(value[0]),
								fontFamily: value[2],
								fontWeight: value[3] ? 'bold' : 'normal',
								fontStyle: value[4] ? 'italic' : 'normal'
							});
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('QuickPicker'), {
						name: '_huanbiAlign',
						value: 'left',
						tooltip: Utility.locale('components', 'system default', 'indicator', 'value align description'),
						label: Utility.locale('components', 'system default', 'indicator', 'value align'),
						execute: function(value, options, $el) {
							options.huanbi.textStyle.textAlign = value;
						}
					}),
					// _.extend(Renderer.getRendererBaseAttrs('SingleSelect'), {
					// 	name: '_huanbiFormat',
					// 	search: false,
					// 	available: percentArray,
					// 	value: ['#,###.00%'],
					// 	singleRequireSelected: true,
					// 	label: Utility.locale('components', 'system default', 'indicator', 'huanbi value format'),
					// 	tooltip: Utility.locale('components', 'system default', 'indicator', 'huanbi value format description'),
					// 	execute: function(value, options, ui) {
					// 		var val = Array.isArray(value) ? value[0] : value;
					// 		var huanbi = options.huanbi;
					// 		if (val == 'default') {
					// 			huanbi.percent = huanbi.formattedOrigin + '%';
					// 		} else {
					// 			if (Utility.isNumeric(huanbi.formattedOrigin)) {
					// 				huanbi.percent = numeral(huanbi.formattedOrigin).format(val);
					// 			} else {
					// 				huanbi.percent = huanbi.formattedOrigin;
					// 			}
					// 		}
					// 	}
					// }),
					instance.line(),
					instance.label(Utility.locale('components', 'system default', 'indicator', 'tongbi value style')),
					_.extend(Renderer.getRendererBaseAttrs('Font'), {
						name: 'tongbiFont',
						label: Utility.locale('components', 'system default', 'indicator', 'tongbi font'),
						value: [14, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
						sizes: [12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 42, 48],
						bold: true,
						italic: true,
						color: null,
						tooltip: Utility.locale('components', 'system default', 'indicator', 'tongbi font description'),
						execute: function(value, options, ui) {
							options.tongbi.textStyle = _.extend(options.tongbi.textStyle || {}, {
								fontSize: Number(value[0]),
								fontFamily: value[2],
								fontWeight: value[3] ? 'bold' : 'normal',
								fontStyle: value[4] ? 'italic' : 'normal'
							});
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('QuickPicker'), {
						name: '_tongbiAlign',
						value: 'left',
						tooltip: Utility.locale('components', 'system default', 'indicator', 'value align description'),
						label: Utility.locale('components', 'system default', 'indicator', 'value align'),
						execute: function(value, options, $el) {
							options.tongbi.textStyle.textAlign = value;
						}
					}),
					// _.extend(Renderer.getRendererBaseAttrs('SingleSelect'), {
					// 	name: '_tongbiFormat',
					// 	search: false,
					// 	available: percentArray,
					// 	value: ['#,###.00%'],
					// 	singleRequireSelected: true,
					// 	label: Utility.locale('components', 'system default', 'indicator', 'tongbi value format'),
					// 	tooltip: Utility.locale('components', 'system default', 'indicator', 'tongbi value format description'),
					// 	execute: function(value, options, ui) {
					// 		var val = Array.isArray(value) ? value[0] : value;
					// 		var tongbi = options.tongbi;
					// 		if (val == 'default') {
					// 			tongbi.percent = tongbi.formattedOrigin + '%';
					// 		} else {
					// 			if (Utility.isNumeric(tongbi.formattedOrigin)) {
					// 				tongbi.percent = numeral(tongbi.formattedOrigin).format(val);
					// 			} else {
					// 				tongbi.percent = tongbi.formattedOrigin;
					// 			}
					// 		}
					// 	}
					// }),
					instance.line(),
					instance.label(Utility.locale('components', 'system default', 'indicator', 'comparison color')),
					_.extend(Renderer.getRendererBaseAttrs('ColorPicker'), {
						name: '_increaseColor',
						tooltip: Utility.locale('components', 'system default', 'indicator', 'increase color description'),
						value: 'red',
						label: Utility.locale('components', 'system default', 'indicator', 'increase color'),
						execute: function(value, options, ui) {
							if (!options) return;
							options.increaseColor = value;
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('ColorPicker'), {
						name: '_decreaseColor',
						tooltip: Utility.locale('components', 'system default', 'indicator', 'decrease color description'),
						value: 'green',
						label: Utility.locale('components', 'system default', 'indicator', 'decrease color'),
						execute: function(value, options, ui) {
							if (!options) return;
							options.decreaseColor = value;
						}
					}),
					instance.line(),
					instance.label(Utility.locale('components', 'system default', 'indicator', 'structure layout')),
					_.extend(Renderer.getRendererBaseAttrs('SingleSelect'), {
						name: '_layout',
						search: false,
						available: [{
							value: 'default',
							label: Utility.locale('components', 'system default', 'indicator', 'layout type list', 'default') //'默认'
						}, {
							value: 'horizontal',
							label: Utility.locale('components', 'system default', 'indicator', 'layout type list', 'right vertical') //''
						}, {
							value: 'vertical',
							label: Utility.locale('components', 'system default', 'indicator', 'layout type list', 'bottom parallel') //''
						}],
						value: ['default'],
						singleRequireSelected: true,
						label: Utility.locale('components', 'system default', 'indicator', 'layout type'),
						tooltip: Utility.locale('components', 'system default', 'indicator', 'layout type description'),
						execute: function(value, options, ui) {
							var val = Array.isArray(value) ? value[0] : value;
							options.layout = val;
						}
					})
				]
			},
			{
				name: 'action',
				label: Utility.locale('panel', 'actions'),
				datasets: [
					//这一块需要抽象，不能让开发者随意修改
					instance.label(Utility.locale('panel', 'action panel', 'refresh')),
					instance.refresh(),
					instance.period(),
					instance.line(),
					instance.label(Utility.locale(
						'panel',
						'action panel',
						'custom blocks'
					)),
					{
						name: '_viewclick',
						disable: false,
						type: 'Function',
						tooltip: '点击指标卡组件的自定义回调过程，返回false将阻止事件冒泡',
						value: 'function click(event){\n\treturn true;\n}',
						label: 'Click事件'
					},
					instance.preExecution(),
					instance.preFetch(),
					instance.postFetch(),
					instance.postExecution()
				]
			}
		])
	});

	Base.register(Chart);

	return Chart;
});