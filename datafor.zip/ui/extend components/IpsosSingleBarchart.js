define('IpsosSingleBarchart', [
 	 	'Utility',
 	 	'echartbase/EchartsBase',
 	 	'log/Log',
 	 	'Event',
 	 	'underscore',
 	 	'utility/runtime',
 	 	'Base.Panel',
 	 	'echartbase/EchartsBase.Panel',
 	 	'render/Base',
 	 	'render/Renderer'
], function(Utility, Base, Log, Event, _, runtime, BasePanel, Echarts, Renderer) {
 	 	var instance = new BasePanel();

 	 	/**
 	 	 *
 	 	 */
 	 	var basicOptions = $.extend(true, {}, Base.getBaseOption(), {
 	 	 	 	legend: {
 	 	 	 	 	 	show: false
 	 	 	 	},
 	 	 	 	tooltip: {
 	 	 	 	 	 	axisPointer: {
 	 	 	 	 	 	 	 	type: 'shadow'
 	 	 	 	 	 	},
 	 	 	 	 	 	trigger: 'item'
 	 	 	 	},
 	 	 	 	grid: {
 	 	 	 	 	 	left: 0,
 	 	 	 	 	 	right: 10,
 	 	 	 	 	 	top: 0,
 	 	 	 	 	 	bottom: 0
 	 	 	 	},
 	 	 	 	yAxis: {
 	 	 	 	 	 	type: 'category',
 	 	 	 	 	 	data: [''],
 	 	 	 	 	 	show: false
 	 	 	 	},
 	 	 	 	xAxis: {
 	 	 	 	 	 	show: false,
 	 	 	 	 	 	//data: null,
 	 	 	 	 	 	type: 'value'
 	 	 	 	},
 	 	 	 	series: []
 	 	});

 	 	var Barchart = Base.extend({
 	 	 	 	/**
 	 	 	 	 * 组件类型名称，一个唯一识别字符串
 	 	 	 	 */
 	 	 	 	type: 'IpsosSingleBarchart',

 	 	 	 	/**
 	 	 	 	 * 组件的显示名称
 	 	 	 	 */
 	 	 	 	name: '占比条形图',

 	 	 	 	classify: '_custom',

 	 	 	 	/**
 	 	 	 	 * 组件的描述
 	 	 	 	 */
 	 	 	 	description: '占比条形图，Ipsos专用',

 	 	 	 	/**
 	 	 	 	 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
 	 	 	 	 *
 	 	 	 	 * @author: 美神猎手
 	 	 	 	 * @time: 2017-3-31上午11:52:49
 	 	 	 	 */
 	 	 	 	echartsInit: function() {
 	 	 	 	 	 	var checkQueryModel = this.model.isValidQueryModel.bind(
 	 	 	 	 	 	 	 	this.model
 	 	 	 	 	 	);
 	 	 	 	 	 	this.model.isValidQueryModel = function() {
 	 	 	 	 	 	 	 	return checkQueryModel(true);
 	 	 	 	 	 	};
 	 	 	 	 	 	_.isFunction(this.barExtend) && this.barExtend();
 	 	 	 	 	 	this.options = Utility.deepCopy(basicOptions);
 	 	 	 	 	 	this.options.tooltip.formatter = this.tipFormat.bind(this);
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * [description]
 	 	 	 	 * @param     {[type]}                 params   [description]
 	 	 	 	 * @param     {[type]}                 ticket   [description]
 	 	 	 	 * @param     {Function}               callback [description]
 	 	 	 	 * @return    {[type]}                          [description]
 	 	 	 	 * @time      2019-05-18T12:28:13+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	tipFormat: function(params, ticket, callback) {
 	 	 	 	 	 	var customs = this.model.getCustomizations();
 	 	 	 	 	 	var stack = true;
 	 	 	 	 	 	var dataLevel = params[0] && params[0].data && params[0].data.levels ? params[0].data.levels : [];
 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	var measures = this.model.getMeasures();
 	 	 	 	 	 	var list = ['<table class="tooltiper">'];
 	 	 	 	 	 	var item = Array.isArray(params) ? params[0] : params;
 	 	 	 	 	 	list.push(
 	 	 	 	 	 	 	 	'<tr><td>' +
 	 	 	 	 	 	 	 	item.marker +
 	 	 	 	 	 	 	 	item.seriesName +
 	 	 	 	 	 	 	 	'</td><td>' +
 	 	 	 	 	 	 	 	item.data.formatted +
 	 	 	 	 	 	 	 	'</td></tr>'
 	 	 	 	 	 	);
 	 	 	 	 	 	list.push('</table>');
 	 	 	 	 	 	return list.join('');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 图表切换后处理轴配置
 	 	 	 	 * @param     {[type]}                 rows     [description]
 	 	 	 	 * @param     {[type]}                 columns  [description]
 	 	 	 	 * @param     {[type]}                 measures [description]
 	 	 	 	 * @return    {[type]}                          [description]
 	 	 	 	 * @time      2019-05-18T17:49:18+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	checkQm: function(rows, columns, measures) {
 	 	 	 	 	 	this.model.hslice('ROWS', 0);
 	 	 	 	 	 	this.model.hslice('COLUMNS', 0);
 	 	 	 	 	 	return null;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * @description: 系统通知~~~~
 	 	 	 	 * 				 组件的数据准备就绪
 	 	 	 	 * @param _data: 转换后的cde格式数据，并将结果保存到组件UI渲染的配置对象里。
 	 	 	 	 * @param     {[type]}                 _data   [description]
 	 	 	 	 * @param     {[type]}                 raw     [description]
 	 	 	 	 * @param     {[type]}                 summary [description]
 	 	 	 	 * @param     {[type]}                 details [description]
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2019-05-18T12:29:11+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	dataFormatter: function(_data, raw, summary, details) {
 	 	 	 	 	 	var customs = this.model.getCustomizations();
 	 	 	 	 	 	var options = this.options;
 	 	 	 	 	 	var datasets;
 	 	 	 	 	 	var sum = 0;
 	 	 	 	 	 	this.options.series = new Array();
 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	datasets = this.details.children[0].details.measures;
 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	datasets = new Array();
 	 	 	 	 	 	}
 	 	 	 	 	 	datasets.every(function(item, i) {
 	 	 	 	 	 	 	 	this.push({
 	 	 	 	 	 	 	 	 	 	name: item.caption,
 	 	 	 	 	 	 	 	 	 	itemStyle: {
 	 	 	 	 	 	 	 	 	 	 	 	barBorderRadius: 6,
 	 	 	 	 	 	 	 	 	 	 	 	borderWidth: 5,
 	 	 	 	 	 	 	 	 	 	 	 	borderColor: 'transparent'
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	type: 'bar',
 	 	 	 	 	 	 	 	 	 	barWidth: 50,
 	 	 	 	 	 	 	 	 	 	stack: 'stack',
 	 	 	 	 	 	 	 	 	 	data: [{
 	 	 	 	 	 	 	 	 	 	 	 	value: item.value,
 	 	 	 	 	 	 	 	 	 	 	 	formatted: item.formatted,
 	 	 	 	 	 	 	 	 	 	 	 	itemStyle: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	color: 'transparent'
 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	label: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	show: true,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	color: '#888',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	verticalAlign: 'bottom',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	position: (i == 0) ? [0, 0] : ['100%', 0],
 	 	 	 	 	 	 	 	 	 	 	 	 	 	align: (i == 0) ? 'left' : 'right',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	formatter: function(params) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return params.seriesName;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	tooltip: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	show: false
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	value: item.value,
 	 	 	 	 	 	 	 	 	 	 	 	formatted: item.formatted
 	 	 	 	 	 	 	 	 	 	}]
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	sum += item.value;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}, this.options.series);
 	 	 	 	 	 	this.options.xAxis.max = sum;
 	 	 	 	 	 	this.options.xAxis.min = 0;
 	 	 	 	 	 	console.log(this.options);
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	}, {
 	 	 	 	thumbnail: 'icon iconfont icon-datafor-zhuzhuangtu',

 	 	 	 	_sort_order: 9,

 	 	 	 	symbol: 'bar.svg',

 	 	 	 	/**
 	 	 	 	 * 组件类的基本面板配置
 	 	 	 	 */
 	 	 	 	staticPanelOptions: _.extend(
 	 	 	 	 	 	[], [{
 	 	 	 	 	 	 	 	name: 'data',
 	 	 	 	 	 	 	 	label: Utility.locale('panel', 'data'),
 	 	 	 	 	 	 	 	active: true,
 	 	 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	 	 	instance.datasource(),
 	 	 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	 	 	instance.measures(null, 'mul', true),
 	 	 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	 	 	instance.dimensionDate(),
 	 	 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	 	 	instance.filters(),
 	 	 	 	 	 	 	 	 	 	instance.line()
 	 	 	 	 	 	 	 	]
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	name: 'style',
 	 	 	 	 	 	 	 	label: Utility.locale('panel', 'styles'),
 	 	 	 	 	 	 	 	active: false,
 	 	 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	 	 	/*整体配置*/
 	 	 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'frame style')),
 	 	 	 	 	 	 	 	 	 	Echarts.backgroundColor(Utility.locale('panel', 'background color')),
 	 	 	 	 	 	 	 	 	 	Echarts.border(Utility.locale('panel', 'border')),
 	 	 	 	 	 	 	 	 	 	instance.shadow(),
 	 	 	 	 	 	 	 	 	 	instance.line(),

 	 	 	 	 	 	 	 	 	 	instance.label('内容样式配置'),
 	 	 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Slider'), {
 	 	 	 	 	 	 	 	 	 	 	 	name: '_thin',
 	 	 	 	 	 	 	 	 	 	 	 	tooltip: '设置柱子的粗细尺寸',
 	 	 	 	 	 	 	 	 	 	 	 	label: '尺寸',
 	 	 	 	 	 	 	 	 	 	 	 	min: 10,
 	 	 	 	 	 	 	 	 	 	 	 	max: 45,
 	 	 	 	 	 	 	 	 	 	 	 	formatter: function(value) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return '当前尺寸:' + value + 'px';
 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	value: 20,
 	 	 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	options.series.every(function(item) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	item.barWidth = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('ColorsArray'), {
 	 	 	 	 	 	 	 	 	 	 	 	name: '_colors',
 	 	 	 	 	 	 	 	 	 	 	 	label: '颜色配置',
 	 	 	 	 	 	 	 	 	 	 	 	tooltip: '各个指标颜色配置',
 	 	 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (!Array.isArray(value)) return;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	options.color = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	 	 	name: '_nameFont',
 	 	 	 	 	 	 	 	 	 	 	 	label: '名称字体',
 	 	 	 	 	 	 	 	 	 	 	 	value: [14, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	 	 	sizes: [12, 14, 16, 18, 20],
 	 	 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	 	 	tooltip: '各指标名称标签字体样式',
 	 	 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	var max = options.xAxis.max;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	var normal;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	options.series.every(function(item, i) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (!Array.isArray(item.data) && item.data.length < 2) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	item.data[0].label = item.data[0].label || {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal = item.data[0].label;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.show = true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontSize = Number(value[0]);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.color = value[1];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontFamily = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontWeight = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontStyle = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	 	 	name: '_valueFont',
 	 	 	 	 	 	 	 	 	 	 	 	label: '值字体',
 	 	 	 	 	 	 	 	 	 	 	 	value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	 	 	sizes: [10, 11, 12, 14, 16, 18, 20],
 	 	 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	 	 	color: null,
 	 	 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	 	 	tooltip: '各指标值标签字体样式',
 	 	 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	var max = options.xAxis.max;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	options.series.every(function(item, i) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	var normal;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	item.label = item.label || {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	item.label.normal = item.label.normal || {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal = item.label.normal;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.show = true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.formatter = function(params) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return Number(100 * params.data.value / max).toFixed(1) + '%\t\t' + params.data.formatted;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (i == 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.position = [0, '110%'];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.align = 'left';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.position = ['100%', '110%'];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.align = 'right';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.verticalAlign = 'top';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontSize = Number(value[0]);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontFamily = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontWeight = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	normal.fontStyle = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	]
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	name: 'action',
 	 	 	 	 	 	 	 	label: Utility.locale('panel', 'actions'),
 	 	 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	 	 	//这一块需要抽象，不能让开发者随意修改
 	 	 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'refresh')),
 	 	 	 	 	 	 	 	 	 	instance.refresh(),
 	 	 	 	 	 	 	 	 	 	instance.period(),
 	 	 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'user interaction')),
 	 	 	 	 	 	 	 	 	 	instance.interaction(),
 	 	 	 	 	 	 	 	 	 	instance.menuEnable(),
 	 	 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'custom blocks')),
 	 	 	 	 	 	 	 	 	 	Echarts.clickPlotEvent(),
 	 	 	 	 	 	 	 	 	 	instance.preExecution(),
 	 	 	 	 	 	 	 	 	 	instance.preFetch(),
 	 	 	 	 	 	 	 	 	 	instance.postFetch(),
 	 	 	 	 	 	 	 	 	 	instance.postExecution()
 	 	 	 	 	 	 	 	]
 	 	 	 	 	 	}]
 	 	 	 	)
 	 	});

 	 	Base.register(Barchart);

 	 	return Barchart;
});