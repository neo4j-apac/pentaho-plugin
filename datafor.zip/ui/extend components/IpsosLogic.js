define('IpsosLogic', [
 	 	'Utility',
 	 	'Event',
 	 	'underscore',
 	 	'model/Component',
 	 	'utility/runtime'
], function(Utility, Events, _, Component, runtime) {

 	 	var _dbList = [{
 	 	 	 	"id": "[对标].[全国均值]",
 	 	 	 	"name": "全国均值",
 	 	 	 	"text": "全国均值"
 	 	}, {
 	 	 	 	"id": "[对标].[区域均值]",
 	 	 	 	"name": "区域均值",
 	 	 	 	"text": "区域均值"
 	 	}, {
 	 	 	 	"id": "[对标].[同规模均值]",
 	 	 	 	"name": "同规模均值",
 	 	 	 	"text": "同规模均值"
 	 	}];


 	 	var Logic = {

 	 	 	 	/**
 	 	 	 	 * 将Filter轴上的区域hierarchy，复制到Row上
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @return    {[type]}                           [description]
 	 	 	 	 * @time      2018-12-03T17:25:19+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	filterRegion2Row: function(query, tip, tc) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var levels = new Array();
 	 	 	 	 	 	var hierarchy = component.getHierarchy('[Dim company.default]', 'FILTER', true);
 	 	 	 	 	 	var cube = query.cube;
 	 	 	 	 	 	var last;
 	 	 	 	 	 	var formula;
 	 	 	 	 	 	var m = component.getMeasures();
 	 	 	 	 	 	var duibiao = component.getHierarchy('[对标]', 'FILTER', true);
 	 	 	 	 	 	var parent = new Array();
 	 	 	 	 	 	var duibiaoType;
 	 	 	 	 	 	var member;
 	 	 	 	 	 	var duibiaoName;
 	 	 	 	 	 	var j = _.find(tip.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '经销商选择';
 	 	 	 	 	 	});
 	 	 	 	 	 	if (!Array.isArray(m) || m.length == 0) {
 	 	 	 	 	 	 	 	return;
 	 	 	 	 	 	}
 	 	 	 	 	 	m = m[0];
 	 	 	 	 	 	if (duibiao && !_.isEmpty(duibiao.levels)) {
 	 	 	 	 	 	 	 	duibiao = duibiao.levels['对标'];
 	 	 	 	 	 	 	 	if (duibiao && Array.isArray(duibiao.filters)) {
 	 	 	 	 	 	 	 	 	 	duibiaoType = duibiao.filters[0].expressions[1];
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', ['[对标]']);
 	 	 	 	 	 	}
 	 	 	 	 	 	if (hierarchy && !_.isEmpty(hierarchy.levels)) {
 	 	 	 	 	 	 	 	for (var i in hierarchy.levels) {
 	 	 	 	 	 	 	 	 	 	levels.push({
 	 	 	 	 	 	 	 	 	 	 	 	level: hierarchy.levels[i],
 	 	 	 	 	 	 	 	 	 	 	 	order: runtime.getLevelOrderIndex(hierarchy.name + '.[' + i + ']', cube)
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	component.moveHierarchy('FILTER', 'ROWS', hierarchy.name);
 	 	 	 	 	 	}
 	 	 	 	 	 	levels.sort(function(a, b) {
 	 	 	 	 	 	 	 	return a.order - b.order;
 	 	 	 	 	 	});
 	 	 	 	 	 	last = levels[levels.length - 1];
 	 	 	 	 	 	if (last) {
 	 	 	 	 	 	 	 	last = last.level;
 	 	 	 	 	 	 	 	switch (last.name) {
 	 	 	 	 	 	 	 	 	 	case 'Dq name':
 	 	 	 	 	 	 	 	 	 	case 'dq name':
 	 	 	 	 	 	 	 	 	 	case 'Dq':
 	 	 	 	 	 	 	 	 	 	 	 	/*大区下进行全国对标*/
 	 	 	 	 	 	 	 	 	 	 	 	duibiao = '全国均值';
 	 	 	 	 	 	 	 	 	 	 	 	member = hierarchy.name + '.CurrentMember.Parent.Children';
 	 	 	 	 	 	 	 	 	 	 	 	formula = 'avg(' + member + ', ' + m.id + ')';
 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	case 'xq':
 	 	 	 	 	 	 	 	 	 	case 'xq name':
 	 	 	 	 	 	 	 	 	 	case 'Xq name':
 	 	 	 	 	 	 	 	 	 	 	 	if (duibiaoType == '全国均值') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	duibiao = '全国均值';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	member = '[Dim company.default].[' + last.name + '].members';
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	duibiao = '区域均值';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	member = '[Dim company.default].CurrentMember.Parent.Children';
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	formula = 'avg(' + member + ', ' + m.id + ')';
 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	 	 	var selectedName = j.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	 	 	 	 	if (!Array.isArray(selectedName) || selectedName.length == 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	data: '计算经销商对标所需要的规模信息没有取到'
 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	selectedName = selectedName[0];
 	 	 	 	 	 	 	 	 	 	 	 	var tcM = tc || '[Measures].[All tc]';
 	 	 	 	 	 	 	 	 	 	 	 	selectedName = tcM + '>0 and [Dim company.default].CurrentMember.Parent.Name=' + selectedName + '.Parent.Name)';
 	 	 	 	 	 	 	 	 	 	 	 	if (duibiaoType == '全国均值') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	duibiao = '全国均值';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	member = 'Filter([Dim company.default].[' + last.name + '].members, ' + selectedName;
 	 	 	 	 	 	 	 	 	 	 	 	} else if (duibiaoType == '区域均值') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	duibiao = '区域均值';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	member = 'Filter(Descendants([Dim company.default].CurrentMember.Parent.Parent.Parent, [Dim company.default].[' + last.name + ']), ' + selectedName;
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	/*同规模均值*/
 	 	 	 	 	 	 	 	 	 	 	 	 	 	duibiao = '同规模均值';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	member = 'Filter(Descendants([Dim company.default].CurrentMember.Parent.Parent, [Dim company.default].[' + last.name + ']), ' + selectedName;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	formula = 'avg(' + member + ', ' + m.id + ')';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	component
 	 	 	 	 	 	 	 	 	 	.createCalculatedMeasure(duibiao, formula, {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '#,###.0'
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.createCalculatedMeasure("StatusMeasureCalculated", 'IIf([Measures].[' + duibiao + ']-' + m.id + '>0, "true", "false")')
 	 	 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: duibiao,
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: 'StatusMeasureCalculated',
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	/*没有任何区域过滤，不计算对标*/
 	 	 	 	 	 	 	 	duibiao = null; //'全国均值';
 	 	 	 	 	 	 	 	formula = ''; //'avg(Filter([Dim company.default].[dealer].members,[Measures].[All tc]>0), ' + m.id + ')';
 	 	 	 	 	 	}
 	 	 	 	 	 	query = component.get('query');
 	 	 	 	 	 	return query;
 	 	 	 	},


 	 	 	 	tip2m: function(options, scale, after, precise) {
 	 	 	 	 	 	var s = Utility.isNumeric(scale) ? (scale || 1) : 1;
 	 	 	 	 	 	var p = Utility.isNumeric(precise) ? precise : 0;
 	 	 	 	 	 	options.series.every(function(item) {
 	 	 	 	 	 	 	 	Array.isArray(item.data) && item.data.every(function(o) {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(o.value)) {
 	 	 	 	 	 	 	 	 	 	 	 	o.formatted = Utility.localeNumeric(o.value / s, p) + (after || '');
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	o.formatted = '-';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},



 	 	 	 	changeStackBarLabel2Ratio: function(options) {
 	 	 	 	 	 	var getTotal = function(list) {
 	 	 	 	 	 	 	 	var c = 0;
 	 	 	 	 	 	 	 	Array.isArray(list) && list.every(function(o) {
 	 	 	 	 	 	 	 	 	 	c += Utility.isNumeric(o.value) ? o.value : 0;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return c == 0 ? 1 : c;
 	 	 	 	 	 	};
 	 	 	 	 	 	options.series.every(function(o) {
 	 	 	 	 	 	 	 	o.label.normal.formatter = function(params) {
 	 	 	 	 	 	 	 	 	 	var t = getTotal(params.data.measures);
 	 	 	 	 	 	 	 	 	 	var value = params.data.value;
 	 	 	 	 	 	 	 	 	 	return Utility.localeNumeric(100 * value / t, 1) + '%';
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * [description]
 	 	 	 	 * @param     {[type]}                 query  [description]
 	 	 	 	 * @param     {[type]}                 m      [description]
 	 	 	 	 * @param     {[type]}                 t      [description]
 	 	 	 	 * @param     {[type]}                 h      [description]
 	 	 	 	 * @param     {[type]}                 format [description]
 	 	 	 	 * @return    {[type]}                        [description]
 	 	 	 	 * @time      2018-12-07T14:11:33+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	thComparisonMake: function(query, m, t, h, format, origin, originFormat) {
 	 	 	 	 	 	var model = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	format = format || '#,###.0';
 	 	 	 	 	 	model.createCalculatedMeasure("同比", '(' + m + '-' + t + ')' + ' /' + t, {
 	 	 	 	 	 	 	 	"FORMAT_STRING": format
 	 	 	 	 	 	}).createCalculatedMeasure("环比", '(' + m + '-' + h + ')' + ' /' + h, {
 	 	 	 	 	 	 	 	"FORMAT_STRING": format
 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	name: '同比',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	});
 	 	 	 	 	 	if (origin) {
 	 	 	 	 	 	 	 	var extF = originFormat || '#,###.0';
 	 	 	 	 	 	 	 	model.createCalculatedMeasure('同比值', t, {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": extF
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.createCalculatedMeasure('环比值', h, {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": extF
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: '同比值',
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: '环比值',
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	}
 	 	 	 	 	 	/*返回值将替换原有的查询参数，发送至服务器查询数据*/
 	 	 	 	 	 	return model.get('query');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 比例同环比
 	 	 	 	 * @param     {[type]}                 query        [description]
 	 	 	 	 * @param     {[type]}                 m            [description]
 	 	 	 	 * @param     {[type]}                 t            [description]
 	 	 	 	 * @param     {[type]}                 h            [description]
 	 	 	 	 * @param     {[type]}                 format       [description]
 	 	 	 	 * @param     {[type]}                 origin       [description]
 	 	 	 	 * @param     {[type]}                 originFormat [description]
 	 	 	 	 * @return    {[type]}                              [description]
 	 	 	 	 * @time      2018-12-12T16:15:18+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	ratioThComparisonMake: function(query, m, t, h, format, origin, originFormat) {
 	 	 	 	 	 	var model = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	format = format || '#,###.0';
 	 	 	 	 	 	model.createCalculatedMeasure("同比", m + '-' + t, {
 	 	 	 	 	 	 	 	"FORMAT_STRING": format
 	 	 	 	 	 	}).createCalculatedMeasure("环比", m + '-' + h, {
 	 	 	 	 	 	 	 	"FORMAT_STRING": format
 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	name: '同比',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	});
 	 	 	 	 	 	if (origin) {
 	 	 	 	 	 	 	 	var extF = originFormat || '#,###.0';
 	 	 	 	 	 	 	 	model.createCalculatedMeasure('同比值', t, {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": extF
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.createCalculatedMeasure('环比值', h, {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": extF
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: '同比值',
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: '环比值',
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	}
 	 	 	 	 	 	/*返回值将替换原有的查询参数，发送至服务器查询数据*/
 	 	 	 	 	 	return model.get('query');
 	 	 	 	},





 	 	 	 	/**
 	 	 	 	 * 自定义指标值格式
 	 	 	 	 * @param     {[type]}                 value   值
 	 	 	 	 * @param     {[type]}                 precise 小数位精度
 	 	 	 	 * @param     {[type]}                 before  前缀值
 	 	 	 	 * @param     {[type]}                 after   后缀值
 	 	 	 	 * @param     {[type]}                 style   前后缀值样式
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2018-12-04T13:21:15+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	translateMvalue: function(value, precise, before, after, style) {
 	 	 	 	 	 	var val = Number(value);
 	 	 	 	 	 	var styles = '';
 	 	 	 	 	 	if (!_.isEmpty(style)) {
 	 	 	 	 	 	 	 	for (var i in style) {
 	 	 	 	 	 	 	 	 	 	styles += 'i:' + style[i];
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}
 	 	 	 	 	 	if (Utility.isNumeric(val)) {
 	 	 	 	 	 	 	 	val = (val / 1000000).toFixed(precise || 0);
 	 	 	 	 	 	 	 	if (before) {
 	 	 	 	 	 	 	 	 	 	val = '<span style="' + styles + '">' + before + '</span>' + val;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	if (after) {
 	 	 	 	 	 	 	 	 	 	val += '<span style="' + styles + '">' + after + '</span>';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	val = 'N/A';
 	 	 	 	 	 	}
 	 	 	 	 	 	return val;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 数据格式转换
 	 	 	 	 * @param     {[type]}                 value   原始值
 	 	 	 	 * @param     {[type]}                 precise 小数位精度
 	 	 	 	 * @param     {[type]}                 scale   放缩比例
 	 	 	 	 * @param     {[type]}                 before  前置字符
 	 	 	 	 * @param     {[type]}                 after   后置字符
 	 	 	 	 * @param     {[type]}                 style   追加字符样式
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2018-12-05T09:38:47+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	translateOriginValue: function(value, precise, scale, before, after, style) {
 	 	 	 	 	 	var val = Number(value);
 	 	 	 	 	 	var styles = '';
 	 	 	 	 	 	//scale = ((scale == 0) ? 0 : scale);
 	 	 	 	 	 	if (!_.isEmpty(style)) {
 	 	 	 	 	 	 	 	for (var i in style) {
 	 	 	 	 	 	 	 	 	 	styles += 'i:' + style[i];
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}
 	 	 	 	 	 	if (!Utility.isNumeric(scale) || scale == 0) {
 	 	 	 	 	 	 	 	scale = 1;
 	 	 	 	 	 	}
 	 	 	 	 	 	if (Utility.isNumeric(val)) {
 	 	 	 	 	 	 	 	val = Utility.isNumeric(scale) ? (val / scale) : val;
 	 	 	 	 	 	 	 	val = Utility.localeNumeric(val, precise || 0);
 	 	 	 	 	 	 	 	if (before) {
 	 	 	 	 	 	 	 	 	 	val = '<span style="' + styles + '">' + before + '</span>' + val;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	if (after) {
 	 	 	 	 	 	 	 	 	 	val += '<span style="' + styles + '">' + after + '</span>';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	val = 'N/A';
 	 	 	 	 	 	}
 	 	 	 	 	 	return val;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 通过当前选中月份，推算前12个月
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @param     {[type]}                 model [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-05T09:37:18+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	doLast12Months: function(query, model, hierarchy, level, months) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var hierarchyName = hierarchy || '[Dim ym.Mo]';
 	 	 	 	 	 	var levelName = level || 'Month';
 	 	 	 	 	 	var time = component.getHierarchy(hierarchyName, 'FILTER', true);
 	 	 	 	 	 	var expressions;
 	 	 	 	 	 	var end;
 	 	 	 	 	 	var id;
 	 	 	 	 	 	var count = months || 12;
 	 	 	 	 	 	var cube = query.cube;
 	 	 	 	 	 	if (time) {
 	 	 	 	 	 	 	 	var picker = _.find(model.parent.get('children'), function(o) {
 	 	 	 	 	 	 	 	 	 	return o.getLabel() == '月份时间轴组件';
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var end = picker.getDefaultsValue();
 	 	 	 	 	 	 	 	var mdx;
 	 	 	 	 	 	 	 	if (end && Array.isArray(end.value)) {
 	 	 	 	 	 	 	 	 	 	end = end.value[0];
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', [hierarchyName]);
 	 	 	 	 	 	 	 	if (!_.isEmpty(time.levels) && !_.isEmpty(time.levels[levelName])) {
 	 	 	 	 	 	 	 	 	 	if (end) {
 	 	 	 	 	 	 	 	 	 	 	 	mdx = "{ParallelPeriod(" +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	time.name + '.[' + levelName + ']' +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	", " + (count - 1) + ", " +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	end +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"):ParallelPeriod(" +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	time.name + '.[' + levelName + ']' +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	", 0, " +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	end +
 	 	 	 	 	 	 	 	 	 	 	 	 	 	")}";
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	mdx = null;
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	time = component.getHierarchy(hierarchyName, 'ROWS', true);
 	 	 	 	 	 	 	 	 	 	if (!_.isEmpty(time.levels) && !_.isEmpty(time.levels[levelName])) {
 	 	 	 	 	 	 	 	 	 	 	 	time.levels[levelName].mdx = mdx;
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 添加当前level的平均值指标
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-05T09:41:13+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	addCurrentLevelAvgMeasure: function(query, axisName, type) {
 	 	 	 	 	 	var axis = axisName || 'ROWS';
 	 	 	 	 	 	var agg = type || 'avg';
 	 	 	 	 	 	query.queryModel.axes[axis].aggregators = [agg];
 	 	 	 	 	 	return query;
 	 	 	 	},

 	 	 	 	addAvgBar: function(options, details) {
 	 	 	 	 	 	var sum;
 	 	 	 	 	 	if (details && details.details && Array.isArray(details.details.measures) && details.details.measures.length) {
 	 	 	 	 	 	 	 	sum = details.details.measures[0].value;
 	 	 	 	 	 	}
 	 	 	 	 	 	if (Utility.isNumeric(sum) && !_.find(options.series[0].data, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.name == '区域均值';
 	 	 	 	 	 	 	 	})) {
 	 	 	 	 	 	 	 	options.yAxis.data.unshift('区域均值');
 	 	 	 	 	 	 	 	options.series[0].data.unshift({
 	 	 	 	 	 	 	 	 	 	name: '区域均值',
 	 	 	 	 	 	 	 	 	 	value: sum,
 	 	 	 	 	 	 	 	 	 	formatted: Utility.localeNumeric(sum, 2),
 	 	 	 	 	 	 	 	 	 	itemStyle: {
 	 	 	 	 	 	 	 	 	 	 	 	color: '#49becf'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	}
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	addAvgLineAtFontend: function(options, details) {
 	 	 	 	 	 	var template = options.series[0];
 	 	 	 	 	 	var datasets = new Array();
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	if (details && Array.isArray(details.total) && details.total.length) {
 	 	 	 	 	 	 	 	datasets = details.total[0].datasets;
 	 	 	 	 	 	}
 	 	 	 	 	 	options.series.every(function(o) {
 	 	 	 	 	 	 	 	o.data.every(function(item) {
 	 	 	 	 	 	 	 	 	 	item.formatted = Utility.localeNumeric(item.value / 1000000, 1) + 'm';
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	template.data.length == datasets.length && datasets.every(function(o, i) {
 	 	 	 	 	 	 	 	var item = Utility.deepCopy(this[i]);
 	 	 	 	 	 	 	 	var val = (o || o == 0) ? o.replace(/\,/g, '') : 0;
 	 	 	 	 	 	 	 	val = Number(val);
 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	id: item.id,
 	 	 	 	 	 	 	 	 	 	name: item.name,
 	 	 	 	 	 	 	 	 	 	levels: item.levels,
 	 	 	 	 	 	 	 	 	 	measures: item.measures,
 	 	 	 	 	 	 	 	 	 	formatted: Utility.localeNumeric(val / 1000000, 1) + 'm',
 	 	 	 	 	 	 	 	 	 	value: val
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}, template.data);
 	 	 	 	 	 	options.series.push({
 	 	 	 	 	 	 	 	type: 'line',
 	 	 	 	 	 	 	 	smooth: true,
 	 	 	 	 	 	 	 	name: '区域均值',
 	 	 	 	 	 	 	 	data: list
 	 	 	 	 	 	});
 	 	 	 	 	 	options.legend.data.push('区域均值');
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 配件收入页面里表格查询指标处理
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-05T10:36:57+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	partIncomeMeasuresModify: function(query, m, h, t) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	component.createCalculatedMeasure("同比", '100*(' + m + '-' + t + ')' + ' /' + t, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure("环比", '100*(' + m + '-' + h + ')' + ' /' + h, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure("与上月差额", m + '-' + h, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure("与去年同期差额", m + '-' + t, null)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '与上月差额',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '与去年同期差额',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '同比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	changeIncomeListName: function(options, details, baseOptions, threthhold) {
 	 	 	 	 	 	if (details &&
 	 	 	 	 	 	 	 	details.details &&
 	 	 	 	 	 	 	 	Array.isArray(details.details.measures) &&
 	 	 	 	 	 	 	 	details.details.measures.length &&
 	 	 	 	 	 	 	 	!_.find(baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.appendNode;
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	var item = {};
 	 	 	 	 	 	 	 	var colNode = _.find(baseOptions.colModel, function(o) {
 	 	 	 	 	 	 	 	 	 	return !o.isNumericNode;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var id = colNode.dataIndx;
 	 	 	 	 	 	 	 	details.details.measures.every(function(o) {
 	 	 	 	 	 	 	 	 	 	item[o.uniqueName] = o.value;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	item[id] = '区域平均';
 	 	 	 	 	 	 	 	item.appendNode = true;
 	 	 	 	 	 	 	 	baseOptions.datasets.push(item);
 	 	 	 	 	 	}
 	 	 	 	 	 	threthhold = threthhold || 0;
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.default].[xq]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '本月收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[与上月差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '与上月差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[与去年同期差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '与去年同期差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	 	 	if (['[Measures].[Part income]', '[Measures].[与上月差额]', '[Measures].[与去年同期差额]'].indexOf(name) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric(item[name] / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (item[name] < threthhold) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	addListMeasuresForIncomeCompare: function(query, m, h) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	component.createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'差额',
 	 	 	 	 	 	 	 	 	 	m + '-' + h
 	 	 	 	 	 	 	 	).createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	"环比",
 	 	 	 	 	 	 	 	 	 	'100*(' + m + '-' + h + ')' + ' /' + h)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '差额',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},


 	 	 	 	byIncomeListRender: function(options, details, baseOptions) {
 	 	 	 	 	 	if (details &&
 	 	 	 	 	 	 	 	details.details &&
 	 	 	 	 	 	 	 	Array.isArray(details.details.measures) &&
 	 	 	 	 	 	 	 	details.details.measures.length &&
 	 	 	 	 	 	 	 	!_.find(baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.appendNode;
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	var item = {};
 	 	 	 	 	 	 	 	var colNode = _.find(baseOptions.colModel, function(o) {
 	 	 	 	 	 	 	 	 	 	return !o.isNumericNode;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var id = colNode.dataIndx;
 	 	 	 	 	 	 	 	details.details.measures.every(function(o) {
 	 	 	 	 	 	 	 	 	 	item[o.uniqueName] = o.value;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	item[id] = '平均';
 	 	 	 	 	 	 	 	item.appendNode = true;
 	 	 	 	 	 	 	 	baseOptions.datasets.push(item);
 	 	 	 	 	 	}
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.default].[xq]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '区域';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part by income]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part wx income]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sg income]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sp income]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '本期' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part by income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part wx income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sg income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sp income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '上期' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[环比]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	//TODO
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric((item[name] || 0) / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[环比]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (item[name] < 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else if (item[name] > 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:green;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	},

 	 	 	 	partIncomeDqList0: function(query, m, formula, label, main) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var name = label || '比例';
 	 	 	 	 	 	component.createCalculatedMeasure(name, formula, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure('本期收入值', '1*' + m, null);
 	 	 	 	 	 	main && component.createCalculatedMeasure('差额', main + '-' + m, null);
 	 	 	 	 	 	component.includeMeasure({
 	 	 	 	 	 	 	 	name: '本期收入值',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	}, 0);
 	 	 	 	 	 	main && component.includeMeasure({
 	 	 	 	 	 	 	 	name: '差额',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	});
 	 	 	 	 	 	component.includeMeasure({
 	 	 	 	 	 	 	 	name: name,
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	partIncomeDqListRender0: function(options, details, baseOptions, threthhold) {
 	 	 	 	 	 	if (details &&
 	 	 	 	 	 	 	 	details.details &&
 	 	 	 	 	 	 	 	Array.isArray(details.details.measures) &&
 	 	 	 	 	 	 	 	details.details.measures.length &&
 	 	 	 	 	 	 	 	!_.find(baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.appendNode;
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	var item = {};
 	 	 	 	 	 	 	 	var colNode = _.find(baseOptions.colModel, function(o) {
 	 	 	 	 	 	 	 	 	 	return !o.isNumericNode;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var id = colNode.dataIndx;
 	 	 	 	 	 	 	 	details.details.measures.every(function(o) {
 	 	 	 	 	 	 	 	 	 	item[o.uniqueName] = o.value;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	item[id] = '全国';
 	 	 	 	 	 	 	 	item.appendNode = true;
 	 	 	 	 	 	 	 	baseOptions.datasets.push(item);
 	 	 	 	 	 	}
 	 	 	 	 	 	threthhold = threthhold || 0;
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = item[name].value;
 	 	 	 	 	 	 	 	//var unit = '<div style="text-align:right;">(m)</div>';
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	var val;
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.default].[Dq name]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[本期收入值]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '本期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	//val = item[name].value;
 	 	 	 	 	 	 	 	 	 	//if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name].value)) {
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[本期收入值]' || name == '[Measures].[差额]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric((item[name].value || 0) / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[完成]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (item[name].value < 100) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 大区环比列表
 	 	 	 	 * @param     {[type]}                 options     [description]
 	 	 	 	 * @param     {[type]}                 details     [description]
 	 	 	 	 * @param     {[type]}                 baseOptions [description]
 	 	 	 	 * @param     {[type]}                 threthhold  [description]
 	 	 	 	 * @return    {[type]}                             [description]
 	 	 	 	 * @time      2018-12-06T13:26:21+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	partIncomeDqListRender1: function(options, details, baseOptions, threthhold) {
 	 	 	 	 	 	if (details &&
 	 	 	 	 	 	 	 	details.details &&
 	 	 	 	 	 	 	 	Array.isArray(details.details.measures) &&
 	 	 	 	 	 	 	 	details.details.measures.length &&
 	 	 	 	 	 	 	 	!_.find(baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.appendNode;
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	var item = {};
 	 	 	 	 	 	 	 	var colNode = _.find(baseOptions.colModel, function(o) {
 	 	 	 	 	 	 	 	 	 	return !o.isNumericNode;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var id = colNode.dataIndx;
 	 	 	 	 	 	 	 	details.details.measures.every(function(o) {
 	 	 	 	 	 	 	 	 	 	item[o.uniqueName] = o.value;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	item[id] = '全国';
 	 	 	 	 	 	 	 	item.appendNode = true;
 	 	 	 	 	 	 	 	baseOptions.datasets.push(item);
 	 	 	 	 	 	}
 	 	 	 	 	 	threthhold = threthhold || 0;
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.default].[Dq name]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[本期收入值]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '上期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[本期收入值]' || name == '[Measures].[差额]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric((item[name] || 0) / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[环比]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (item[name] < threthhold) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 配件总收入对比列表-同比
 	 	 	 	 * @param     {[type]}                 options     [description]
 	 	 	 	 * @param     {[type]}                 details     [description]
 	 	 	 	 * @param     {[type]}                 baseOptions [description]
 	 	 	 	 * @param     {[type]}                 threthhold  [description]
 	 	 	 	 * @return    {[type]}                             [description]
 	 	 	 	 * @time      2018-12-06T13:34:30+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	partIncomeDqListRender2: function(options, details, baseOptions, threthhold) {
 	 	 	 	 	 	if (details &&
 	 	 	 	 	 	 	 	details.details &&
 	 	 	 	 	 	 	 	Array.isArray(details.details.measures) &&
 	 	 	 	 	 	 	 	details.details.measures.length &&
 	 	 	 	 	 	 	 	!_.find(baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.appendNode;
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	var item = {};
 	 	 	 	 	 	 	 	var colNode = _.find(baseOptions.colModel, function(o) {
 	 	 	 	 	 	 	 	 	 	return !o.isNumericNode;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var id = colNode.dataIndx;
 	 	 	 	 	 	 	 	details.details.measures.every(function(o) {
 	 	 	 	 	 	 	 	 	 	item[o.uniqueName] = o.value;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	item[id] = '全国';
 	 	 	 	 	 	 	 	item.appendNode = true;
 	 	 	 	 	 	 	 	baseOptions.datasets.push(item);
 	 	 	 	 	 	}
 	 	 	 	 	 	threthhold = threthhold || 0;
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.default].[Dq name]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[本期收入值]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '去年同期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income tb]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[本期收入值]' || name == '[Measures].[差额]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric((item[name] || 0) / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[同比]' || name == '[Measures].[差额]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (item[name] < threthhold) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	},

 	 	 	 	partIncomeDqListBottom: function(query, m, h) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	component.createCalculatedMeasure('差额', m + '-' + h, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure('环比', '100*(' + m + '-' + h + ')/' + h, null)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '差额',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	partIncomeDqListBottomRender: function(options, details, baseOptions, threthhold) {
 	 	 	 	 	 	if (details &&
 	 	 	 	 	 	 	 	details.details &&
 	 	 	 	 	 	 	 	Array.isArray(details.details.measures) &&
 	 	 	 	 	 	 	 	details.details.measures.length &&
 	 	 	 	 	 	 	 	!_.find(baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.appendNode;
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	var item = {};
 	 	 	 	 	 	 	 	var colNode = _.find(baseOptions.colModel, function(o) {
 	 	 	 	 	 	 	 	 	 	return !o.isNumericNode;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var id = colNode.dataIndx;
 	 	 	 	 	 	 	 	details.details.measures.every(function(o) {
 	 	 	 	 	 	 	 	 	 	item[o.uniqueName] = o.value;
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	item[id] = '全国';
 	 	 	 	 	 	 	 	item.appendNode = true;
 	 	 	 	 	 	 	 	baseOptions.datasets.push(item);
 	 	 	 	 	 	}
 	 	 	 	 	 	threthhold = threthhold || 0;
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.default].[Dq name]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '区域';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part by income]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sg income]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sp income]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part wx income]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '本期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part by income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sg income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part sp income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part wx income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '上期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	 	 	if ([
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[Part by income]', '[Measures].[Part by income hb]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[Part sg income]', '[Measures].[Part sg income hb]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[Part sp income]', '[Measures].[Part sp income hb]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[Part wx income]', '[Measures].[Part wx income hb]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[差额]'
 	 	 	 	 	 	 	 	 	 	 	 	 	 	].indexOf(name) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric((item[name] || 0) / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[环比]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (item[name] < threthhold) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * 部件收入经销商对比页面，经销商规模占比
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-06T16:45:37+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	makeJxsRatioMeasure: function(query, chart, formula) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	// var cube = query.cube;
 	 	 	 	 	 	// var xq = _.find(chart.dashboard.components, function(o) {
 	 	 	 	 	 	// 	return o.model.getLabel() == '小区选择';
 	 	 	 	 	 	// });
 	 	 	 	 	 	// var hierarchy = component.getHierarchy('[Dim company.default]', 'FILTER', true);
 	 	 	 	 	 	// var orderList = new Array();
 	 	 	 	 	 	// var level;
 	 	 	 	 	 	// var m = component.getMeasures();
 	 	 	 	 	 	// var countrySummary = function() {
 	 	 	 	 	 	// 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	// 		controls: {
 	 	 	 	 	 	// 			include: ['Alert']
 	 	 	 	 	 	// 		},
 	 	 	 	 	 	// 		data: '没有拿到小区信息'
 	 	 	 	 	 	// 	});
 	 	 	 	 	 	// 	return component.get('query');
 	 	 	 	 	 	// };
 	 	 	 	 	 	// xq = xq.model.getDefaultsValue().value[0];
 	 	 	 	 	 	// console.log('hello');
 	 	 	 	 	 	// if (!hierarchy || _.isEmpty(hierarchy.levels) || !Array.isArray(m) || m.length < 1) {
 	 	 	 	 	 	// 	return countrySummary();
 	 	 	 	 	 	// }
 	 	 	 	 	 	// m = m[0];
 	 	 	 	 	 	// for (var i in hierarchy.levels) {
 	 	 	 	 	 	// 	if (i == 'scale') {
 	 	 	 	 	 	// 		continue;
 	 	 	 	 	 	// 	}
 	 	 	 	 	 	// 	orderList.push({
 	 	 	 	 	 	// 		level: hierarchy.levels[i],
 	 	 	 	 	 	// 		order: runtime.getLevelOrderIndex(hierarchy.name + '.[' + i + ']', cube)
 	 	 	 	 	 	// 	});
 	 	 	 	 	 	// }
 	 	 	 	 	 	// orderList.sort(function(a, b) {
 	 	 	 	 	 	// 	return a.order - b.order;
 	 	 	 	 	 	// });
 	 	 	 	 	 	// level = orderList[orderList.length - 1];
 	 	 	 	 	 	// if (!level) {
 	 	 	 	 	 	// 	return countrySummary();
 	 	 	 	 	 	// }
 	 	 	 	 	 	// level = level.level;
 	 	 	 	 	 	// if (!Array.isArray(level.filters) ||
 	 	 	 	 	 	// 	!level.filters[0] ||
 	 	 	 	 	 	// 	!Array(level.filters[0].expressions) ||
 	 	 	 	 	 	// 	level.filters[0].expressions.length < 1) {
 	 	 	 	 	 	// 	return countrySummary();
 	 	 	 	 	 	// }
 	 	 	 	 	 	// level = level.filters[0].expressions[0] + '.[' + level.filters[0].expressions[1] + '].[scale]';
 	 	 	 	 	 	component.createCalculatedMeasure(
 	 	 	 	 	 	 	 	'总计',
 	 	 	 	 	 	 	 	formula
 	 	 	 	 	 	 	 	//'Avg(Filter(Descendants([Dim company.default].members, [Dim company.default].[dealer]), [Dim company.default].CurrentMember.Parent.Parent.uniqueName="' + xq + '"), ' + m.id + ')'
 	 	 	 	 	 	).includeMeasure({
 	 	 	 	 	 	 	 	name: '总计',
 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 经销商占比饼图options配置修改
 	 	 	 	 * @return    {[type]}                 [description]
 	 	 	 	 * @time      2018-12-06T17:32:06+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	jxsRadioOptionsModify: function(options, details) {
 	 	 	 	 	 	var item = options.series[0].data;
 	 	 	 	 	 	var typev;
 	 	 	 	 	 	var allv;
 	 	 	 	 	 	if (!details ||
 	 	 	 	 	 	 	 	!Array.isArray(details.children) ||
 	 	 	 	 	 	 	 	details.children.length < 1 ||
 	 	 	 	 	 	 	 	_.isEmpty(details.children[0].details) ||
 	 	 	 	 	 	 	 	!Array.isArray(details.children[0].details.measures) ||
 	 	 	 	 	 	 	 	details.children[0].details.measures.length < 2
 	 	 	 	 	 	) {
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	}
 	 	 	 	 	 	allv = item[0].value;
 	 	 	 	 	 	typev = details.children[0].details.measures[1].value;
 	 	 	 	 	 	if (!Array.isArray(item) || item.length < 1 || _.find(item, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.name == 'typevalue';
 	 	 	 	 	 	 	 	})) {
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	}
 	 	 	 	 	 	item[0].value = allv - typev;
 	 	 	 	 	 	item[0].itemStyle = {
 	 	 	 	 	 	 	 	color: '#e0e0e0'
 	 	 	 	 	 	};
 	 	 	 	 	 	item.unshift({
 	 	 	 	 	 	 	 	cateID: '',
 	 	 	 	 	 	 	 	levels: Utility.deepCopy(item[0].levels),
 	 	 	 	 	 	 	 	measures: Utility.deepCopy(item[0].measures),
 	 	 	 	 	 	 	 	name: 'typevalue',
 	 	 	 	 	 	 	 	value: typev
 	 	 	 	 	 	});
 	 	 	 	 	 	item[0].label = {
 	 	 	 	 	 	 	 	show: true,
 	 	 	 	 	 	 	 	position: 'center',
 	 	 	 	 	 	 	 	fontSize: 18,
 	 	 	 	 	 	 	 	formatter: function() {
 	 	 	 	 	 	 	 	 	 	return (100 * typev / allv).toFixed(1) + '%';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	};
 	 	 	 	 	 	item.every(function(o) {
 	 	 	 	 	 	 	 	o.tooltip = {
 	 	 	 	 	 	 	 	 	 	show: false
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	o.hoverAnimation = false;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	//console.log(options);
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	jxsTop5ListMeasureModify: function(query, m, h, t) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	component.createCalculatedMeasure("同比", '100*(' + m + '-' + t + ')' + ' /' + t, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure("环比", '100*(' + m + '-' + h + ')' + ' /' + h, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure('环比差额', m + '-' + h, null)
 	 	 	 	 	 	 	 	.createCalculatedMeasure('同比差额', m + '-' + t, null)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '环比差额',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}, 3)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}, 4)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '同比差额',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}, 6)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '同比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * Top5经销商对比列表
 	 	 	 	 * @param     {[type]}                 options     [description]
 	 	 	 	 * @param     {[type]}                 details     [description]
 	 	 	 	 * @param     {[type]}                 baseOptions [description]
 	 	 	 	 * @return    {[type]}                             [description]
 	 	 	 	 * @time      2018-12-06T21:59:48+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	jxsTop5ListRender: function(options, details, baseOptions) {
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	var unit = '(m)';
 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim company.scale].[scale]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '类型';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income tb]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '去年同期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income hb]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '上期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[Part income]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '本期收入' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[环比差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '环比差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	case '[Measures].[同比差额]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '同比差额' + unit;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item[name])) {
 	 	 	 	 	 	 	 	 	 	 	 	if ([
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[Part income]', '[Measures].[Part income hb]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[同比差额]', '[Measures].[Part income tb]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[环比差额]'
 	 	 	 	 	 	 	 	 	 	 	 	 	 	].indexOf(name) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = Utility.localeNumeric((item[name] || 0) / 1000000, 1);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	if (name == '[Measures].[环比]' || name == '[Measures].[环比]') {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (item[name] < 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '<span style="color:red;">' + value + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = value;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 区域选择器状态变化事件
 	 	 	 	 * @param     {[type]}                 _selector [description]
 	 	 	 	 * {
 	 	 	 	 * 		dashboard: Object,  	//页面引用
 	 	 	 	 *
 	 	 	 	 * 		dq_sName: '',	//大区选择框名称
 	 	 	 	 * 		xq_sName: '',	//小区选择框名称
 	 	 	 	 * 		jxs_sName: '',	//经销商选择框名称
 	 	 	 	 *
 	 	 	 	 * 		dq: String,			//大区标签页的UUID
 	 	 	 	 * 		xq: String,			//小区标签页的UUID
 	 	 	 	 * 		jxs: String,			//经销商标签页的UUID
 	 	 	 	 * 		by: String,			//保养标签页的UUID
 	 	 	 	 * 		pp: String			//品牌标签页的UUID
 	 	 	 	 * }
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-07T09:41:52+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	selectedUpdateEvent: function(type, value, _selector) {
 	 	 	 	 	 	var selector = (function(arg0, arg1, arg2) {
 	 	 	 	 	 	 	 	if (_.isObject(arg0) && arg0.hasOwnProperty('dashboard')) {
 	 	 	 	 	 	 	 	 	 	return arg0;
 	 	 	 	 	 	 	 	} else if (_.isObject(arg1) && arg1.hasOwnProperty('dashboard')) {
 	 	 	 	 	 	 	 	 	 	return arg1;
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	return arg2;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	})(type, value, _selector);
 	 	 	 	 	 	var component = _.find(selector.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.type == 'StaticsComponentTabs';
 	 	 	 	 	 	});
 	 	 	 	 	 	if (!component) {
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	}
 	 	 	 	 	 	var dqName = selector.dq_sName || '大区选择';
 	 	 	 	 	 	var ds = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == dqName;
 	 	 	 	 	 	});
 	 	 	 	 	 	var xqName = selector.xq_sName || '小区选择';
 	 	 	 	 	 	var xs = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == xqName;
 	 	 	 	 	 	});
 	 	 	 	 	 	var jxsName = selector.jxs_sName || '经销商选择';
 	 	 	 	 	 	var js = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == jxsName;
 	 	 	 	 	 	});
 	 	 	 	 	 	var d;
 	 	 	 	 	 	var x;
 	 	 	 	 	 	var j;
 	 	 	 	 	 	var b;
 	 	 	 	 	 	var p;
 	 	 	 	 	 	if (!component || !ds || !xs || !js) {
 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	data: '判断需要用到的条件搜集不全'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	}
 	 	 	 	 	 	ds = ds.model.getDefaultsValue().value;
 	 	 	 	 	 	xs = xs.model.getDefaultsValue().value;
 	 	 	 	 	 	js = js.model.getDefaultsValue().value;
 	 	 	 	 	 	d = selector.dq || 'CINTLMLEAFAYFLQJAWCHQILHNA';
 	 	 	 	 	 	d = component.$el.find('a[aria-controls="' + d + '"]');
 	 	 	 	 	 	x = selector.xq || 'CHNFLDLAAPAXFXIRNVCJIUTVFE';
 	 	 	 	 	 	x = component.$el.find('a[aria-controls="' + x + '"]');
 	 	 	 	 	 	j = selector.jxs || 'CQNRLFLLAAATFYQWCBAJASLIAT';
 	 	 	 	 	 	j = component.$el.find('a[aria-controls="' + j + '"]');
 	 	 	 	 	 	b = selector.by || 'CCNJLNLOCQLXZQIBWYIRTIZVCN';
 	 	 	 	 	 	b = component.$el.find('a[aria-controls="' + b + '"]');
 	 	 	 	 	 	p = selector.pp || 'CUNYLFLPCVLGZBLCALWEWUZSZM';
 	 	 	 	 	 	p = component.$el.find('a[aria-controls="' + p + '"]');
 	 	 	 	 	 	/*经销商选择框有值*/
 	 	 	 	 	 	if (js.length) {
 	 	 	 	 	 	 	 	d.hide();
 	 	 	 	 	 	 	 	x.hide();
 	 	 	 	 	 	 	 	j.hide();
 	 	 	 	 	 	 	 	b.tab('show');
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	/*小区选择框有值*/
 	 	 	 	 	 	 	 	if (xs.length) {
 	 	 	 	 	 	 	 	 	 	d.hide();
 	 	 	 	 	 	 	 	 	 	x.hide();
 	 	 	 	 	 	 	 	 	 	j.show().tab('show');
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	/*大区选择框有值*/
 	 	 	 	 	 	 	 	 	 	if (ds.length) {
 	 	 	 	 	 	 	 	 	 	 	 	d.hide();
 	 	 	 	 	 	 	 	 	 	 	 	x.show().tab('show');
 	 	 	 	 	 	 	 	 	 	 	 	j.hide();
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	d.show().tab('show');
 	 	 	 	 	 	 	 	 	 	 	 	x.hide();
 	 	 	 	 	 	 	 	 	 	 	 	j.hide();
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 预览页面的区域下拉框选择事件
 	 	 	 	 * @param     {[type]}                 type      [description]
 	 	 	 	 * @param     {[type]}                 value     [description]
 	 	 	 	 * @param     {[type]}                 component [description]
 	 	 	 	 * @return    {[type]}                           [description]
 	 	 	 	 * @time      2018-12-07T10:50:08+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	selectorUpdatePreview: function(type, value, component) {
 	 	 	 	 	 	var duibiao = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '对标选择';
 	 	 	 	 	 	});
 	 	 	 	 	 	var d = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '大区选择';
 	 	 	 	 	 	});
 	 	 	 	 	 	var x = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '小区选择';
 	 	 	 	 	 	});
 	 	 	 	 	 	var j = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '经销商选择';
 	 	 	 	 	 	});
 	 	 	 	 	 	var jvalue;
 	 	 	 	 	 	var dvalue;
 	 	 	 	 	 	var xvalue;
 	 	 	 	 	 	var duibiaoUpdate = function(list, value) {
 	 	 	 	 	 	 	 	var defaults = duibiao.model.getDefaultsValue();
 	 	 	 	 	 	 	 	var selected = defaults && Array.isArray(defaults.value) ? defaults.value[0] : null;
 	 	 	 	 	 	 	 	duibiao.model.valuesAvailable = Utility.deepCopy(_dbList.filter(function(o) {
 	 	 	 	 	 	 	 	 	 	return list.indexOf(o.name) >= 0;
 	 	 	 	 	 	 	 	}));
 	 	 	 	 	 	 	 	if (!_.find(duibiao.model.valuesAvailable, function(o) {
 	 	 	 	 	 	 	 	 	 	 	 	return o.id == selected;
 	 	 	 	 	 	 	 	 	 	})) {
 	 	 	 	 	 	 	 	 	 	duibiao.model.defaultValueUpdated([value], true);
 	 	 	 	 	 	 	 	 	 	duibiao.selectorUpdate([value]);
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	duibiao.model.defaultValueUpdated([selected], true);
 	 	 	 	 	 	 	 	 	 	duibiao.selectorUpdate([selected]);
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	};
 	 	 	 	 	 	if (duibiao) {
 	 	 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	 	 	jvalue = j.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	 	 	jvalue = '';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	 	 	dvalue = d.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	 	 	dvalue = '';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	 	 	xvalue = x.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	 	 	xvalue = '';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	if (jvalue.length) {
 	 	 	 	 	 	 	 	 	 	duibiaoUpdate(['全国均值', '区域均值', '同规模均值'], '[对标].[同规模均值]');
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	if (xvalue.length) {
 	 	 	 	 	 	 	 	 	 	 	 	duibiaoUpdate(['全国均值', '区域均值'], '[对标].[区域均值]');
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	duibiaoUpdate(['全国均值'], '[对标].[全国均值]');
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	yAxis2m: function(o, component, reverse, scale, unit, precise) {
 	 	 	 	 	 	var s = Utility.isNumeric(scale) ? (scale || 1) : 1000000;
 	 	 	 	 	 	var r = component.quantizeAxisValue.bind(component);
 	 	 	 	 	 	var p = Utility.isNumeric(precise) ? precise : 1;
 	 	 	 	 	 	var name = !!reverse ? 'xAxis' : 'yAxis';
 	 	 	 	 	 	if (unit == null || unit == undefined) {
 	 	 	 	 	 	 	 	a = 'm';
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	a = unit || '';
 	 	 	 	 	 	}
 	 	 	 	 	 	component.quantizeAxisValue = function() {
 	 	 	 	 	 	 	 	r();
 	 	 	 	 	 	 	 	this.options[name].axisLabel.formatter = function(value) {
 	 	 	 	 	 	 	 	 	 	//return value;
 	 	 	 	 	 	 	 	 	 	return Utility.localeNumeric(value / s, p) + a;
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;

 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * 手动添加上月、环比计算成员
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-11T14:18:54+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	addPrevAndHbMemberManually: function(query, list) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var time = _.find(list.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '月份时间轴组件';
 	 	 	 	 	 	});
 	 	 	 	 	 	var hierarchyName = '[Dim ym.default]';
 	 	 	 	 	 	var levelName = 'Mo';
 	 	 	 	 	 	var levelUniqueName = hierarchyName + '.[' + levelName + ']';
 	 	 	 	 	 	var value;
 	 	 	 	 	 	var parent;
 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', [hierarchyName]);
 	 	 	 	 	 	if (!time) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	value = time.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	value = value[0];
 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	parent = value.replace(/(\[.*\].)(\[.*\].)(\[.*\])\.(.*)/g, '$1$2$3');
 	 	 	 	 	 	component.createCalculatedMemeber({
 	 	 	 	 	 	 	 	 	 	"parentMember": parent,
 	 	 	 	 	 	 	 	 	 	"parentMemberLevel": "",
 	 	 	 	 	 	 	 	 	 	"previousLevel": "",
 	 	 	 	 	 	 	 	 	 	"dimension": "Dim ym",
 	 	 	 	 	 	 	 	 	 	"name": "上月",
 	 	 	 	 	 	 	 	 	 	//"uniqueName": hierarchyName + ".[上月]",
 	 	 	 	 	 	 	 	 	 	"uniqueName": parent + ".[上月]",
 	 	 	 	 	 	 	 	 	 	"caption": "上月",
 	 	 	 	 	 	 	 	 	 	"properties": {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": "#,###"
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	"formula": value + '.PrevMember',
 	 	 	 	 	 	 	 	 	 	"hierarchyName": hierarchyName,
 	 	 	 	 	 	 	 	 	 	"assignedLevel": levelUniqueName
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	.createCalculatedMemeber({
 	 	 	 	 	 	 	 	 	 	"parentMember": parent,
 	 	 	 	 	 	 	 	 	 	"parentMemberLevel": "",
 	 	 	 	 	 	 	 	 	 	"previousLevel": "",
 	 	 	 	 	 	 	 	 	 	"dimension": "Dim ym",
 	 	 	 	 	 	 	 	 	 	"name": "本月",
 	 	 	 	 	 	 	 	 	 	//"uniqueName": hierarchyName + ".[本月]",
 	 	 	 	 	 	 	 	 	 	"uniqueName": parent + ".[本月]",
 	 	 	 	 	 	 	 	 	 	"caption": "本月",
 	 	 	 	 	 	 	 	 	 	"properties": {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": "#,###"
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	"formula": value,
 	 	 	 	 	 	 	 	 	 	"hierarchyName": hierarchyName,
 	 	 	 	 	 	 	 	 	 	"assignedLevel": levelUniqueName
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	.createCalculatedMemeber({
 	 	 	 	 	 	 	 	 	 	"parentMember": parent,
 	 	 	 	 	 	 	 	 	 	"parentMemberLevel": "",
 	 	 	 	 	 	 	 	 	 	"previousLevel": "",
 	 	 	 	 	 	 	 	 	 	"dimension": "Dim ym",
 	 	 	 	 	 	 	 	 	 	"name": "环比",
 	 	 	 	 	 	 	 	 	 	//"uniqueName": hierarchyName + ".[环比]",
 	 	 	 	 	 	 	 	 	 	"uniqueName": parent + ".[环比]",
 	 	 	 	 	 	 	 	 	 	"caption": "环比",
 	 	 	 	 	 	 	 	 	 	"properties": {
 	 	 	 	 	 	 	 	 	 	 	 	"FORMAT_STRING": "0.0%"
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	"formula": "(" + value + "-" + value + ".PrevMember) / " + value + ".PrevMember)",
 	 	 	 	 	 	 	 	 	 	"hierarchyName": hierarchyName,
 	 	 	 	 	 	 	 	 	 	"assignedLevel": levelUniqueName
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[上月]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[本月]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[环比]", hierarchyName);
 	 	 	 	 	 	component.setLevelMdxSelections({
 	 	 	 	 	 	 	 	hierarchyName: hierarchyName,
 	 	 	 	 	 	 	 	levelName: levelName,
 	 	 	 	 	 	 	 	mdx: '{' + parent + '.[上月], ' + parent + '.[本月],' + parent + '.[环比]}',
 	 	 	 	 	 	 	 	notify: false
 	 	 	 	 	 	}, 'ROWS');
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 格式化本月基盘的列表数据
 	 	 	 	 * @param     {[type]}                 options [description]
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2018-12-11T16:17:19+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	formatJpList: function(component, options) {
 	 	 	 	 	 	var levelUniqueName = '[Dim ym.default].[Mo]';
 	 	 	 	 	 	var s = _.find(component.baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	return o[levelUniqueName] == '上月';
 	 	 	 	 	 	});
 	 	 	 	 	 	var b = _.find(component.baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	return o[levelUniqueName] == '本月';
 	 	 	 	 	 	});
 	 	 	 	 	 	var h = _.find(component.baseOptions.datasets, function(o) {
 	 	 	 	 	 	 	 	return o[levelUniqueName] == '环比';
 	 	 	 	 	 	});
 	 	 	 	 	 	component.baseOptions.datasets = [s, b, h];
 	 	 	 	 	 	options.render = function(item, value, name, column, head) {
 	 	 	 	 	 	 	 	var o;
 	 	 	 	 	 	 	 	if (head) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	if (name == levelUniqueName) {
 	 	 	 	 	 	 	 	 	 	 	 	return '一年基盘';
 	 	 	 	 	 	 	 	 	 	} else if (name == '[Measures].[Oneyear base]') {
 	 	 	 	 	 	 	 	 	 	 	 	return '基盘数';
 	 	 	 	 	 	 	 	 	 	} else if (name == '[Measures].[Oneyear base lost]') {
 	 	 	 	 	 	 	 	 	 	 	 	return '流失数';
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	return '新增数';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	//return null;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	o = _.find(item.measures, function(_o) {
 	 	 	 	 	 	 	 	 	 	return _o.uniqueName == name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (o) {
 	 	 	 	 	 	 	 	 	 	if (item[levelUniqueName] == '环比') {
 	 	 	 	 	 	 	 	 	 	 	 	if (o.value < 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return '<span style="color:red">' + o.formatted + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	} else if (o.value > 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return '<span style="color:green">' + o.formatted + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return o.formatted;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	return o.formatted;
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return null;
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	triggerIncomeTrendLine: function(component) {
 	 	 	 	 	 	var line = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '近6个月趋势图';
 	 	 	 	 	 	});
 	 	 	 	 	 	var ui = component.$el.closest('.c-node');
 	 	 	 	 	 	$('.c-node.ipsos-selected-card').removeClass('ipsos-selected-card').find('div.arrow').remove();
 	 	 	 	 	 	if (line && line._ipsosLinkedComponent != component.id) {
 	 	 	 	 	 	 	 	line._ipsosLinkedComponent = component.id;
 	 	 	 	 	 	 	 	line.model.commit();
 	 	 	 	 	 	}
 	 	 	 	 	 	ui.addClass('ipsos-selected-card').append('<div class="arrow">');
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	incomeTrendLineCheckLinkedComponent: function(query, component) {
 	 	 	 	 	 	var id = component._ipsosLinkedComponent;
 	 	 	 	 	 	var model = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var m = {
 	 	 	 	 	 	 	 	uniqueName: '[Measures].[All income]',
 	 	 	 	 	 	 	 	name: 'All income',
 	 	 	 	 	 	 	 	type: 'EXACT'
 	 	 	 	 	 	};
 	 	 	 	 	 	var tm;
 	 	 	 	 	 	var card;
 	 	 	 	 	 	model.clearMeasures();
 	 	 	 	 	 	if (!id) {
 	 	 	 	 	 	 	 	model.includeMeasure(m);
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	card = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.id == id;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (card) {
 	 	 	 	 	 	 	 	 	 	tm = card.model.getMeasures();
 	 	 	 	 	 	 	 	 	 	tm = tm[0];
 	 	 	 	 	 	 	 	 	 	model.includeMeasure(_.isEmpty(tm) ? m : {
 	 	 	 	 	 	 	 	 	 	 	 	name: tm.value,
 	 	 	 	 	 	 	 	 	 	 	 	type: 'EXACT',
 	 	 	 	 	 	 	 	 	 	 	 	uniqueName: tm.id
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	model.includeMeasure(m);
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}
 	 	 	 	 	 	return model.get('query');
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 保养趋势图小数位和轴处理
 	 	 	 	 * @param     {[type]}                 options   [description]
 	 	 	 	 * @param     {[type]}                 component [description]
 	 	 	 	 * @return    {[type]}                           [description]
 	 	 	 	 * @time      2018-12-12T11:13:12+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	byTrendLineAxisTip: function(options, component) {
 	 	 	 	 	 	var id = component._ipsosLinkedComponent;
 	 	 	 	 	 	var card;
 	 	 	 	 	 	if (id) {
 	 	 	 	 	 	 	 	card = _.find(component.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.id == id;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (card) {
 	 	 	 	 	 	 	 	 	 	if (['首保收入', '定保收入'].indexOf(card.model.getLabel()) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	this.tip2m(options, 1000000, 'm', 1).yAxis2m(options, component);
 	 	 	 	 	 	 	 	 	 	} else if (['首保客单价', '定保客单价'].indexOf(card.model.getLabel()) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	this.tip2m(options, 1, '元', 0).yAxis2m(options, component, false, 1, '元', 0);
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	this.tip2m(options, 1, '台次', 0).yAxis2m(options, component, false, 1, '台次', 0);
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	this.tip2m(options, 1000000, 'm', 1).yAxis2m(options, component);
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	this.tip2m(options, 1000000, 'm', 1).yAxis2m(options, component);
 	 	 	 	 	 	}
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 保养收入页面初始化过程
 	 	 	 	 * @param     {[type]}                 msg [description]
 	 	 	 	 * @return    {[type]}                     [description]
 	 	 	 	 * @time      2018-12-12T14:52:09+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	initByPage: function(msg) {
 	 	 	 	 	 	var card = _.find(msg.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '首保收入' && o.type == 'ServerIndicatorCardchart';
 	 	 	 	 	 	});
 	 	 	 	 	 	card && card.$el.trigger('click');
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	funnelStyle: function(options, left, sizex) {
 	 	 	 	 	 	var get = function(datasets, key) {
 	 	 	 	 	 	 	 	return _.find(datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return !!o.name.match(key);
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	};
 	 	 	 	 	 	options.series.every(function(o) {
 	 	 	 	 	 	 	 	o.left = left || '50%';
 	 	 	 	 	 	 	 	o.funnelAlign = 'left';
 	 	 	 	 	 	 	 	o.width = sizex || '40%';
 	 	 	 	 	 	 	 	o.labelLine = {
 	 	 	 	 	 	 	 	 	 	show: false,
 	 	 	 	 	 	 	 	 	 	length: -2
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	o.sort = 'none';
 	 	 	 	 	 	 	 	o.data.every(function(item, i) {
 	 	 	 	 	 	 	 	 	 	if (i == 0) return true;
 	 	 	 	 	 	 	 	 	 	item.name += ('(' + Utility.localeNumeric(100 * item.value / this[0].value, 1) + '%)');
 	 	 	 	 	 	 	 	 	 	item.name = item.name.replace('全部', '');
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	}, o.data);
 	 	 	 	 	 	 	 	var yy = get(o.data, /邀约$/);
 	 	 	 	 	 	 	 	var lx = get(o.data, /有效联系/);
 	 	 	 	 	 	 	 	var cg = get(o.data, /呼叫成功/);
 	 	 	 	 	 	 	 	var js = get(o.data, /邀约接受/);
 	 	 	 	 	 	 	 	var jd = get(o.data, /邀约进店/);
 	 	 	 	 	 	 	 	o.data = [yy, lx, cg, js, jd];
 	 	 	 	 	 	 	 	//console.log(o.data);
 	 	 	 	 	 	 	 	return true;

 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 处理保养收入页面中漏斗图下方列表
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @param     {[type]}                 list  [description]
 	 	 	 	 * @param     {[type]}                 m     [description]
 	 	 	 	 * @param     {[type]}                 y     [description]
 	 	 	 	 * @param     {[type]}                 z     [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-12T17:30:41+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	jdMemberCalculate: function(query, list, m, y, z) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var time = _.find(list.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '月份时间轴组件';
 	 	 	 	 	 	});
 	 	 	 	 	 	var hierarchyName = '[Dim ym.default]';
 	 	 	 	 	 	var levelName = 'Mo';
 	 	 	 	 	 	var levelUniqueName = hierarchyName + '.[' + levelName + ']';
 	 	 	 	 	 	var value;
 	 	 	 	 	 	var parent;
 	 	 	 	 	 	var getMember = function(_name) {
 	 	 	 	 	 	 	 	return {
 	 	 	 	 	 	 	 	 	 	"parentMember": parent,
 	 	 	 	 	 	 	 	 	 	"parentMemberLevel": "",
 	 	 	 	 	 	 	 	 	 	"previousLevel": "",
 	 	 	 	 	 	 	 	 	 	"dimension": "Dim ym",
 	 	 	 	 	 	 	 	 	 	"name": _name,
 	 	 	 	 	 	 	 	 	 	"uniqueName": parent + ".[" + _name + "]",
 	 	 	 	 	 	 	 	 	 	"caption": _name,
 	 	 	 	 	 	 	 	 	 	"properties": {},
 	 	 	 	 	 	 	 	 	 	"formula": value,
 	 	 	 	 	 	 	 	 	 	"hierarchyName": hierarchyName,
 	 	 	 	 	 	 	 	 	 	"assignedLevel": levelUniqueName
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	};
 	 	 	 	 	 	var getHuanbi = function(hbm) {
 	 	 	 	 	 	 	 	return '((' + value + ', ' + hbm + ') - (' + value + '.PrevMember, ' + hbm + '))/(' + value + '.PrevMember, ' + hbm + ')';
 	 	 	 	 	 	};
 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', [hierarchyName]);
 	 	 	 	 	 	if (!time) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	value = time.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	value = value[0];
 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	parent = value.replace(/(\[.*\].)(\[.*\].)(\[.*\])\.(.*)/g, '$1$2$3');
 	 	 	 	 	 	component.createCalculatedMemeber(getMember('邀约进店'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('自行进店'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('总进店'))
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[邀约进店]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[自行进店]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[总进店]", hierarchyName);
 	 	 	 	 	 	component.setLevelMdxSelections({
 	 	 	 	 	 	 	 	hierarchyName: hierarchyName,
 	 	 	 	 	 	 	 	levelName: levelName,
 	 	 	 	 	 	 	 	mdx: '{' + parent + '.[邀约进店], ' + parent + '.[自行进店],' + parent + '.[总进店]}',
 	 	 	 	 	 	 	 	notify: false
 	 	 	 	 	 	}, 'ROWS');

 	 	 	 	 	 	component.clearMeasures()
 	 	 	 	 	 	 	 	.createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'客户数',
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '邀约进店', " + y + ", IIf([Dim ym.default].CurrentMember.Caption = '自行进店', " + z + ", " + m + "))", {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '#,###'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	).createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'占比',
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '邀约进店', " + y + "/" + m + ", IIf([Dim ym.default].CurrentMember.Caption = '自行进店', " + z + "/" + m + ", Null))", {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '0.0%'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	).createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'环比',
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '邀约进店', " + getHuanbi(y) + ", IIf([Dim ym.default].CurrentMember.Caption = '自行进店', " + getHuanbi(z) + ", " + getHuanbi(m) + "))", {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '0.0%'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '客户数',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '占比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: '环比',
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	jdMemberCalculateRender: function(options, baseOptions) {
 	 	 	 	 	 	var levelUniqueName = '[Dim ym.default].[Mo]';
 	 	 	 	 	 	var datasets = baseOptions.datasets;
 	 	 	 	 	 	var get = function(name) {
 	 	 	 	 	 	 	 	return _.find(datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return o[levelUniqueName] == name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	};
 	 	 	 	 	 	var zx = get('自行进店');
 	 	 	 	 	 	var zj = get('总进店');
 	 	 	 	 	 	var yy = get('邀约进店');
 	 	 	 	 	 	baseOptions.datasets = [yy, zx, zj];
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim ym.default].[Mo]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	var o = _.find(item.measures, function(_o) {
 	 	 	 	 	 	 	 	 	 	 	 	return _o.uniqueName == name;
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	if (o) {
 	 	 	 	 	 	 	 	 	 	 	 	if (['[Measures].[环比]'].indexOf(name) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (o.value < 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return '<span style="color:red">' + o.formatted + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else if (o.value > 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return '<span style="color:green">' + o.formatted + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return o.formatted;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return o.formatted;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	cgbyLinechart: function(options) {
 	 	 	 	 	 	options.series.every(function(o) {
 	 	 	 	 	 	 	 	if (o.categoryID == 'null~[Measures].[Part cnt]') {
 	 	 	 	 	 	 	 	 	 	o.name = '用量';
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	o.name = '环比';
 	 	 	 	 	 	 	 	 	 	o.type = 'line';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.legend.data = ['用量', '环比'];
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	byLinechartRadioboxUpdate: function(radio, value) {
 	 	 	 	 	 	var listeners = radio.model.getListeners() || new Array();
 	 	 	 	 	 	var model = radio.model;
 	 	 	 	 	 	var mode = __ENV.mode;
 	 	 	 	 	 	var measure = value.id;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	var id;
 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	uniqueName: '[Dim customer type.default].[定保客户]',
 	 	 	 	 	 	 	 	caption: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	uniqueName: '[Dim customer type.default].[首保客户]',
 	 	 	 	 	 	 	 	caption: ''
 	 	 	 	 	 	});
 	 	 	 	 	 	if (_.isEmpty(value)) {
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	}
 	 	 	 	 	 	id = value.id;
 	 	 	 	 	 	console.log(id);
 	 	 	 	 	 	if (id == 'none') {
 	 	 	 	 	 	 	 	list = new Array();
 	 	 	 	 	 	} else if (id == 's') {
 	 	 	 	 	 	 	 	list.splice(0, 1);
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	list.splice(1);
 	 	 	 	 	 	}
 	 	 	 	 	 	listeners.every(function(id) {
 	 	 	 	 	 	 	 	var component = model.getComponent(id);
 	 	 	 	 	 	 	 	if (component) {
 	 	 	 	 	 	 	 	 	 	__ENV.mode = 'edit';
 	 	 	 	 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', ['[Dim customer type.default]']);
 	 	 	 	 	 	 	 	 	 	if (list.length) {
 	 	 	 	 	 	 	 	 	 	 	 	component.filterValueUpdateForReadonly({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	hierarchyName: '[Dim customer type.default]',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	levelName: 'Customer type',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	caption: '客户类别',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	list: Utility.deepCopy(list)
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	__ENV.mode = mode;
 	 	 	 	 	 	 	 	 	 	component.commit();
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 转化率折线图tip框格式化
 	 	 	 	 * @param     {[type]}                 options [description]
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2018-12-13T16:11:46+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	convertRateTip: function(options) {
 	 	 	 	 	 	options.series.every(function(o) {
 	 	 	 	 	 	 	 	o.data.every(function(item) {
 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(item.value)) {
 	 	 	 	 	 	 	 	 	 	 	 	item.formatted = Utility.localeNumeric(100 * item.value, 1) + '%';
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	item.formatted = 'N/A';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},



 	 	 	 	/**
 	 	 	 	 * 漏斗图右侧各客户数
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @param     {[type]}                 list  [description]
 	 	 	 	 * @param     {[type]}                 m     [description]
 	 	 	 	 * @param     {[type]}                 y     [description]
 	 	 	 	 * @param     {[type]}                 z     [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-12T17:30:41+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	funnelRightListMembers: function(query, list, yy, yxlx, hjcg, yyjs, yyjd) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var time = _.find(list.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '月份时间轴组件';
 	 	 	 	 	 	});
 	 	 	 	 	 	var hierarchyName = '[Dim ym.default]';
 	 	 	 	 	 	var levelName = 'Mo';
 	 	 	 	 	 	var levelUniqueName = hierarchyName + '.[' + levelName + ']';
 	 	 	 	 	 	var value;
 	 	 	 	 	 	var parent;
 	 	 	 	 	 	var getMember = function(_name) {
 	 	 	 	 	 	 	 	return {
 	 	 	 	 	 	 	 	 	 	"parentMember": parent,
 	 	 	 	 	 	 	 	 	 	"parentMemberLevel": "",
 	 	 	 	 	 	 	 	 	 	"previousLevel": "",
 	 	 	 	 	 	 	 	 	 	"dimension": "Dim ym",
 	 	 	 	 	 	 	 	 	 	"name": _name,
 	 	 	 	 	 	 	 	 	 	"uniqueName": parent + ".[" + _name + "]",
 	 	 	 	 	 	 	 	 	 	"caption": _name,
 	 	 	 	 	 	 	 	 	 	"properties": {},
 	 	 	 	 	 	 	 	 	 	"formula": value,
 	 	 	 	 	 	 	 	 	 	"hierarchyName": hierarchyName,
 	 	 	 	 	 	 	 	 	 	"assignedLevel": levelUniqueName
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	};
 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', [hierarchyName]);
 	 	 	 	 	 	if (!time) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	value = time.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	value = value[0];
 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	parent = value.replace(/(\[.*\].)(\[.*\].)(\[.*\])\.(.*)/g, '$1$2$3');
 	 	 	 	 	 	component.createCalculatedMemeber(getMember('邀约客户数'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('有效联系方式客户数'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('呼叫成功客户数'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('邀约接受客户数'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('邀约进店客户数'))
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[邀约客户数]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[有效联系方式客户数]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[呼叫成功客户数]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[邀约接受客户数]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[邀约进店客户数]", hierarchyName);
 	 	 	 	 	 	component.setLevelMdxSelections({
 	 	 	 	 	 	 	 	hierarchyName: hierarchyName,
 	 	 	 	 	 	 	 	levelName: levelName,
 	 	 	 	 	 	 	 	mdx: '{' +
 	 	 	 	 	 	 	 	 	 	parent + '.[邀约客户数], ' +
 	 	 	 	 	 	 	 	 	 	parent + '.[有效联系方式客户数],' +
 	 	 	 	 	 	 	 	 	 	parent + '.[呼叫成功客户数],' +
 	 	 	 	 	 	 	 	 	 	parent + '.[邀约接受客户数],' +
 	 	 	 	 	 	 	 	 	 	parent + '.[邀约进店客户数]' +
 	 	 	 	 	 	 	 	 	 	'}',
 	 	 	 	 	 	 	 	notify: false
 	 	 	 	 	 	}, 'ROWS');

 	 	 	 	 	 	component.clearMeasures()
 	 	 	 	 	 	 	 	.createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'客户数',
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '邀约客户数', " + yy + ", " +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '有效联系方式客户数', " + yxlx + ", " +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '呼叫成功客户数', " + hjcg + ", " +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '邀约接受客户数', " + yyjs + ", " +
 	 	 	 	 	 	 	 	 	 	yyjd + "))))", {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '#,###'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	"name": "客户数",
 	 	 	 	 	 	 	 	 	 	"type": "CALCULATED"
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},



 	 	 	 	/**
 	 	 	 	 * 漏斗图底侧各转换率
 	 	 	 	 * @param     {[type]}                 query [description]
 	 	 	 	 * @param     {[type]}                 list  [description]
 	 	 	 	 * @param     {[type]}                 m     [description]
 	 	 	 	 * @param     {[type]}                 y     [description]
 	 	 	 	 * @param     {[type]}                 z     [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2018-12-12T17:30:41+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	funnelZhListMembers: function(query, list, yy, yxlx, hjcg, yyjs, yyjd) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var time = _.find(list.dashboard.components, function(o) {
 	 	 	 	 	 	 	 	return o.model.getLabel() == '月份时间轴组件';
 	 	 	 	 	 	});
 	 	 	 	 	 	var hierarchyName = '[Dim ym.default]';
 	 	 	 	 	 	var levelName = 'Mo';
 	 	 	 	 	 	var levelUniqueName = hierarchyName + '.[' + levelName + ']';
 	 	 	 	 	 	var value;
 	 	 	 	 	 	var parent;
 	 	 	 	 	 	var getMember = function(_name) {
 	 	 	 	 	 	 	 	return {
 	 	 	 	 	 	 	 	 	 	"parentMember": parent,
 	 	 	 	 	 	 	 	 	 	"parentMemberLevel": "",
 	 	 	 	 	 	 	 	 	 	"previousLevel": "",
 	 	 	 	 	 	 	 	 	 	"dimension": "Dim ym",
 	 	 	 	 	 	 	 	 	 	"name": _name,
 	 	 	 	 	 	 	 	 	 	"uniqueName": parent + ".[" + _name + "]",
 	 	 	 	 	 	 	 	 	 	"caption": _name,
 	 	 	 	 	 	 	 	 	 	"properties": {},
 	 	 	 	 	 	 	 	 	 	"formula": value,
 	 	 	 	 	 	 	 	 	 	"hierarchyName": hierarchyName,
 	 	 	 	 	 	 	 	 	 	"assignedLevel": levelUniqueName
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	};
 	 	 	 	 	 	component.clearAxisHierarchy('FILTER', [hierarchyName]);
 	 	 	 	 	 	if (!time) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	value = time.model.getDefaultsValue().value;
 	 	 	 	 	 	 	 	value = value[0];
 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	return query;
 	 	 	 	 	 	}
 	 	 	 	 	 	parent = value.replace(/(\[.*\].)(\[.*\].)(\[.*\])\.(.*)/g, '$1$2$3');
 	 	 	 	 	 	component.createCalculatedMemeber(getMember('有效联系-全部邀约'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('呼叫成功-有效联系'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('邀约接受-呼叫成功'))
 	 	 	 	 	 	 	 	.createCalculatedMemeber(getMember('邀约进店-邀约接受'))
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[有效联系-全部邀约]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[呼叫成功-有效联系]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[邀约接受-呼叫成功]", hierarchyName)
 	 	 	 	 	 	 	 	.includeCalculatedMember(parent + ".[邀约进店-邀约接受]", hierarchyName);
 	 	 	 	 	 	component.setLevelMdxSelections({
 	 	 	 	 	 	 	 	hierarchyName: hierarchyName,
 	 	 	 	 	 	 	 	levelName: levelName,
 	 	 	 	 	 	 	 	mdx: '{' +
 	 	 	 	 	 	 	 	 	 	parent + '.[有效联系-全部邀约], ' +
 	 	 	 	 	 	 	 	 	 	parent + '.[呼叫成功-有效联系],' +
 	 	 	 	 	 	 	 	 	 	parent + '.[邀约接受-呼叫成功],' +
 	 	 	 	 	 	 	 	 	 	parent + '.[邀约进店-邀约接受]' +
 	 	 	 	 	 	 	 	 	 	'}',
 	 	 	 	 	 	 	 	notify: false
 	 	 	 	 	 	}, 'ROWS');

 	 	 	 	 	 	component.clearMeasures()
 	 	 	 	 	 	 	 	.createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'本月',
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '有效联系-全部邀约', 100*" + yy + ", " +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '呼叫成功-有效联系', 100*" + yxlx + ", " +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption = '邀约接受-呼叫成功', 100*" + hjcg + ", 100*" +
 	 	 	 	 	 	 	 	 	 	yyjs + ")))", {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '#,###'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	)
 	 	 	 	 	 	 	 	.createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	'环比',
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption='有效联系-全部邀约',100*(" + yy + "-(" + value + ".PrevMember," + yy + "))/(" + value + ".PrevMember," + yy + ")," +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption='呼叫成功-有效联系',100*(" + yxlx + "-(" + value + ".PrevMember," + yxlx + "))/(" + value + ".PrevMember," + yxlx + ")," +
 	 	 	 	 	 	 	 	 	 	"IIf([Dim ym.default].CurrentMember.Caption='邀约接受-呼叫成功',100*(" + hjcg + "-(" + value + ".PrevMember," + hjcg + "))/(" + value + ".PrevMember," + hjcg + ")," +
 	 	 	 	 	 	 	 	 	 	"100*(" + yyjs + "-(" + value + ".PrevMember," + yyjs + "))/(" + value + ".PrevMember," + yyjs + "))))", {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '#,###'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	)
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	"name": "本月",
 	 	 	 	 	 	 	 	 	 	"type": "CALCULATED"
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	.includeMeasure({
 	 	 	 	 	 	 	 	 	 	"name": "环比",
 	 	 	 	 	 	 	 	 	 	"type": "CALCULATED"
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	funnelBottomListRender: function(options, baseOptions) {
 	 	 	 	 	 	var levelUniqueName = '[Dim ym.default].[Mo]';
 	 	 	 	 	 	var datasets = baseOptions.datasets;
 	 	 	 	 	 	var get = function(name) {
 	 	 	 	 	 	 	 	return _.find(datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return o[levelUniqueName] == name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	};
 	 	 	 	 	 	var yy = get('有效联系-全部邀约');
 	 	 	 	 	 	var yx = get('呼叫成功-有效联系');
 	 	 	 	 	 	var cg = get('邀约接受-呼叫成功');
 	 	 	 	 	 	var js = get('邀约进店-邀约接受');
 	 	 	 	 	 	baseOptions.datasets = [yy, yx, cg, js];
 	 	 	 	 	 	options.render = function(item, value, name, column, header) {
 	 	 	 	 	 	 	 	var text = null;
 	 	 	 	 	 	 	 	if (header) {
 	 	 	 	 	 	 	 	 	 	column.sortable = false;
 	 	 	 	 	 	 	 	 	 	switch (name) {
 	 	 	 	 	 	 	 	 	 	 	 	case '[Dim ym.default].[Mo]':
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text = '转化率';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	 	 	default:
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	var o = _.find(item.measures, function(_o) {
 	 	 	 	 	 	 	 	 	 	 	 	return _o.uniqueName == name;
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	var val;
 	 	 	 	 	 	 	 	 	 	if (o) {
 	 	 	 	 	 	 	 	 	 	 	 	if (['[Measures].[环比]'].indexOf(name) >= 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (Utility.isNumeric(o.value)) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	val = Utility.localeNumeric(o.value, 1) + '%';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (o.value < 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return '<span style="color:red">' + val + '</span>';
 	 	 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return null;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return null;
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return text;
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	extendPortraitPieLenged: function(options, size, dict) {
 	 	 	 	 	 	var base = 'image://' + location.protocol + "//" + location.hostname + ':' + location.port;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	var datasets = options.series[0].data;
 	 	 	 	 	 	var sum = 0;
 	 	 	 	 	 	dict = _.isObject(dict) && !_.isEmpty(dict) ? dict : {
 	 	 	 	 	 	 	 	'高频': {
 	 	 	 	 	 	 	 	 	 	icon: 'gaopin.png',
 	 	 	 	 	 	 	 	 	 	color: 'rgb(249, 168, 37)'
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'正常': {
 	 	 	 	 	 	 	 	 	 	icon: 'zhengchang.png',
 	 	 	 	 	 	 	 	 	 	color: 'rgb(3, 155, 229)'
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'低频': {
 	 	 	 	 	 	 	 	 	 	icon: 'dipin.png',
 	 	 	 	 	 	 	 	 	 	color: 'rgb(10, 143, 8)'
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	};
 	 	 	 	 	 	size = Utility.isNumeric(size) ? size : 40;
 	 	 	 	 	 	datasets.every(function(o) {
 	 	 	 	 	 	 	 	var name = (o && o.name ? o.name : o).replace(/\s+.*$/, '');
 	 	 	 	 	 	 	 	sum += o.value;
 	 	 	 	 	 	 	 	o.itemStyle = o.itemStyle || {};
 	 	 	 	 	 	 	 	o.itemStyle.color = dict[name].color;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	base += Utility.getWebAppName() + '/content/datafor/ui/extend components/images/';
 	 	 	 	 	 	options.legend.data.every(function(o) {
 	 	 	 	 	 	 	 	var name = (o && o.name ? o.name : o).replace(/\s+.*$/, '');
 	 	 	 	 	 	 	 	var d = _.find(datasets, function(ii) {
 	 	 	 	 	 	 	 	 	 	return ii.name.replace(/\s+.*$/, '') == name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (d) {
 	 	 	 	 	 	 	 	 	 	name = name + ' ' + (100 * d.value / sum).toFixed(0) + '%';
 	 	 	 	 	 	 	 	 	 	d.name = name;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	for (var i in dict) {
 	 	 	 	 	 	 	 	 	 	var reg = new RegExp('^' + i);
 	 	 	 	 	 	 	 	 	 	if (reg.test(name)) {
 	 	 	 	 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	name: name,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	icon: base + dict[i].icon,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	textStyle: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	color: dict[i].color,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	//fontSize: 12
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	break;
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.legend.data = list;
 	 	 	 	 	 	options.legend.itemWidth = size;
 	 	 	 	 	 	options.legend.itemHeight = size;
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	channelBarLegendFix: function(options, size) {
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	var datasets = options.series;
 	 	 	 	 	 	var sum = 0;
 	 	 	 	 	 	size = Utility.isNumeric(size) ? size : 40;
 	 	 	 	 	 	datasets.every(function(o) {
 	 	 	 	 	 	 	 	sum += o.data[0].value;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.color = ['#D0177F', '#0EBF57', '#0088FE'];
 	 	 	 	 	 	options.legend.data.every(function(o) {
 	 	 	 	 	 	 	 	var name = (o && o.name ? o.name : o).replace(/\s+.*$/, '');
 	 	 	 	 	 	 	 	var d = _.find(datasets, function(ii) {
 	 	 	 	 	 	 	 	 	 	return ii.name.replace(/\s+.*$/, '') == name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (d) {
 	 	 	 	 	 	 	 	 	 	name = name + ' ' + (100 * d.data[0].value / sum).toFixed(0) + '%';
 	 	 	 	 	 	 	 	 	 	d.name = name;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	if (/^电话/.test(name)) {
 	 	 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	 	 	name: name,
 	 	 	 	 	 	 	 	 	 	 	 	icon: 'path://M765.4,10H234.6c-56.3,0-102.1,45.8-102.1,102.1v775.8c0,56.3,45.8,102.1,102.1,102.1h530.8c56.3,0,102.1-45.8,102.1-102.1V112.1C867.5,55.8,821.7,10,765.4,10z M500,71.3c11.3,0,20.4,9.1,20.4,20.4c0,11.3-9.1,20.4-20.4,20.4c-11.3,0-20.4-9.1-20.4-20.4C479.6,80.4,488.7,71.3,500,71.3z M500,928.8c-22.6,0-40.8-18.3-40.8-40.8s18.3-40.8,40.8-40.8c22.5,0,40.8,18.3,40.8,40.8S522.5,928.8,500,928.8z M785.8,806.3c0,11.3-9.1,20.4-20.4,20.4H234.6c-11.3,0-20.4-9.1-20.4-20.4V152.9c0-11.3,9.1-20.4,20.4-20.4h530.8c11.3,0,20.4,9.1,20.4,20.4V806.3z'
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	} else if (/^微信/.test(name)) {
 	 	 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	 	 	name: name,
 	 	 	 	 	 	 	 	 	 	 	 	icon: 'path://M673.4,332.3c11.2,0,22.4,0.9,33.4,2.2c-30-148.7-179.4-259.2-350-259.2C166.2,75.3,10,213.6,10,389.2c0,101.4,52,184.6,138.8,249.1l-34.7,111l121.3-64.7c43.4,9.1,78.2,18.5,121.5,18.5c10.9,0,21.7-0.6,32.4-1.5c-6.8-24.7-10.7-50.5-10.7-77.3C378.5,463.1,508.7,332.3,673.4,332.3z M486.9,232.2c26.1,0,43.4,18.3,43.4,46.1c0,27.7-17.3,46.2-43.4,46.2c-26,0-52.1-18.5-52.1-46.2C434.8,250.5,460.9,232.2,486.9,232.2z M244.2,324.5c-26,0-52.2-18.5-52.2-46.2c0-27.8,26.2-46.1,52.2-46.1c26,0,43.3,18.3,43.3,46.1C287.5,305.9,270.2,324.5,244.2,324.5z"/><path d="M990,619.9c0-147.6-138.8-267.8-294.6-267.8c-165,0-295,120.3-295,267.8c0,147.8,130,267.8,295,267.8c34.5,0,69.4-9.2,104.1-18.5l95.1,55.4l-26.1-92.3C938.1,776.8,990,703.1,990,619.9z M599.7,573.8c-17.3,0-34.7-18.3-34.7-36.9c0-18.4,17.4-36.9,34.7-36.9c26.2,0,43.4,18.5,43.4,36.9C643.1,555.5,626,573.8,599.7,573.8z M790.5,573.8c-17.2,0-34.5-18.3-34.5-36.9c0-18.4,17.3-36.9,34.5-36.9c26,0,43.4,18.5,43.4,36.9C833.9,555.5,816.5,573.8,790.5,573.8z'
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	 	 	name: name,
 	 	 	 	 	 	 	 	 	 	 	 	icon: "path://M237.3,863.1l10.5,5.5c76.5,40.6,163.7,62,252.2,62c270.2,0,490-193.2,490-430.6c0-237.4-219.8-430.6-490-430.6C229.8,69.4,10,262.5,10,500c0,85.3,28.4,167.8,82.1,238.5l9,11.8L51.7,917.1L237.3,863.1L237.3,863.1z M343.4,500c0,37.9-30.7,68.6-68.6,68.6c-37.9,0-68.6-30.7-68.6-68.6c0-37.9,30.7-68.6,68.6-68.6C312.6,431.4,343.4,462.1,343.4,500z M583.7,500c0,37.9-30.7,68.6-68.6,68.6c-37.9,0-68.6-30.7-68.6-68.6c0-37.9,30.7-68.6,68.6-68.6C553,431.4,583.7,462.1,583.7,500z M824.1,500c0,37.9-30.7,68.6-68.6,68.6s-68.6-30.7-68.6-68.6c0-37.9,30.7-68.6,68.6-68.6S824.1,462.1,824.1,500z"
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.legend.data = list;
 	 	 	 	 	 	options.legend.itemWidth = size;
 	 	 	 	 	 	options.legend.itemHeight = size;
 	 	 	 	 	 	return this;
 	 	 	 	},


 	 	 	 	extendPortraitBarLabel: function(options, size) {
 	 	 	 	 	 	var base = location.protocol + "//" + location.hostname + ':' + location.port;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	size = Utility.isNumeric(size) ? size : 40;
 	 	 	 	 	 	options.color = ['green', '#f0f0f0'];
 	 	 	 	 	 	base += Utility.getWebAppName() + '/content/datafor/ui/extend components/images/';
 	 	 	 	 	 	options.yAxis.axisLabel = options.yAxis.axisLabel || {};
 	 	 	 	 	 	options.yAxis.axisLabel.formatter = function(value) {
 	 	 	 	 	 	 	 	var key = '';
 	 	 	 	 	 	 	 	if (value == '流失') {
 	 	 	 	 	 	 	 	 	 	key = 'a';
 	 	 	 	 	 	 	 	} else if (value == '新车') {
 	 	 	 	 	 	 	 	 	 	key = 'b';
 	 	 	 	 	 	 	 	} else if (value == '半流失') {
 	 	 	 	 	 	 	 	 	 	key = 'c';
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	key = 'd';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return '{' + key + '| } {value|' + value + '}';
 	 	 	 	 	 	};
 	 	 	 	 	 	options.yAxis.axisLabel.customized = true;
 	 	 	 	 	 	options.yAxis.axisLabel.rich = {
 	 	 	 	 	 	 	 	value: {
 	 	 	 	 	 	 	 	 	 	lineHeight: size - 10,
 	 	 	 	 	 	 	 	 	 	align: 'left'
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'a': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	align: 'left',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'liushi.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'b': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	align: 'left',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'xinche.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'c': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	align: 'center',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'banliushi.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'd': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	align: 'center',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'zhongcheng.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	};
 	 	 	 	 	 	var colors = {
 	 	 	 	 	 	 	 	'新车': '#FF9900',
 	 	 	 	 	 	 	 	'流失': '#D0177F',
 	 	 	 	 	 	 	 	'半流失': '#0EBF57',
 	 	 	 	 	 	 	 	'忠诚': '#0088FE'
 	 	 	 	 	 	};
 	 	 	 	 	 	options.series[0].data.every(function(o, i) {
 	 	 	 	 	 	 	 	o.itemStyle = o.itemStyle || {};
 	 	 	 	 	 	 	 	o.itemStyle.color = colors[o.name];
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.series[1].data.every(function(o, i) {
 	 	 	 	 	 	 	 	o.label = {
 	 	 	 	 	 	 	 	 	 	show: true,
 	 	 	 	 	 	 	 	 	 	position: 'right',
 	 	 	 	 	 	 	 	 	 	formatter: function(o) {
 	 	 	 	 	 	 	 	 	 	 	 	var m = o.data.measures;
 	 	 	 	 	 	 	 	 	 	 	 	return (100 * m[0].value / (m[0].value + m[1].value)).toFixed(2) + '%';
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	color: colors[o.name]
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	extendPortraitBarLabelA: function(options, size) {
 	 	 	 	 	 	var base = location.protocol + "//" + location.hostname + ':' + location.port;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	size = Utility.isNumeric(size) ? size : 40;
 	 	 	 	 	 	options.color = ['green', '#f0f0f0'];
 	 	 	 	 	 	base += Utility.getWebAppName() + '/content/datafor/ui/extend components/images/';
 	 	 	 	 	 	options.xAxis.axisLabel = options.xAxis.axisLabel || {};
 	 	 	 	 	 	options.xAxis.axisLabel.formatter = function(value) {
 	 	 	 	 	 	 	 	var key = '';
 	 	 	 	 	 	 	 	if (value == '上升') {
 	 	 	 	 	 	 	 	 	 	key = 'a';
 	 	 	 	 	 	 	 	} else if (value == '平稳') {
 	 	 	 	 	 	 	 	 	 	key = 'b';
 	 	 	 	 	 	 	 	} else if (value == '下降') {
 	 	 	 	 	 	 	 	 	 	key = 'c';
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	key = 'd';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return '{' + key + '| }\n{value|' + value + '}';
 	 	 	 	 	 	};
 	 	 	 	 	 	options.xAxis.axisLabel.customized = true;
 	 	 	 	 	 	options.xAxis.axisLabel.rich = {
 	 	 	 	 	 	 	 	value: {
 	 	 	 	 	 	 	 	 	 	lineHeight: size - 10,
 	 	 	 	 	 	 	 	 	 	align: 'left'
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'a': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	width: size,
 	 	 	 	 	 	 	 	 	 	align: 'left',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'shangsheng.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'b': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	align: 'left',
 	 	 	 	 	 	 	 	 	 	width: size,
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'pingwen.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'c': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	width: size,
 	 	 	 	 	 	 	 	 	 	align: 'center',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'xiajiang.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'd': {
 	 	 	 	 	 	 	 	 	 	height: size,
 	 	 	 	 	 	 	 	 	 	width: size,
 	 	 	 	 	 	 	 	 	 	align: 'center',
 	 	 	 	 	 	 	 	 	 	backgroundColor: {
 	 	 	 	 	 	 	 	 	 	 	 	image: base + 'bodong.png'
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	};
 	 	 	 	 	 	var colors = {
 	 	 	 	 	 	 	 	'上升': '#0EBF57',
 	 	 	 	 	 	 	 	'平稳': '#0088FE',
 	 	 	 	 	 	 	 	'下降': '#D0177F',
 	 	 	 	 	 	 	 	'波动': '#FF9900'
 	 	 	 	 	 	};
 	 	 	 	 	 	options.series[0].data.every(function(o, i) {
 	 	 	 	 	 	 	 	o.itemStyle = o.itemStyle || {};
 	 	 	 	 	 	 	 	o.itemStyle.color = colors[o.name];
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.series[1].data.every(function(o, i) {
 	 	 	 	 	 	 	 	o.label = {
 	 	 	 	 	 	 	 	 	 	show: true,
 	 	 	 	 	 	 	 	 	 	position: 'top',
 	 	 	 	 	 	 	 	 	 	formatter: function(o) {
 	 	 	 	 	 	 	 	 	 	 	 	var m = o.data.measures;
 	 	 	 	 	 	 	 	 	 	 	 	return (100 * m[0].value / (m[0].value + m[1].value)).toFixed(2) + '%';
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	color: colors[o.name]
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	//console.log(options);
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	extendSimpleBar: function(options) {
 	 	 	 	 	 	options.color = ['#0088FE', '#f0f0f0'];
 	 	 	 	 	 	options.series[0].itemStyle = {
 	 	 	 	 	 	 	 	barBorderRadius: 5
 	 	 	 	 	 	};
 	 	 	 	 	 	if (options.series.length > 1) {
 	 	 	 	 	 	 	 	options.series[1].label = {
 	 	 	 	 	 	 	 	 	 	show: true,
 	 	 	 	 	 	 	 	 	 	position: 'top',
 	 	 	 	 	 	 	 	 	 	formatter: function(o) {
 	 	 	 	 	 	 	 	 	 	 	 	var m = o.data.measures;
 	 	 	 	 	 	 	 	 	 	 	 	return (100 * m[0].value / (m[0].value + m[1].value)).toFixed(2) + '%';
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	fontSize: 10,
 	 	 	 	 	 	 	 	 	 	color: '#0088FE'
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	}
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	convertBarAppearent: function(options) {
 	 	 	 	 	 	options.color = ['#0EBF57', '#f0f0f0'];
 	 	 	 	 	 	options.series[0].markPoint = {
 	 	 	 	 	 	 	 	symbol: 'emptyCircle',
 	 	 	 	 	 	 	 	symbolSize: 10,
 	 	 	 	 	 	 	 	itemStyle: {
 	 	 	 	 	 	 	 	 	 	borderWidth: 3
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	data: []
 	 	 	 	 	 	};
 	 	 	 	 	 	options.series[0].data.every(function(o, i) {
 	 	 	 	 	 	 	 	this.push({
 	 	 	 	 	 	 	 	 	 	coord: [o.value, i]
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}, options.series[0].markPoint.data);
 	 	 	 	 	 	options.series[1].label = {
 	 	 	 	 	 	 	 	show: true,
 	 	 	 	 	 	 	 	position: 'right',
 	 	 	 	 	 	 	 	formatter: function(o) {
 	 	 	 	 	 	 	 	 	 	var m = o.data.measures;
 	 	 	 	 	 	 	 	 	 	return (100 * m[0].value / (m[0].value + m[1].value)).toFixed(2) + '%';
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	color: '#0EBF57'
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	miniPieLegendGap: function(options) {
 	 	 	 	 	 	var datasets = options.series[0].data;
 	 	 	 	 	 	var legend = options.legend;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	var sum = 0;
 	 	 	 	 	 	legend.itemGap = 2;
 	 	 	 	 	 	legend.itemHeight = 10;
 	 	 	 	 	 	legend.itemWidth = 10;
 	 	 	 	 	 	legend.pageIconSize = [12, 6];
 	 	 	 	 	 	datasets.every(function(o) {
 	 	 	 	 	 	 	 	sum += o.value;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	legend.data.every(function(name) {
 	 	 	 	 	 	 	 	var _name = String(_.isObject(name) && name.name ? name.name : name).split(/\s+/)[0];
 	 	 	 	 	 	 	 	var d = _.find(datasets, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.name.split(/\s+/)[0] == _name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (d) {
 	 	 	 	 	 	 	 	 	 	_name += '  ' + (100 * d.value / sum).toFixed(0) + '%';
 	 	 	 	 	 	 	 	 	 	d.name = _name;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	name: _name,
 	 	 	 	 	 	 	 	 	 	icon: 'path://M500,133.8V500H145.7c6.2,190.3,162.4,342.7,354.3,342.7c195.8,0,354.5-158.7,354.5-354.5C854.5,292.5,695.8,133.8,500,133.8z'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	legend.data = list;
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	pieLegendCustomize: function(options) {
 	 	 	 	 	 	var datasets = options.series[0].data;
 	 	 	 	 	 	var sum = 0;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	datasets.every(function(o) {
 	 	 	 	 	 	 	 	sum += o.value;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.series[0].center = ['65%', '50%'];
 	 	 	 	 	 	options.legend.data.every(function(o) {
 	 	 	 	 	 	 	 	var name = (o && o.name ? o.name : o).replace(/\s+.*$/, '');
 	 	 	 	 	 	 	 	var d = _.find(datasets, function(ii) {
 	 	 	 	 	 	 	 	 	 	return ii.name.replace(/\s+.*$/, '') == name;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (d) {
 	 	 	 	 	 	 	 	 	 	if (/有预警且更换数/.test(name)) {
 	 	 	 	 	 	 	 	 	 	 	 	name = '有预警且更换  ' + (100 * d.value / sum).toFixed(0) + '%';
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	name = '有预警且未换  ' + (100 * d.value / sum).toFixed(0) + '%';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	d.name = name;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	name: name,
 	 	 	 	 	 	 	 	 	 	icon: 'path://M455.7,838.7c-8.2,0.6-16.4,1-24.6,1.1c-108.3,1.8-217.2-38.6-299.8-121.3C5.8,593-22.1,407.2,46.7,254.4L300.3,508L508,300.3L254.4,46.7C407.2-22.2,593,5.7,718.5,131.3C847,259.7,873.2,451.3,798.2,606l152,152c53.1,53.1,53.1,139.1,0,192.2c-53.1,53.1-139.1,53.1-192.2,0l-152-152'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	options.legend.data = list;
 	 	 	 	 	 	options.legend.itemWidth = 28;
 	 	 	 	 	 	options.legend.itemHeight = 28;
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	addHuanbiLabel: function(query, _component) {
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: query
 	 	 	 	 	 	});
 	 	 	 	 	 	var m = component.getMeasures();
 	 	 	 	 	 	var len = m.length;
 	 	 	 	 	 	m.every(function(_m, i) {
 	 	 	 	 	 	 	 	var mName = '_H_' + i;
 	 	 	 	 	 	 	 	var id = _m.uniqueName || _m.id;
 	 	 	 	 	 	 	 	this.createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	mName,
 	 	 	 	 	 	 	 	 	 	'(' + id + '-([Dim ym.default].CurrentMember.PrevMember,' + id + '))/([Dim ym.default].CurrentMember.PrevMember,' + id + ')', {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '0.0%'
 	 	 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	name: mName,
 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}, component);
 	 	 	 	 	 	return component.get('query');
 	 	 	 	},

 	 	 	 	extendMulIndicatorPie: function(options, component) {
 	 	 	 	 	 	var normal = options.series[0].label.normal;
 	 	 	 	 	 	var datasets = options.series[0].data;
 	 	 	 	 	 	var reg = new RegExp("_H_");
 	 	 	 	 	 	var labels = datasets.filter(function(o) {
 	 	 	 	 	 	 	 	return !!reg.test(o.myid);
 	 	 	 	 	 	});
 	 	 	 	 	 	component.labelsArray = labels.length ? labels : component.labelsArray;
 	 	 	 	 	 	options.series[0].data = datasets.filter(function(o) {
 	 	 	 	 	 	 	 	return !reg.test(o.myid);
 	 	 	 	 	 	});
 	 	 	 	 	 	options.series[0].labelLine.length = 0;
 	 	 	 	 	 	options.series[0].labelLine.show = false;
 	 	 	 	 	 	normal.position = 'outside';
 	 	 	 	 	 	normal.color = '#666';
 	 	 	 	 	 	normal.rich = {
 	 	 	 	 	 	 	 	'green': {
 	 	 	 	 	 	 	 	 	 	color: 'green'
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	'red': {
 	 	 	 	 	 	 	 	 	 	color: 'red'
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	};
 	 	 	 	 	 	normal.formatter = function(param) {
 	 	 	 	 	 	 	 	var style = component.labelsArray[param.dataIndex].value < 0 ? 'red' : 'green';
 	 	 	 	 	 	 	 	var string = param.data.name.split('~').pop().replace(/^\s+|\s$/, '') +
 	 	 	 	 	 	 	 	 	 	' ' +
 	 	 	 	 	 	 	 	 	 	param.percent +
 	 	 	 	 	 	 	 	 	 	'%\n({' + style + '|' +
 	 	 	 	 	 	 	 	 	 	component.labelsArray[param.dataIndex].formatted + '	})';
 	 	 	 	 	 	 	 	return string;
 	 	 	 	 	 	};
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	uiActiveUpdate: function(cUI, active) {
 	 	 	 	 	 	if (active) {
 	 	 	 	 	 	 	 	cUI.parent().addClass('ipsos-selected-card').append('<div class="arrow">');
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	cUI.parent().removeClass('ipsos-selected-card').find('.arrow').remove();
 	 	 	 	 	 	}
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 初始化配件概览页水球图
 	 	 	 	 * @param     {[type]}                 chart [description]
 	 	 	 	 * @return    {[type]}                       [description]
 	 	 	 	 * @time      2019-03-01T09:33:44+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	initLiquidchart: function(chart) {
 	 	 	 	 	 	var current = chart.model.parent.getParameterCurrentValue('零件小类');
 	 	 	 	 	 	var getKeyLabel = function() {
 	 	 	 	 	 	 	 	var item = chart.model.getSelectionLevelNodes('FILTER');
 	 	 	 	 	 	 	 	var label = '';
 	 	 	 	 	 	 	 	if (!Array.isArray(item) || item.length < 1) {
 	 	 	 	 	 	 	 	 	 	return label;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	item = item[0];
 	 	 	 	 	 	 	 	if (!item || _.isEmpty(item.children) || !Array.isArray(item.children.datasets) || item.children.datasets.length < 1) {
 	 	 	 	 	 	 	 	 	 	return label;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	item = item.children.datasets[0];
 	 	 	 	 	 	 	 	label = item.caption;
 	 	 	 	 	 	 	 	return label;
 	 	 	 	 	 	};
 	 	 	 	 	 	var label = getKeyLabel();
 	 	 	 	 	 	chart.options.series.every(function(o) {
 	 	 	 	 	 	 	 	o.label.normal.formatter = o.formatted;
 	 	 	 	 	 	 	 	o.label.normal.position = ['50%', '90%'];
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	chart.$el.attr('data-label', label);
 	 	 	 	 	 	this.uiActiveUpdate(chart.$el, label == current);
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 注册配件概览页水球图click事件
 	 	 	 	 * @param     {[type]}                 dashboard [description]
 	 	 	 	 * @return    {[type]}                           [description]
 	 	 	 	 * @time      2019-03-01T09:33:04+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	addLiquidchartClickEvent: function(dashboard) {
 	 	 	 	 	 	var myself = dashboard.model.get('data');
 	 	 	 	 	 	var such = this;
 	 	 	 	 	 	dashboard.$el.on('click', '.c-ui[data-label]', function(event) {
 	 	 	 	 	 	 	 	var cNodeUi = $(event.target).closest('.c-ui');
 	 	 	 	 	 	 	 	var id = cNodeUi.attr('data-label');
 	 	 	 	 	 	 	 	var params = myself.getUserParameters();
 	 	 	 	 	 	 	 	var cNode;
 	 	 	 	 	 	 	 	if (!id) {
 	 	 	 	 	 	 	 	 	 	return;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	cNode = _.find(params, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.name == '零件小类';
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (!cNode) {
 	 	 	 	 	 	 	 	 	 	return;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	cNode.valuesArray.every(function(o) {
 	 	 	 	 	 	 	 	 	 	o.active = Boolean(o.value == id);
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	myself.updateUserParameter(cNode.id, cNode);
 	 	 	 	 	 	 	 	dashboard.$el.find('.ipsos-selected-card').removeClass('ipsos-selected-card').find('.arrow').remove();
 	 	 	 	 	 	 	 	such.uiActiveUpdate(cNodeUi, true);
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	}

 	 	};


 	 	return Logic;

});