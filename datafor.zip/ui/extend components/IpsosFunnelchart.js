define('IpsosFunnelchart', [
	'Utility',
	'BaseQueryComponent',
	'template/compile',
	'model/Component',
	'log/Log',
	'Event',
	'underscore',
	'utility/runtime',
	'Base.Panel',
	'numeral',
	'promise',
	'echartbase/EchartsBase.Panel',
	'render/Base',
	'render/Renderer'
], function(Utility, Base, compiler, Component, Log, Event, _, runtime, BasePanel, numeral, promise, EchartsPanel, Renderer) {

	var instance = new BasePanel();

	if (!runtime.getClassify('ipsos')) {
		runtime.classifyAdd({
			classify: 'ipsos',
			classifyLabel: 'IPSOS自定义组件',
			priority: 5
		});
	}

	var Chart = Base.extend({
		/**
		 * 组件类型名称，一个唯一识别字符串
		 */
		type: 'IpsosFunnelchart',

		classify: '_custom',

		/**
		 * 组件的显示名称
		 */
		name: '简易漏斗图',

		/**
		 * 组件的描述，鼠标放置在组件图标上时显示的提示内容
		 */
		description: '自定义简易漏斗图，仅供Ipsos项目使用',



		/**
		 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
		 *
		 * @author: 美神猎手
		 * @time: 2017-3-31上午11:52:49
		 */
		queryExtend: function() {
			var checkQueryModel = this.model.isValidQueryModel.bind(this.model);
			var myself = this;
			this.model.isValidQueryModel = function() {
				return checkQueryModel(true);
			};
			this.options = {};
			return this;
		},



		/**
		 * @description: 系统通知~~~~
		 * 				组件即将请求数据前的回调
		 * 重写父类方法
		 * @param     {[type]}                 msg [description]
		 * @return    {[type]}                     [description]
		 * @time      2018-12-26T14:46:07+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		beforeQuery: function(msg) {
			var preFetch = this.getCustomizeFunction('action', '_preFetch');
			var component = new Component({
				query: msg
			});
			var m = component.getMeasures();
			var len = m.length;
			m.every(function(_m, i) {
				var mName = '_ZHL_' + i;
				var cName = '_ZHLC_' + i;
				var up = _m.uniqueName || _m.id;
				var down;
				if (i < len - 1) {
					down = m[i + 1].uniqueName || m[i + 1].id;
					this.createCalculatedMeasure(mName, down + '/' + up, {
						FORMAT_STRING: '0.0%'
					}).includeMeasure({
						name: mName,
						type: 'CALCULATED'
					}).createCalculatedMeasure(
						cName,
						'[Measures].[' + mName + ']-Sum([Dim ym.default].CurrentMember.PrevMember, [Measures].[' + mName + '])', {
							FORMAT_STRING: '0.0%'
						}
					).includeMeasure({
						name: cName,
						type: 'CALCULATED'
					})
				}
				return true;
			}, component);
			msg = component.get('query');
			return _.isFunction(preFetch) ? preFetch.call(this, msg) : msg;
		},


		/**
		 * @type {[type]}
		 */
		options: null,


		/**
		 * @description: 根据指定数据配置的组件类里重写该方法
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2018-1-10上午10:41:03
		 */
		checkQm: function(rows, columns, measures) {
			this.model.hslice('COLUMNS', 0);
			this.model.hslice('ROWS', 0);
			this.model.mslice(1);
			return null;
		},


		/**
		 * 重写系统接口，当数据响应成功之后，系统将自动调用该方法
		 * 格式化响应数据，封装成Echarts组件能识别的数据格式
		 * @param     {Object}                 _data   [description]
		 * @param     {Object}                 raw     null
		 * @param     {Object}                 summary null
		 * @param     {Object}                 details null
		 * @return    {[type]}                         [description]
		 * @time      2018-09-14T17:07:42+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		dataFormatter: function(_data, raw, summary, details) {
			var customs = this.model.getCustomizations();
			var node;
			var dataNode;
			var item;
			if (
				details &&
				Array.isArray(details.children) &&
				details.children.length &&
				details.children[0].details &&
				Array.isArray(details.children[0].details.measures)
			) {
				dataNode = details.children[0].details.measures;
				this.options.data = {};
				this.options.data = dataNode.filter(function(o) {
					return !/^_ZHL/.test(o.caption);
				});
				this.options.zhl = dataNode.filter(function(o) {
					return /^_ZHL_/.test(o.caption);
				});
				this.options.zhlc = dataNode.filter(function(o) {
					return /^_ZHLC_/.test(o.caption);
				});
			} else {
				//TODO
			}
			return this;
		},

		clearContent: function() {
			this.$el.children().remove();
			this.$el.css({
				'background-image': 'none',
				'background-size': '100% 100%'
			});
			return this;
		},


		/**
		 * @return    {[type]}                        [description]
		 * @time      2018-09-25T13:36:57+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		draw: function() {
			var colors = this.options.dataColor || ['#888'];
			var container = this.$el;
			var css = new Array();
			var size;
			var zhlc = this.options.zhlc;
			this.$el.css({
				'background-image': 'url(' + Utility.getWebAppName() + '/content/datafor/ui/extend%20components/images/funnul.svg)',
				//'background-image': 'url(/pentaho/content/datafor/ui/images/extend/funnul.svg)',
				'background-size': '100% 100%'
			});
			if (this.options.dataFont && !_.isEmpty(this.options.dataFont)) {
				for (var i in this.options.dataFont) {
					css.push(i + ':' + this.options.dataFont[i]);
				}
			}
			container.children().remove();
			size = this.options.data.length;
			container.append(compiler.listCompile(this.options.data, function(item, i) {
				var color = colors[i % size] || '#888';
				return [{
					style: 'color:' + color + ';' + css.join(';'),
					html: item.formatted
				}];
			}, {
				style: 'list-style-type:none;display:flex;flex-direction:column;height:100%;margin:0px;padding:5px;'
			}, {
				style: 'text-align:center;height:100%;display:flex;flex-direction:column;justify-content:center;'
			}, null));
			container.append(compiler.listCompile(this.options.zhl, function(item, i) {
				var margin = 3 + 4.5 * i;
				var ss = zhlc[i] || {
					value: 0,
					formatted: 0
				};
				var color = ss.value < 0 ? 'red' : '#666';
				var _color = ss.value < 0 ? 'red' : 'green';
				return [{
					style: 'color:' + color + ';margin-right:' + margin + '%;',
					html: [{
						html: item.formatted,
						style: 'position:relative;top:5px;'
					}, {
						style: 'color:' + _color,
						html: '(' + ss.formatted + ')'
					}]
					//html: item.formatted + '<br><span style="color:' + _color + '">(' + ss.formatted + ')</span>'
				}];
			}, {
				style: 'list-style-type:none;display:flex;flex-direction:column;height:100%;margin:0px;padding:5% 0% 3% 0%;position:absolute;width:100%;z-index:1;top:0px;'
			}, {
				style: 'text-align:right;height:100%;display:flex;flex-direction:column;justify-content:center;'
			}, null));
			return this;
		},




		/**
		 * 系统消息，修改了页面的默认颜色
		 * @param                          {Array} colors [description]
		 * @return                         {[type]}        [description]
		 * @author:美神猎手
		 * @email:meishenlieshou@gmail.com
		 */
		colorsUpdated: function(colors) {
			//TODO
			return this;
		},

	}, {
		/**
		 * 组件图标，请指标一个可用的字体图标
		 * 默认
		 * 1. Bootstrap字体图标
		 * 2. Font-awesome字体图标
		 * 已经可用
		 * @type {String}
		 */
		thumbnail: 'icon iconfont icon-datafor-funnel',

		menus: [{
			value: 'image',
			label: Utility.locale('components', 'universal', 'save as image'),
			enable: false
		}, {
			value: 'drillReset',
			label: Utility.locale('components', 'universal', 'component reset drill'),
			enable: false,
			icon: 'fa fa-undo drill',
			dy: 5,
			top: true
		}],


		/**
		 * 组件位于组件列表中的顺序，值越大越靠后
		 * @type {Number}
		 */
		_sort_order: 24,

		/**
		 * 无数据时，组件渲染的内容，请指定了一个可用的svg文件，
		 * 该文件放置在components_symbol目录下
		 * @type {String}
		 */
		symbol: 'indicate.svg',

		/**
		 * 组件类的基本面板配置
		 */
		staticPanelOptions: _.extend([], [{
			name: 'data',
			label: Utility.locale('panel', 'data'),
			active: true,
			datasets: [
				instance.datasource(null, ['measures', 'date_dim', 'filter']),
				instance.line(),
				instance.measures(null, 'mul', false),
				instance.line(),
				instance.dimensionDate(),
				instance.line(),
				instance.filters(),
				instance.line()
			]
		}, {
			name: 'style',
			label: Utility.locale('panel', 'styles'),
			active: false,
			datasets: [
				instance.background(Utility.locale('panel', 'background color')),
				instance.border(Utility.locale('panel', 'border')),
				instance.shadow(),
				_.extend(Renderer.getRendererBaseAttrs('Font'), {
					name: '_mainfont',
					label: '指标字体',
					value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
					sizes: [6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20],
					bold: true,
					color: null,
					italic: true,
					tooltip: '漏斗图指标值的字体',
					execute: function(value, options, ui) {
						var normal = this.options.dataFont = {};
						normal['font-size'] = Number(value[0]) + 'px';
						normal['font-family'] = value[2];
						normal['font-weight'] = value[3] ? 'bold' : 'normal';
						normal['font-style'] = value[4] ? 'italic' : 'normal';
					}
				}),
				_.extend(Renderer.getRendererBaseAttrs('ColorsArray'), {
					name: '_mainColors',
					label: '指标颜色',
					tooltip: '指标的字体颜色序列',
					execute: function(value, options, ui) {
						if (!Array.isArray(value)) return;
						this.options.dataColor = value;
					}
				}),
			]
		}, {
			name: 'action',
			label: Utility.locale('panel', 'actions'),
			datasets: [
				//这一块需要抽象，不能让开发者随意修改
				instance.label(Utility.locale('panel', 'action panel', 'refresh')),
				instance.refresh(),
				instance.period(),
				instance.line(),
				instance.label(Utility.locale('panel', 'action panel', 'custom blocks')),
				instance.preExecution(),
				instance.preFetch(),
				instance.postFetch(),
				instance.postExecution()
			]
		}])
	});

	Base.register(Chart);

	return Chart;
});