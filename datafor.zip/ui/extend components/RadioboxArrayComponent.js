define('RadioboxArrayComponent', [
	'Utility',
	'underscore',
	'backbone',
	'template/compile',
	'BaseSelectComponent',
	'log/Log',
	'Base.Panel',
	'moment',
	'render/Base',
	'utility/CubeTreeNode',
	'utility/runtime',
	'render/Renderer',
	'bootstrap-select'
], function(
	Utility,
	_,
	Backbone,
	compiler,
	Base,
	Log,
	BasePanel,
	moment,
	Renderer,
	CubeTreeNode,
	runtime
) {
	var instance = new BasePanel();

	if (!runtime.getClassify('ipsos')) {
		runtime.classifyAdd({
			classify: 'ipsos',
			classifyLabel: 'IPSOS自定义组件',
			priority: 5
		});
	}

	var _radiosArray = [{
		id: 'sales income',
		label: '售后总收入',
		text: '售后总收入',
		selected: true
	}, {
		id: 'accessories income',
		label: '配件收入',
		text: '配件收入'
	}, {
		id: 'attachments income',
		label: '附件收入',
		text: '附件收入'
	}];



	var Component = Base.extend({
		/**
		 * 组件类型名称，一个唯一识别字符串
		 */
		type: 'RadioboxArrayComponent',

		classify: '_custom',

		queryRequired: false,

		/**
		 * 组件的显示名称
		 */
		name: '单选框组件',


		events: {
			'click .radio-cell': 'selectedRadioUpdated'
		},

		selectedRadioUpdated: function(event, toUpdatedValue) {
			var func = this.getCustomizeFunction('action', '_selectedPreUpdateEvent');
			var element;
			var val;
			var list = this.model.valuesAvailable;
			var old = _.find(list, function(o) {
				return o.selected;
			});
			var currentMember;
			if (event) {
				element = $(event.target).closest('.radio-cell');
				val = element.attr('data-id');
				if (element.hasClass('disabled') || old.id == val) {
					event.stopPropagation();
					event.preventDefault();
					return this;
				}
			} else {
				if (!toUpdatedValue) {
					return this;
				}
				val = toUpdatedValue;
			}
			list.every(function(item) {
				item.selected = !!(item.id == val);
				if (item.selected) {
					currentMember = Utility.deepCopy(item);
				}
				return true;
			});
			/*编辑状态下，修改选中值，需要保存状态*/
			if (!this.readonly) {
				this.model.customizationUpdate('data._active', val);
			}
			_.isFunction(func) && func.call(this, currentMember, old ? Utility.deepCopy(old) : null);
			this.selectorUpdate();
			return this;
		},


		/**
		 * 组件的描述
		 */
		description: '自定义Radiobox单选框组件',


		/**
		 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
		 *
		 * @author: 美神猎手
		 * @time: 2017-3-31上午11:52:49
		 */
		selectExtend: function() {
			var options = this.model.getCustomizations();
			var _remove = this.remove.bind(this);
			var myself = this;
			var label = '时间轴';
			this.options = {};
			//this.active_type = 'months';
			this.$el.addClass('none-border-component normal-flex').css('overflow', 'visible');
			this.remove = function() {
				//TODO
				_remove();
			};
			this.model.valuesAvailable = Utility.deepCopy(_radiosArray);
			this.getQuerySuccess({});
			return this;
		},

		/**
		 * 工具栏重置事件在组件里的代理方法
		 * @return    {[type]}                 [description]
		 * @time      2018-11-29T09:16:51+080
		 * @author 美神猎手
		 * @email     meishenlieshou@gmail.com
		 * @copyright 上海数为信息技术有限公司
		 */
		valueRestore: function() {
			var configs = this.model.getCustomizations();
			var value = configs['data._active'];
			this.selectedRadioUpdated(null, value);
			return this;
		},

		/**
		 * @description:
		 * @param cde
		 * @param raw
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2017-6-7上午10:01:23
		 */
		dataFormatter: function(cde, raw, summary) {
			//TODO
			return this;
		},

		/**
		 * @description:
		 * @param value: 选中值
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2017-6-7上午10:20:30
		 */
		selectorUpdate: function(value) {
			var postExe = this.getCustomizeFunction('action', '_postExecution');
			var configs = this.model.getCustomizations();
			var list = this.model.valuesAvailable;
			var container = this.$el.empty();
			container.append(compiler.listCompile(list, function(item) {
				return [{
					tagName: 'i',
					class: 'fa ' + (item.selected ? 'fa-dot-circle-o' : 'fa-circle-o') + ' unselectedstyle',
					style: 'cursor:pointer;'
				}, {
					tagName: 'span',
					html: item.label
				}];
			}, {
				class: 'radio-list-box',
			}, {
				class: 'radio-cell',
				'data-id': '{{id}}'
			}, function(item) {
				return true;
			}));
			container.find('.fa').css(this.options.radioStyle || {});
			container.find('span').css(this.options.labelStyle || {});
			_.isFunction(postExe) && postExe.call(this);
			return this;
		}
	}, {
		thumbnail: 'icon iconfont icon-datafor-xialakuang',
		_sort_order: 3,
		staticPanelOptions: [{
				name: 'data',
				label: Utility.locale('panel', 'data'),
				active: true,
				datasets: [
					//_.extend(Renderer.getRendererBaseAttrs('InputArray'), {
					_.extend(Renderer.getRendererBaseAttrs('ListArray'), {
						name: '_statics_list',
						label: '静态值',
						value: [{
							id: Utility.generateUUID(),
							label: '新条目'
						}],
						listeners: ['_default_active'],
						tooltip: '单选框样式设置，包括大小、颜色、是否加粗',
						execute: function(value, options, ui) {
							var backup = Utility.deepCopy(this.model.valuesAvailable);
							var list = new Array();
							//console.log(value);
							value.every(function(o) {
								var current = o.id;
								var exist = _.find(backup, function(_o) {
									return _o.id == current;
								});
								if (exist) {
									exist.label = o.label;
									list.push(exist);
								} else {
									list.push(o);
								}
								return true;
							});
							this.model.valuesAvailable = list;
							this.selectorUpdate();
						},
						init: function(model) {
							var configs = model.getCustomizations();
							var list = configs['data._statics_list'];
							var selected = configs['data._active'];
							Array.isArray(list) && list.every(function(o) {
								o.selected = (o.id == selected);
								return true;
							});
							return Array.isArray(list) ? list : undefined;
						}
					})
				]
			},
			{

				name: 'style',
				label: Utility.locale('panel', 'styles'),
				active: false,
				datasets: [
					_.extend(Renderer.getRendererBaseAttrs('Font'), {
						name: '_checked_style',
						label: '单选框',
						value: [
							16,
							'rgb(84, 105, 141)',
							'FontAwesome',
							false
						],
						families: [],
						bold: true,
						italic: false,
						tooltip: '单选框样式设置，包括大小、颜色、是否加粗',
						execute: function(value, options, ui) {
							options.radioStyle = {
								color: value[1],
								fontSize: Number(value[0]),
								fontFamily: value[2],
								fontWeight: value[3] ? 'bold' : 'normal',
							};
						}
					}),
					_.extend(Renderer.getRendererBaseAttrs('Font'), {
						name: '_label_style',
						label: '文本字体',
						value: [
							14,
							'rgb(84, 105, 141)',
							'Microsoft Yahei',
							false,
							false
						],
						bold: true,
						italic: true,
						tooltip: '单选框样式设置，包括大小、颜色、是否加粗',
						execute: function(value, options, ui) {
							options.labelStyle = {
								color: value[1],
								fontSize: Number(value[0]),
								fontFamily: value[2],
								fontWeight: value[3] ? 'bold' : 'normal',
								fontStyle: value[4] ? 'italic' : 'normal'
							};
						}
					})
				]
			}, {
				name: 'action',
				active: false,
				label: Utility.locale('panel', 'actions'),
				datasets: [
					instance.label(Utility.locale('panel', 'action panel', 'subscribers')),
					instance.subscribers(),
					instance.line(),
					instance.label(Utility.locale('panel', 'action panel', 'custom blocks')),
					{
						name: '_selectedPreUpdateEvent',
						disable: false,
						type: 'Function',
						tooltip: '当组件选中状态即将发生变化时的自定义过程',
						value: 'function preChange(value, previousValue){\n\n}',
						label: '状态变更前'
					},
					instance.postExecution()
				]
			}
		]
	});

	Base.register(Component);

	return Component;
});