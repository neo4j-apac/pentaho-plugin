define('Timelinepicker', [
	'Utility',
	'underscore',
	'backbone',
	'template/compile',
	'BaseSelectComponent',
	'log/Log',
	'Base.Panel',
	'moment',
	'render/Base',
	'utility/CubeTreeNode',
	'lib/backbone.select',
	'utility/runtime',
	'render/Renderer',
	'bootstrap-select'
], function(
	Utility,
	_,
	Backbone,
	compiler,
	Base,
	Log,
	BasePanel,
	moment,
	Renderer,
	CubeTreeNode,
	BackSelect,
	runtime
) {
	var instance = new BasePanel();

	if (!runtime.getClassify('ipsos')) {
		runtime.classifyAdd({
			classify: 'ipsos',
			classifyLabel: 'IPSOS自定义组件',
			priority: 5
		});
	}

	var timeTypes = [
		/*{
				id: 'years',
				label: '年份',
				text: '年份'
			}, {
				id: 'quarters',
				label: '季度',
				text: '季度'
			}, */
		{
			id: 'months',
			label: '月份',
			text: '月份'
		}
	];


	var datesets = (function() {
		var dict = {};
		var startYear = 2017;
		var endYear = 2018;
		var p = startYear;
		var year = new Array();
		var over;
		while (p < endYear) {
			year.push({
				id: p,
				label: p + '年'
			});
			p++;
		}
		dict.years = Utility.deepCopy(year);
		year = new Array();
		p = moment(startYear + '1', 'YYYYQ');
		over = moment(endYear + '3', 'YYYYQ').valueOf();
		while (p.valueOf() < over) {
			year.push({
				id: p.format('YYYYQ'),
				label: p.year() + '年' + p.quarter() + '季度'
			});
			p.add(1, 'quarters');
		}
		dict.quarters = Utility.deepCopy(year);
		year = new Array();
		p = moment(startYear + '-01', 'YYYY-MM');
		over = moment(endYear + '-01', 'YYYY-MM').valueOf();
		while (p.valueOf() < over) {
			year.push({
				id: p.format('YYYYMM'),
				selected: false,
				label: p.year() + '年' + (1 * p.month() + 1) + '月份'
			});
			p.add(1, 'months');
		}
		dict.months = Utility.deepCopy(year);
		return dict;
	})();

	var SelectComponent = Base.extend({
		/**
		 * 组件类型名称，一个唯一识别字符串
		 */
		type: 'TimelinePickerComponent',

		classify: '_custom',

		queryRequired: false,

		/**
		 * 组件的显示名称
		 */
		name: '时间轴组件',


		events: {
			'click .arrowi': 'shiftLocation',
			'click li.timeline-cell': 'selectedNode'
		},

		selectedNode: function(event) {
			var preChange = this.getCustomizeFunction('action', '_preChange');
			var element = $(event.target).closest('.timeline-cell');
			var id = element.find('span').attr('data-id');
			var type = this.active_type;
			var list = datesets[type];
			var old = _.find(list, function(o) {
				return !!o.selected;
			});
			list.every(function(item) {
				item.selected = Boolean(item.id == id);
				return true;
			});
			if (old && old.id == id) {
				//Not changed
				return this;
			}
			_.isFunction(preChange) && preChange.call(this, id);
			this.valueListUpdate();
			return this;
		},

		shiftLocation: function(event) {
			var container = this.$el.find('.cells-box');
			var element = $(event.target);
			var right = element.hasClass('rightarrow');
			var dx = parseFloat(container.css('left'));
			var size = parseFloat(container.width());
			var unit = parseFloat(container.find('.timeline-cell').outerWidth());
			if (!Utility.isNumeric(dx)) {
				dx = 0;
			}
			if (right) {
				dx -= unit;
			} else {
				dx += unit;
			}
			if (dx < -size) {} else if (dx <= -unit) {
				container.css('left', dx);
			} else if (dx <= 0) {
				container.css('left', 0);
			}
			return this;
		},

		/**
		 * 组件的描述
		 */
		description: '自定义时间轴组件',

		/**
		 * 强制为单选模式
		 */
		multiple: false,

		/**
		 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
		 *
		 * @author: 美神猎手
		 * @time: 2017-3-31上午11:52:49
		 */
		selectExtend: function() {
			var options = this.model.getCustomizations();
			var _remove = this.remove.bind(this);
			var myself = this;
			var label = '时间轴';
			this.active_type = 'months';
			this.$el.addClass('none-border-component normal-flex');
			this.$el.append(compiler.plainCompile([{
				tagName: 'span',
				class: 'timeline-label',
				html: '' //label
			}, {
				class: 'timelinepicker',
				html: []
			}, {
				class: 'c-table-cell scroll-list',
				html: [{
					tagName: 'i',
					class: 'arrowi leftarrow glyphicon glyphicon-chevron-left'
				}, {
					class: 'list-content'
				}, {
					tagName: 'i',
					class: 'arrowi rightarrow glyphicon glyphicon-chevron-right'
				}]
			}]));
			this.remove = function() {
				this.selview && this.selview.remove();
				_remove();
			};
			this.selview = new BackSelect({
				model: new BackSelect.Model({
					datasets: Utility.deepCopy(timeTypes),
					selected: [this.active_type],
					container: 'body',
					uuid: this.id,
					search: false,
					singleRequireSelected: true,
					multiple: !!this.multiple,
					updated: function(value) {
						var old = myself.active_type;
						var val;
						if (!value) {
							value = new Array();
						}
						val = Array.isArray(value) ? value : [value];
						if (old == val[0]) {
							return;
						}
						myself.selectedUpdate(val);
						myself.active_type = val[0];
						myself.valueListUpdate();
					},
					sizey: 34
				})
			});
			this.$el.find('.timelinepicker').append(this.selview.$el);
			this.valueListUpdate();
			return this;
		},

		valueListUpdate: function() {
			var container = this.$el.find('.list-content');
			var type = this.active_type;
			var list = Utility.deepCopy(datesets[type]);
			var selected = _.find(list, function(o) {
				return !!o.selected;
			});
			if (!selected) {
				list[0].selected = true;
			}
			container.children().remove();
			container.append(compiler.listCompile(list, function(item) {
				return [{
					tagName: 'span',
					html: item.label,
					'data-id': item.id
				}];
			}, {
				class: 'cells-box'
			}, {
				class: 'timeline-cell {{selected?"selected":""}}'
			}, function(item) {
				item.selected = !!item.selected;
				return true;
			}));
			return this;
		},

		/**
		 * @description:
		 * @param cde
		 * @param raw
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2017-6-7上午10:01:23
		 */
		dataFormatter: function(cde, raw, summary) {
			var defaults = this.model.getDefaultsValue();
			var val;
			var clone;
			if (!cde) return this;
			/*
			 * 清空历史数据
			 */
			this.valuesAvailable = new Array();
			this.model.database = new Array();
			cde.every(function(_node) {
				return (
					this.push({
						id: _node.uniqueName,
						name: _node.name,
						text: _node.caption
					}) || true
				);
			}, this.model.database);
			if (this.readonly) {
				this.model.valuesAvailable = this.model.getAvailableValues(this.model.database) || Utility.deepCopy(this.model.database);
				this.model.setValuesArray(_.extend([], this.model.valuesAvailable));
			} else {
				_.isFunction(this.model.sysAutoLink) && this.model.sysAutoLink(null, null);
			}
			return this;
		},

		/**
		 * @description:
		 * @param value: 选中值
		 * @returns {}
		 * @author: 美神猎手
		 * @time: 2017-6-7上午10:20:30
		 */
		selectorUpdate: function(value) {
			var list = new Array();
			var _val;
			this.selview.model.unset('selected', {
				silent: true
			});
			_val = Array.isArray(value) ? value : [value];
			this.selview.model.set({
				selected: _val
			});
			var defaults = this.model.getDefaultsValue();
			var clone = _.extend([], this.values);
			var list = new Array();
			this.model.setValuesArray(clone);
			if (this.readonly) return this;
			defaults.value || this.model.defaultValueUpdated([]);
			this.defUdt();
			return this;
		}
	}, {
		thumbnail: 'icon iconfont icon-datafor-xialakuang',
		_sort_order: 3,
		staticPanelOptions: [{
			name: 'action',
			active: true,
			label: Utility.locale('panel', 'actions'),
			datasets: [
				instance.label(Utility.locale('panel', 'action panel', 'subscribers')),
				_.extend(Renderer.getRendererBaseAttrs('DateSubscribers'), {
					name: '_subscribers',
					tooltip: Utility.locale('components', 'system default', 'datepicker', 'date subscription description'),
					dateType: 'days',
					save: function(value, model) {
						var list = new Array();
						if (Array.isArray(value)) list = value;
						else {
							list = [value];
						}
						model.addDateListeners(list, true);
					},
					init: function(model, item) {
						var dateType = model.getCustomizations()[
							'data._dateType'
						];
						var list = model.getDateListeners();
						item.dateType = dateType || 'days';
						return _.extend([], list);
					},
					execute: function(value, options, ui) {
						//TODO
					}
				}),
				instance.line(),
				{
					name: '_preChange',
					type: 'Function',
					disable: false,
					tooltip: '状态值变化前的自定义过程',
					value: 'function preChange(value){\n\treturn value;\n}',
					label: '变化前'
				}
			]
		}]
	});

	Base.register(SelectComponent);

	return SelectComponent;
});