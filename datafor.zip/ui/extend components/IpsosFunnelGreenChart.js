define('IpsosFunnelGreenChart', [
 	 	'Utility',
 	 	'BaseQueryComponent',
 	 	'template/compile',
 	 	'model/Component',
 	 	'log/Log',
 	 	'Event',
 	 	'underscore',
 	 	'utility/runtime',
 	 	'Base.Panel',
 	 	'numeral',
 	 	'promise',
 	 	'echartbase/EchartsBase.Panel',
 	 	'render/Base',
 	 	'render/Renderer'
], function(Utility, Base, compiler, Component, Log, Event, _, runtime, BasePanel, numeral, promise, EchartsPanel, Renderer) {

 	 	var instance = new BasePanel();

 	 	if (!runtime.getClassify('ipsos')) {
 	 	 	 	runtime.classifyAdd({
 	 	 	 	 	 	classify: 'ipsos',
 	 	 	 	 	 	classifyLabel: 'IPSOS自定义组件',
 	 	 	 	 	 	priority: 5
 	 	 	 	});
 	 	}

 	 	var Chart = Base.extend({
 	 	 	 	/**
 	 	 	 	 * 组件类型名称，一个唯一识别字符串
 	 	 	 	 */
 	 	 	 	type: 'IpsosFunnelGreenChart',

 	 	 	 	classify: '_custom',

 	 	 	 	/**
 	 	 	 	 * 组件的显示名称
 	 	 	 	 */
 	 	 	 	name: '绿色漏斗图',

 	 	 	 	/**
 	 	 	 	 * 组件的描述，鼠标放置在组件图标上时显示的提示内容
 	 	 	 	 */
 	 	 	 	description: '自定义绿色邀约漏斗图，Ipsos专用',



 	 	 	 	/**
 	 	 	 	 * @description: 创建实例时自动调用的一个方法，可以用来完成一些组件的初始化工作
 	 	 	 	 *
 	 	 	 	 * @author: 美神猎手
 	 	 	 	 * @time: 2017-3-31上午11:52:49
 	 	 	 	 */
 	 	 	 	queryExtend: function() {
 	 	 	 	 	 	var checkQueryModel = this.model.isValidQueryModel.bind(this.model);
 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	this.model.isValidQueryModel = function() {
 	 	 	 	 	 	 	 	return checkQueryModel(true);
 	 	 	 	 	 	};
 	 	 	 	 	 	this.options = {};
 	 	 	 	 	 	_.isFunction(this.funnelExtend) && this.funnelExtend();
 	 	 	 	 	 	return this;
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * 获取模型中关联上的时间维度名称
 	 	 	 	 * @return    {[type]}                 [description]
 	 	 	 	 * @time      2019-05-17T07:36:34+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	getTimeHierarchyName: function() {
 	 	 	 	 	 	var levels = this.model.getAxesLevels('FILTER');
 	 	 	 	 	 	var hierarchyName = '';
 	 	 	 	 	 	var cube = this.model.get('query').cube;
 	 	 	 	 	 	var list = Utility.getSupportedTime();
 	 	 	 	 	 	levels.every(function(o) {
 	 	 	 	 	 	 	 	var msg;
 	 	 	 	 	 	 	 	if (!o || !_.isObject(o) || _.isEmpty(o)) {
 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	msg = runtime.getLevelByUniqueName(o.id, cube, true);
 	 	 	 	 	 	 	 	if (msg && _.find(list, function(o) {
 	 	 	 	 	 	 	 	 	 	 	 	return o.type == msg.levelType;
 	 	 	 	 	 	 	 	 	 	})) {
 	 	 	 	 	 	 	 	 	 	hierarchyName = msg.hierarchyUniqueName;
 	 	 	 	 	 	 	 	 	 	return false;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return hierarchyName;
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * @description: 系统通知~~~~
 	 	 	 	 * 				组件即将请求数据前的回调
 	 	 	 	 * 重写父类方法
 	 	 	 	 * @param     {[type]}                 msg [description]
 	 	 	 	 * @return    {[type]}                     [description]
 	 	 	 	 * @time      2018-12-26T14:46:07+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	beforeQuery: function(msg) {
 	 	 	 	 	 	var preFetch = this.getCustomizeFunction('action', '_preFetch');
 	 	 	 	 	 	var component = new Component({
 	 	 	 	 	 	 	 	query: msg
 	 	 	 	 	 	});
 	 	 	 	 	 	var m = component.getMeasures();
 	 	 	 	 	 	var len = m.length;
 	 	 	 	 	 	var time = this.getTimeHierarchyName();
 	 	 	 	 	 	time && m.every(function(_m, i) {
 	 	 	 	 	 	 	 	var mName = '_ZHL_' + i;
 	 	 	 	 	 	 	 	var cName = '_ZHLC_' + i;
 	 	 	 	 	 	 	 	var up = _m.uniqueName || _m.id;
 	 	 	 	 	 	 	 	var down;
 	 	 	 	 	 	 	 	if (i < len - 1) {
 	 	 	 	 	 	 	 	 	 	down = m[i + 1].uniqueName || m[i + 1].id;
 	 	 	 	 	 	 	 	 	 	this.createCalculatedMeasure(mName, down + '/' + up, {
 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '0.0%'
 	 	 	 	 	 	 	 	 	 	}).includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: mName,
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	}).createCalculatedMeasure(
 	 	 	 	 	 	 	 	 	 	 	 	cName,
 	 	 	 	 	 	 	 	 	 	 	 	'[Measures].[' + mName + ']-Sum(' + time + '.CurrentMember.PrevMember, [Measures].[' + mName + '])', {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	FORMAT_STRING: '0.0%'
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	).includeMeasure({
 	 	 	 	 	 	 	 	 	 	 	 	name: cName,
 	 	 	 	 	 	 	 	 	 	 	 	type: 'CALCULATED'
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}, component);
 	 	 	 	 	 	msg = component.get('query');
 	 	 	 	 	 	return _.isFunction(preFetch) ? preFetch.call(this, msg) : msg;
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * @type {[type]}
 	 	 	 	 */
 	 	 	 	options: null,


 	 	 	 	/**
 	 	 	 	 * @description: 根据指定数据配置的组件类里重写该方法
 	 	 	 	 * @returns {}
 	 	 	 	 * @author: 美神猎手
 	 	 	 	 * @time: 2018-1-10上午10:41:03
 	 	 	 	 */
 	 	 	 	checkQm: function(rows, columns, measures) {
 	 	 	 	 	 	this.model.hslice('COLUMNS', 0);
 	 	 	 	 	 	this.model.hslice('ROWS', 0);
 	 	 	 	 	 	this.model.mslice(1);
 	 	 	 	 	 	return null;
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * 重写系统接口，当数据响应成功之后，系统将自动调用该方法
 	 	 	 	 * 格式化响应数据，封装成Echarts组件能识别的数据格式
 	 	 	 	 * @param     {Object}                 _data   [description]
 	 	 	 	 * @param     {Object}                 raw     null
 	 	 	 	 * @param     {Object}                 summary null
 	 	 	 	 * @param     {Object}                 details null
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2018-09-14T17:07:42+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	dataFormatter: function(_data, raw, summary, details) {
 	 	 	 	 	 	var customs = this.model.getCustomizations();
 	 	 	 	 	 	var node;
 	 	 	 	 	 	var dataNode;
 	 	 	 	 	 	var item;
 	 	 	 	 	 	if (details && Array.isArray(details.children) && details.children.length && details.children[0].details && Array.isArray(details.children[0].details.measures)) {
 	 	 	 	 	 	 	 	dataNode = details.children[0].details.measures;
 	 	 	 	 	 	 	 	this.options.data = {};
 	 	 	 	 	 	 	 	this.options.data = dataNode.filter(function(o) {
 	 	 	 	 	 	 	 	 	 	return !/^_ZHL/.test(o.caption);
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	this.options.zhl = dataNode.filter(function(o) {
 	 	 	 	 	 	 	 	 	 	return /^_ZHL_/.test(o.caption);
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	this.options.zhlc = dataNode.filter(function(o) {
 	 	 	 	 	 	 	 	 	 	return /^_ZHLC_/.test(o.caption);
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	//TODO
 	 	 	 	 	 	}
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	clearContent: function() {
 	 	 	 	 	 	this.$el.children().remove();
 	 	 	 	 	 	this.$el.css({
 	 	 	 	 	 	 	 	'background-image': 'none',
 	 	 	 	 	 	 	 	'background-size': '100% 100%'
 	 	 	 	 	 	});
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	 	 	/**
 	 	 	 	 * 计算样式
 	 	 	 	 * @param     {[type]}                 key     [description]
 	 	 	 	 * @param     {[type]}                 exclude [description]
 	 	 	 	 * @return    {[type]}                         [description]
 	 	 	 	 * @time      2019-05-17T07:47:29+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	getGeneratedStyle: function(key, exclude) {
 	 	 	 	 	 	var attrs = _.isObject(exclude) && !_.isEmpty(exclude) ? exclude : {};
 	 	 	 	 	 	var dict = Utility.deepCopy(this.options[key || 'dataFont'] || {});
 	 	 	 	 	 	var css = new Array();
 	 	 	 	 	 	dict = _.extend(dict, attrs);
 	 	 	 	 	 	for (var i in dict) {
 	 	 	 	 	 	 	 	css.push(i + ':' + dict[i]);
 	 	 	 	 	 	}
 	 	 	 	 	 	return css.join(';');
 	 	 	 	},


 	 	 	 	/**
 	 	 	 	 * @return    {[type]}                        [description]
 	 	 	 	 * @time      2018-09-25T13:36:57+080
 	 	 	 	 * @author 美神猎手
 	 	 	 	 * @email     meishenlieshou@gmail.com
 	 	 	 	 * @copyright 上海数为信息技术有限公司
 	 	 	 	 */
 	 	 	 	draw: function() {
 	 	 	 	 	 	var data = this.options.data || new Array();
 	 	 	 	 	 	var container = this.$el;
 	 	 	 	 	 	//var css = new Array();
 	 	 	 	 	 	var size;
 	 	 	 	 	 	var zhlc = this.options.zhlc;
 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	this.$el.css({
 	 	 	 	 	 	 	 	'background-image': 'url(' + Utility.getWebAppName() + '/content/datafor/ui/extend%20components/images/funnel_green.svg)',
 	 	 	 	 	 	 	 	'background-size': 'auto 100%',
 	 	 	 	 	 	 	 	'background-repeat': 'no-repeat',
 	 	 	 	 	 	 	 	'background-position-x': '15%'
 	 	 	 	 	 	});

 	 	 	 	 	 	container.children().remove();
 	 	 	 	 	 	size = this.options.data.length;
 	 	 	 	 	 	list = [{
 	 	 	 	 	 	 	 	formatted: data[0] ? data[0].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont')
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[0] ? data[0].caption : '',
 	 	 	 	 	 	 	 	style: "color:white;font-size:14px"
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[1] ? data[1].formatted : '',
 	 	 	 	 	 	 	 	right: data[1] ? data[1].caption : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont'),
 	 	 	 	 	 	 	 	size: '34%'
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[2] ? data[2].formatted : '',
 	 	 	 	 	 	 	 	right: data[2] ? data[2].caption : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont'),
 	 	 	 	 	 	 	 	size: '37%'
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[3] ? data[3].formatted : '',
 	 	 	 	 	 	 	 	right: data[3] ? data[3].caption : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont'),
 	 	 	 	 	 	 	 	size: '40%'
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: ''
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[4] ? data[4].formatted : '',
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('keyFont')
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	formatted: data[4] ? data[4].caption : '',
 	 	 	 	 	 	 	 	style: "color:white;font-size:14px"
 	 	 	 	 	 	}];
 	 	 	 	 	 	container.append(compiler.listCompile(list, function(item, i) {
 	 	 	 	 	 	 	 	if (item.right) {
 	 	 	 	 	 	 	 	 	 	return [{
 	 	 	 	 	 	 	 	 	 	 	 	style: item.style,
 	 	 	 	 	 	 	 	 	 	 	 	class: 'center-text-value',
 	 	 	 	 	 	 	 	 	 	 	 	html: item.formatted
 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	style: myself.getGeneratedStyle('labelFont', {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	width: item.size
 	 	 	 	 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	 	 	 	 	class: 'right-label-name',
 	 	 	 	 	 	 	 	 	 	 	 	html: [{
 	 	 	 	 	 	 	 	 	 	 	 	 	 	tagName: 'i'
 	 	 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	tagName: 'span',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	html: item.right
 	 	 	 	 	 	 	 	 	 	 	 	}]
 	 	 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	return [{
 	 	 	 	 	 	 	 	 	 	 	 	style: item.style,
 	 	 	 	 	 	 	 	 	 	 	 	class: 'center-text-value',
 	 	 	 	 	 	 	 	 	 	 	 	html: item.formatted
 	 	 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	class: 'funnel-green-text-ul',
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	style: 'min-height:{{sizey}};max-height:{{sizey}};flex-direction:{{h?"row":"column"}};'
 	 	 	 	 	 	}, function(item, i) {
 	 	 	 	 	 	 	 	var childy = ['13%', '13%', '14%', '3%', '13%', '4%', '12%', '3%', '10%', '14%', ];
 	 	 	 	 	 	 	 	item.sizey = childy[i];
 	 	 	 	 	 	 	 	item.element_index = i;
 	 	 	 	 	 	 	 	item.h = !!item.right;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}));
 	 	 	 	 	 	list = Utility.deepCopy(this.options.zhl.slice(0, this.options.zhl.length - 1));
 	 	 	 	 	 	container.append(compiler.listCompile(list, function(item, i) {
 	 	 	 	 	 	 	 	var margin = 3 + 4.5 * i;
 	 	 	 	 	 	 	 	var ss = zhlc[i] || {
 	 	 	 	 	 	 	 	 	 	value: 0,
 	 	 	 	 	 	 	 	 	 	formatted: 0
 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	var color = myself.options.dataFont.color;
 	 	 	 	 	 	 	 	var _color = ss.value < 0 ? 'red' : 'green';
 	 	 	 	 	 	 	 	var symbol = '';
 	 	 	 	 	 	 	 	if (ss.value > 0) {
 	 	 	 	 	 	 	 	 	 	symbol = '+';
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return [{
 	 	 	 	 	 	 	 	 	 	html: [{
 	 	 	 	 	 	 	 	 	 	 	 	html: item.formatted,
 	 	 	 	 	 	 	 	 	 	 	 	style: 'position:relative;top:5px;color:' + color
 	 	 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	 	 	style: 'color:' + _color,
 	 	 	 	 	 	 	 	 	 	 	 	html: symbol + ss.formatted
 	 	 	 	 	 	 	 	 	 	}]
 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	class: 'changed-label-text',
 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	style: this.getGeneratedStyle('dataFont') + ';top:{{y}};justify-content:center;position:absolute;left:{{x}}'
 	 	 	 	 	 	}, function(item, i) {
 	 	 	 	 	 	 	 	var x = ['8%', '11%', '13%'];
 	 	 	 	 	 	 	 	var y = ['21%', '38%', '54%'];
 	 	 	 	 	 	 	 	item.x = x[i];
 	 	 	 	 	 	 	 	item.y = y[i];
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	}));
 	 	 	 	 	 	return this;
 	 	 	 	},




 	 	 	 	/**
 	 	 	 	 * 系统消息，修改了页面的默认颜色
 	 	 	 	 * @param                          {Array} colors [description]
 	 	 	 	 * @return                         {[type]}        [description]
 	 	 	 	 * @author:美神猎手
 	 	 	 	 * @email:meishenlieshou@gmail.com
 	 	 	 	 */
 	 	 	 	colorsUpdated: function(colors) {
 	 	 	 	 	 	//TODO
 	 	 	 	 	 	return this;
 	 	 	 	},

 	 	}, {
 	 	 	 	/**
 	 	 	 	 * 组件图标，请指标一个可用的字体图标
 	 	 	 	 * 默认
 	 	 	 	 * 1. Bootstrap字体图标
 	 	 	 	 * 2. Font-awesome字体图标
 	 	 	 	 * 已经可用
 	 	 	 	 * @type {String}
 	 	 	 	 */
 	 	 	 	thumbnail: 'icon iconfont icon-datafor-funnel',

 	 	 	 	menus: [{
 	 	 	 	 	 	value: 'image',
 	 	 	 	 	 	label: Utility.locale('components', 'universal', 'save as image'),
 	 	 	 	 	 	enable: false
 	 	 	 	}, {
 	 	 	 	 	 	value: 'drillReset',
 	 	 	 	 	 	label: Utility.locale('components', 'universal', 'component reset drill'),
 	 	 	 	 	 	enable: false,
 	 	 	 	 	 	icon: 'fa fa-undo drill',
 	 	 	 	 	 	dy: 5,
 	 	 	 	 	 	top: true
 	 	 	 	}],


 	 	 	 	/**
 	 	 	 	 * 组件位于组件列表中的顺序，值越大越靠后
 	 	 	 	 * @type {Number}
 	 	 	 	 */
 	 	 	 	_sort_order: 24,

 	 	 	 	/**
 	 	 	 	 * 无数据时，组件渲染的内容，请指定了一个可用的svg文件，
 	 	 	 	 * 该文件放置在components_symbol目录下
 	 	 	 	 * @type {String}
 	 	 	 	 */
 	 	 	 	symbol: 'indicate.svg',

 	 	 	 	/**
 	 	 	 	 * 组件类的基本面板配置
 	 	 	 	 */
 	 	 	 	staticPanelOptions: _.extend([], [{
 	 	 	 	 	 	name: 'data',
 	 	 	 	 	 	label: Utility.locale('panel', 'data'),
 	 	 	 	 	 	active: true,
 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	instance.datasource(null, ['measures', 'date_dim', 'filter']),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.measures(null, 'mul', false),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.dimensionDate(),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.filters(),
 	 	 	 	 	 	 	 	instance.line()
 	 	 	 	 	 	]
 	 	 	 	}, {
 	 	 	 	 	 	name: 'style',
 	 	 	 	 	 	label: Utility.locale('panel', 'styles'),
 	 	 	 	 	 	active: false,
 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	instance.background(Utility.locale('panel', 'background color')),
 	 	 	 	 	 	 	 	instance.border(Utility.locale('panel', 'border')),
 	 	 	 	 	 	 	 	instance.shadow(),
 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	name: '_mainfont',
 	 	 	 	 	 	 	 	 	 	label: '指标字体',
 	 	 	 	 	 	 	 	 	 	value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	sizes: [12, 14, 16, 18, 20],
 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	//color: null,
 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	tooltip: '漏斗图指标值的字体',
 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	var normal = this.options.dataFont = {};
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-size'] = Number(value[0]) + 'px';
 	 	 	 	 	 	 	 	 	 	 	 	normal['color'] = value[1];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-family'] = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-weight'] = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-style'] = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	name: '_lastfont',
 	 	 	 	 	 	 	 	 	 	label: '关键指标字体',
 	 	 	 	 	 	 	 	 	 	value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	sizes: [12, 14, 16, 18, 20, 24, 28],
 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	//color: null,
 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	tooltip: '漏斗图最后一个指标的字体样式',
 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	var normal = this.options.keyFont = {};
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-size'] = Number(value[0]) + 'px';
 	 	 	 	 	 	 	 	 	 	 	 	normal['color'] = value[1];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-family'] = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-weight'] = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-style'] = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	}),
 	 	 	 	 	 	 	 	_.extend(Renderer.getRendererBaseAttrs('Font'), {
 	 	 	 	 	 	 	 	 	 	name: '_labelfont',
 	 	 	 	 	 	 	 	 	 	label: '标签字体',
 	 	 	 	 	 	 	 	 	 	value: [12, 'rgb(84, 105, 141)', 'Microsoft Yahei', false, false],
 	 	 	 	 	 	 	 	 	 	sizes: [12, 14, 16, 18, 20, 24, 28],
 	 	 	 	 	 	 	 	 	 	bold: true,
 	 	 	 	 	 	 	 	 	 	//color: null,
 	 	 	 	 	 	 	 	 	 	italic: true,
 	 	 	 	 	 	 	 	 	 	tooltip: '漏斗图右侧标签字体样式',
 	 	 	 	 	 	 	 	 	 	execute: function(value, options, ui) {
 	 	 	 	 	 	 	 	 	 	 	 	var normal = this.options.labelFont = {};
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-size'] = Number(value[0]) + 'px';
 	 	 	 	 	 	 	 	 	 	 	 	normal['color'] = value[1];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-family'] = value[2];
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-weight'] = value[3] ? 'bold' : 'normal';
 	 	 	 	 	 	 	 	 	 	 	 	normal['font-style'] = value[4] ? 'italic' : 'normal';
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	]
 	 	 	 	}, {
 	 	 	 	 	 	name: 'action',
 	 	 	 	 	 	label: Utility.locale('panel', 'actions'),
 	 	 	 	 	 	datasets: [
 	 	 	 	 	 	 	 	//这一块需要抽象，不能让开发者随意修改
 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'refresh')),
 	 	 	 	 	 	 	 	instance.refresh(),
 	 	 	 	 	 	 	 	instance.period(),
 	 	 	 	 	 	 	 	instance.line(),
 	 	 	 	 	 	 	 	instance.label(Utility.locale('panel', 'action panel', 'custom blocks')),
 	 	 	 	 	 	 	 	instance.preExecution(),
 	 	 	 	 	 	 	 	instance.preFetch(),
 	 	 	 	 	 	 	 	instance.postFetch(),
 	 	 	 	 	 	 	 	instance.postExecution()
 	 	 	 	 	 	]
 	 	 	 	}])
 	 	});

 	 	Base.register(Chart);

 	 	return Chart;
});