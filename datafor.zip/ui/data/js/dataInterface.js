$(function() {
 	 	var Utility = require('Utility');
 	 	var $ = require('jquery');
 	 	var CodeMirror = require('codemirror');
 	 	var javaScript = require('javascript');
 	 	var placeholder = require('placeholder');
 	 	var Saiku = require('model/Saiku');
 	 	var Component = require('model/Component');
 	 	var Dashboard = require('model/Dashboard')
 	 	var Events = require('Event');
 	 	var Convert = require('lib/saiku.data.convert');
 	 	var Selector = require('lib/backbone.select');
 	 	var Loader = require('Loader');
 	 	var DUtility = require('echartbase/Echart_cda');
 	 	var CubeTreeNode = require('utility/CubeTreeNode');
 	 	require('vim');
 	 	require('pqgrid');
 	 	$('.load-mask').remove();

 	 	require('mdx');

 	 	var Service = {
 	 	 	 	analyseUrl: function() {
 	 	 	 	 	 	var search = decodeURI(window.location.search);
 	 	 	 	 	 	var dict = {};
 	 	 	 	 	 	var string = search.substr(1);
 	 	 	 	 	 	var paramslist = string.split('&');
 	 	 	 	 	 	paramslist.every(function(o) {
 	 	 	 	 	 	 	 	var keyvalue = o.split('=');
 	 	 	 	 	 	 	 	var key = keyvalue[0];
 	 	 	 	 	 	 	 	var val = keyvalue[1];
 	 	 	 	 	 	 	 	dict[key] = val;
 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	});
 	 	 	 	 	 	return dict;
 	 	 	 	}
 	 	};
 	 	var params = Service.analyseUrl();
 	 	var isMdxMode = (params.__mdx || params.__mdx == 'true');

 	 	var backQuery;

 	 	var settings = {
 	 	 	 	pageModel: {
 	 	 	 	 	 	type: 'local',
 	 	 	 	 	 	rPP: 100,
 	 	 	 	 	 	strRpp: '{0}',
 	 	 	 	 	 	strDisplay: '{0} to {1} of {2}'
 	 	 	 	},
 	 	 	 	width: '100%',
 	 	 	 	height: '100%',
 	 	 	 	refresh: function(event, ui) {
 	 	 	 	 	 	var styles = myself.options.style;
 	 	 	 	 	 	var frozens = styles._frozens || 0;
 	 	 	 	 	 	var summaryAll = myself.$el.find('td.frozen-cols.smy_col_all');
 	 	 	 	 	 	var shouldRemove = Utility.isNumeric(frozens) && frozens > 0;
 	 	 	 	 	 	var labelNames = Utility.deepCopy(myself.baseOptions.labelNames);
 	 	 	 	 	 	var len = labelNames.length;
 	 	 	 	 	 	summaryAll.each(function(indx, o) {
 	 	 	 	 	 	 	 	if (indx == 0) {
 	 	 	 	 	 	 	 	 	 	$(this).attr('colspan', len);
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	shouldRemove || $(this).remove();
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	});
 	 	 	 	},
 	 	 	 	selectionModel: {
 	 	 	 	 	 	type: 'cell',
 	 	 	 	 	 	mode: 'single'
 	 	 	 	},
 	 	 	 	beforeTableView: function(event, ui) {
 	 	 	 	 	 	// var filters = new Array();
 	 	 	 	 	 	// var array = Utility.deepCopy(ui.pageData);
 	 	 	 	 	 	// ui.pageData.splice(0);
 	 	 	 	 	 	// array.every(function(item) {
 	 	 	 	 	 	// 	var o = {};
 	 	 	 	 	 	// 	for (var i in item) {
 	 	 	 	 	 	// 		//if (!!i && i != undefined && i != 'undefined' && !isSubSummaryCell(String(item[i] || ""))) {
 	 	 	 	 	 	// 		if (!!i && i != undefined && i != 'undefined') {
 	 	 	 	 	 	// 			o[i] = item[i];
 	 	 	 	 	 	// 		}
 	 	 	 	 	 	// 	}
 	 	 	 	 	 	// 	this.push(o);
 	 	 	 	 	 	// 	return true;
 	 	 	 	 	 	// }, ui.pageData);
 	 	 	 	},
 	 	 	 	cellClick: function(event, ui) {
 	 	 	 	 	 	var msg = Parse.getCellLevelsReferred(myself.details, ui.rowData, ui.dataIndx, myself);
 	 	 	 	 	 	var cell_click_listener = myself.getCustomizeFunction('action', '_cell_click');
 	 	 	 	 	 	var ret;
 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	msg.measures[0].value = ui.rowData[ui.dataIndx].value || '';
 	 	 	 	 	 	 	 	msg.measures[0].formatted = ui.rowData[ui.dataIndx].formatted || '';
 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	//TODO
 	 	 	 	 	 	}
 	 	 	 	 	 	if (_.isFunction(cell_click_listener)) {
 	 	 	 	 	 	 	 	ret = cell_click_listener.call(myself, {
 	 	 	 	 	 	 	 	 	 	rowData: Utility.deepCopy(ui.rowData),
 	 	 	 	 	 	 	 	 	 	position: {
 	 	 	 	 	 	 	 	 	 	 	 	y: ui.rowIndx,
 	 	 	 	 	 	 	 	 	 	 	 	x: ui.colIndx
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	id: ui.dataIndx,
 	 	 	 	 	 	 	 	 	 	message: Utility.deepCopy(msg)
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	}
 	 	 	 	 	 	if (ret != false) {
 	 	 	 	 	 	 	 	/*暂时只支持数据单元格上的交互*/
 	 	 	 	 	 	 	 	//myself.triggerLinkMenus({
 	 	 	 	 	 	 	 	msg.detailNode && myself.triggerLinkMenus({
 	 	 	 	 	 	 	 	 	 	x: event.clientX,
 	 	 	 	 	 	 	 	 	 	y: event.clientY
 	 	 	 	 	 	 	 	}, {
 	 	 	 	 	 	 	 	 	 	levels: msg.levels,
 	 	 	 	 	 	 	 	 	 	measures: msg.measures
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	}
 	 	 	 	},
 	 	 	 	headerCellClick: function(event, ui) {
 	 	 	 	 	 	/*暂时不支持表头上的交互*/
 	 	 	 	 	 	// var msg = Parse.getCellLevelsReferred(myself.details, ui.rowData, ui.dataIndx, myself);
 	 	 	 	 	 	// try {
 	 	 	 	 	 	// 	msg.measures[0].value = ui.rowData[ui.dataIndx];
 	 	 	 	 	 	// } catch (e) {
 	 	 	 	 	 	// 	//TODO
 	 	 	 	 	 	// }
 	 	 	 	 	 	// myself.triggerLinkMenus({
 	 	 	 	 	 	// 	x: event.clientX,
 	 	 	 	 	 	// 	y: event.clientY
 	 	 	 	 	 	// }, {
 	 	 	 	 	 	// 	levels: msg.levels,
 	 	 	 	 	 	// 	measures: msg.measures
 	 	 	 	 	 	// });
 	 	 	 	},
 	 	 	 	resizable: false,
 	 	 	 	sortModel: {
 	 	 	 	 	 	single: false,
 	 	 	 	 	 	//                sorter: [{ dataIndx: 'ShipCountry', dir: 'up' }, { dataIndx: 'ContactName', dir: 'down'}],
 	 	 	 	 	 	sorter: [],
 	 	 	 	 	 	space: true,
 	 	 	 	 	 	multiKey: null,
 	 	 	 	 	 	type: 'local'
 	 	 	 	},
 	 	 	 	stripeRows: true,
 	 	 	 	editable: false,
 	 	 	 	title: null,
 	 	 	 	labelNames: [],
 	 	 	 	collapsible: {
 	 	 	 	 	 	on: false,
 	 	 	 	 	 	toggle: false
 	 	 	 	},
 	 	 	 	dragColumns: {
 	 	 	 	 	 	enabled: false
 	 	 	 	},
 	 	 	 	showTitle: false,
 	 	 	 	postRenderInterval: 200,
 	 	 	 	flex: {
 	 	 	 	 	 	one: true
 	 	 	 	},
 	 	 	 	bootstrap: {
 	 	 	 	 	 	on: true
 	 	 	 	},
 	 	 	 	showBottom: true,
 	 	 	 	mergeCells: [],
 	 	 	 	wrap: false,
 	 	 	 	hwrap: false,
 	 	 	 	scrollModel: {
 	 	 	 	 	 	autoFit: false,
 	 	 	 	 	 	horizontal: true
 	 	 	 	},
 	 	 	 	dataModel: {
 	 	 	 	 	 	data: null
 	 	 	 	},
 	 	 	 	numberCell: {
 	 	 	 	 	 	show: false
 	 	 	 	}
 	 	};


 	 	if (isMdxMode) {
 	 	 	 	$('button.apply').html('提交（MDX）');
 	 	} else {
 	 	 	 	$('button.apply').html('提交（QUERYMODEL）');
 	 	}


 	 	(function(baseQuery, baseMDX) {


 	 	 	 	var UI = {

 	 	 	 	 	 	cubeList: new Array(),

 	 	 	 	 	 	metadata: {},

 	 	 	 	 	 	cube: {},

 	 	 	 	 	 	getValidLevelNode: function(dimensions) {
 	 	 	 	 	 	 	 	var msg = null;
 	 	 	 	 	 	 	 	dimensions.every(function(dim) {
 	 	 	 	 	 	 	 	 	 	var hierarchies = dim.hierarchies;
 	 	 	 	 	 	 	 	 	 	if (Array.isArray(dim.hierarchies) && dim.hierarchies.length) {
 	 	 	 	 	 	 	 	 	 	 	 	dim.hierarchies.every(function(hierarchy) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	var levelNode;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (Array.isArray(hierarchy.levels) && hierarchy.levels.length > 1) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg = {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg.name = hierarchy.uniqueName;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	levelNode = hierarchy.levels[hierarchy.levels.length - 1];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg.levels = {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg.cmembers = {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg.filters = [];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg.levels[levelNode.name] = {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	name: levelNode.name,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	caption: levelNode.caption,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	mdx: null,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	selection: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	type: 'INCLUSION',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	members: [],
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	parameterName: null
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	aggregators: null,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	filters: []
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return !msg;
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	return !msg;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return msg;
 	 	 	 	 	 	},




 	 	 	 	 	 	datasourceUpdate: function(value) {
 	 	 	 	 	 	 	 	var id = Array.isArray(value) ? value[0] : value;
 	 	 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	 	 	var cube;
 	 	 	 	 	 	 	 	if (!id) {
 	 	 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	data: "没有选中数据源"
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	cube = _.find(this.cubeList, function(o) {
 	 	 	 	 	 	 	 	 	 	return o.uniqueName == id;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	if (!cube) {
 	 	 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	data: "没有找到对应的数据源"
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	this.loader = new Loader();
 	 	 	 	 	 	 	 	this.cube = Utility.deepCopy(cube);
 	 	 	 	 	 	 	 	new CubeTreeNode({
 	 	 	 	 	 	 	 	 	 	cube: cube
 	 	 	 	 	 	 	 	}).getNodes(function(data) {
 	 	 	 	 	 	 	 	 	 	baseQuery = Utility.deepCopy(backQuery);
 	 	 	 	 	 	 	 	 	 	myself.loader && myself.loader.remove();
 	 	 	 	 	 	 	 	 	 	baseQuery.cube = Utility.deepCopy(cube);
 	 	 	 	 	 	 	 	 	 	if (!data || !Array.isArray(data.dimensions) || !Array.isArray(data.measures)) {
 	 	 	 	 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	data: "数据源可能已经损坏"
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	return;
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	baseQuery.queryModel.axes.ROWS.hierarchies = [myself.getValidLevelNode(data.dimensions)];
 	 	 	 	 	 	 	 	 	 	if (data.measures.length) {
 	 	 	 	 	 	 	 	 	 	 	 	baseQuery.queryModel.details.measures = [{
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"caption": data.measures[0].caption,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"name": data.measures[0].name,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"uniqueName": data.measures[0].uniqueName,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"type": "EXACT"
 	 	 	 	 	 	 	 	 	 	 	 	}];
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	data: "数据源中没有指标"
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	myself.metadata = data || {};
 	 	 	 	 	 	 	 	 	 	myself.contentUpdate();
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	},

 	 	 	 	 	 	getDatasourcesList: function(callback) {
 	 	 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	 	 	this.cubeList = new Array();
 	 	 	 	 	 	 	 	//$.get(Utility.getURL('CUBES'), function(data) {
 	 	 	 	 	 	 	 	$.get(Utility.getURL('MODELS_LIST'), function(data) {
 	 	 	 	 	 	 	 	 	 	var list = new Array();
 	 	 	 	 	 	 	 	 	 	Array.isArray(data) && data.every(function(connection) {
 	 	 	 	 	 	 	 	 	 	 	 	Array.isArray(connection.catalogs) && connection.catalogs.every(function(catalog) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	Array.isArray(catalog.schemas) && catalog.schemas.every(function(schema) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	Array.isArray(schema.cubes) && schema.cubes.every(function(cube) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	myself.cubeList.push(Utility.deepCopy(cube));
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	list.push({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	id: cube.uniqueName,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	text: cube.schema + ' -> ' + cube.caption,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	name: cube.name
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	myself.selector.model.unset('datasets', {
 	 	 	 	 	 	 	 	 	 	 	 	silent: true
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	myself.selector.model.set('datasets', list);
 	 	 	 	 	 	 	 	 	 	_.isFunction(callback) && callback(list);
 	 	 	 	 	 	 	 	 	 	myself.loader && myself.loader.remove();
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	},

 	 	 	 	 	 	getValidUniqueName: function(dimensions) {
 	 	 	 	 	 	 	 	var msg = null;
 	 	 	 	 	 	 	 	dimensions.every(function(dim) {
 	 	 	 	 	 	 	 	 	 	var hierarchies = dim.hierarchies;
 	 	 	 	 	 	 	 	 	 	if (Array.isArray(dim.hierarchies) && dim.hierarchies.length) {
 	 	 	 	 	 	 	 	 	 	 	 	dim.hierarchies.every(function(hierarchy) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	var levelNode;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (Array.isArray(hierarchy.levels) && hierarchy.levels.length > 1) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	levelNode = hierarchy.levels[hierarchy.levels.length - 1];
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	msg = levelNode.uniqueName;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	return !msg;
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	return !msg;
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	return msg;
 	 	 	 	 	 	},

 	 	 	 	 	 	getSampleMDX: function() {
 	 	 	 	 	 	 	 	var uniqueName = this.getValidUniqueName(this.metadata.dimensions);
 	 	 	 	 	 	 	 	var mUniqueName = this.metadata.measures[0].uniqueName;
 	 	 	 	 	 	 	 	var cubeName = this.cube.name;
 	 	 	 	 	 	 	 	var mdx = "WITH SET [~ROWS] AS {" + uniqueName + ".Members} \n" +
 	 	 	 	 	 	 	 	 	 	"SELECT \n" +
 	 	 	 	 	 	 	 	 	 	"\tNON EMPTY {" + mUniqueName + "} ON COLUMNS, \n" +
 	 	 	 	 	 	 	 	 	 	"\tNON EMPTY [~ROWS] ON ROWS \n" +
 	 	 	 	 	 	 	 	 	 	"FROM [" + cubeName + "]";
 	 	 	 	 	 	 	 	// return 'WITH SET [~dim_company_dim_company.dim_company_dq_name] AS     Filter({[dim_company].[dq_name].Members}, ([dim_company].CurrentMember IN {[dim_company].[北大区]})) SET [~dim_company_dim_company.dim_company_xq_name] AS     Exists(Filter({[dim_company].[xq_name].Members}, ([dim_company].CurrentMember IN {[dim_company].[北大区].[北三区]})), [~dim_company_dim_company.dim_company_dq_name]) SET [~COLUMNS] AS     {[dim_company.dim_dealer].[dealer_scale_nm].Members} MEMBER [Measures].[配件收入占比] AS     ([Measures].[part_income] / SUM(Filter([dim_company.dim_dealer].CurrentMember.Siblings, ([dim_company.dim_dealer].CurrentMember.Caption <> "失效")), [Measures].[part_income])), FORMAT_STRING = "0.0%" SET [~ROWS] AS     {{(ParallelPeriod([dim_ym].[months], 5, [dim_ym].[2018].[20184].[201810]) : ParallelPeriod([dim_ym].[months], 0, [dim_ym].[2018].[20184].[201810]))}} SELECT NON EMPTY CrossJoin([~COLUMNS], {[Measures].[配件收入占比]}) ON COLUMNS, NON EMPTY [~ROWS] ON ROWS FROM [ipsos_target] WHERE CrossJoin({[dim_company.dim_dealer].[中型], [dim_company.dim_dealer].[大型], [dim_company.dim_dealer].[小型]}, CrossJoin({Filter([dim_spart_catalog.dim_small_catalog].[part_catalog_name].members, (([dim_spart_catalog.dim_small_catalog].CurrentMember.Name MATCHES "常规配件") OR ([dim_spart_catalog.dim_small_catalog].CurrentMember.Caption MATCHES "常规配件")))}, [~dim_company_dim_company.dim_company_xq_name]))';
 	 	 	 	 	 	 	 	return mdx;
 	 	 	 	 	 	},


 	 	 	 	 	 	contentUpdate: function() {
 	 	 	 	 	 	 	 	if (isMdxMode) {
 	 	 	 	 	 	 	 	 	 	this._coder.getDoc().setValue(this.getSampleMDX());
 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	this._coder.getDoc().setValue(JSON.stringify(Utility.deepCopy(baseQuery), '\t', 8));
 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	return this;
 	 	 	 	 	 	},


 	 	 	 	 	 	init: function() {
 	 	 	 	 	 	 	 	this._coder = CodeMirror.fromTextArea(document.querySelector('.text-content'), {
 	 	 	 	 	 	 	 	 	 	theme: 'datafor',
 	 	 	 	 	 	 	 	 	 	tabSize: 8,
 	 	 	 	 	 	 	 	 	 	mode: isMdxMode ? "text/x-mdx" : "application/ld+json",
 	 	 	 	 	 	 	 	 	 	indentWithTabs: true,
 	 	 	 	 	 	 	 	 	 	cursorHeight: 1,
 	 	 	 	 	 	 	 	 	 	keyMap: "vim",
 	 	 	 	 	 	 	 	 	 	lineNumbers: true,
 	 	 	 	 	 	 	 	 	 	indentUnit: 8
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var sizey = $('.CodeMirror-vscrollbar>div').height();
 	 	 	 	 	 	 	 	var myself = this;
 	 	 	 	 	 	 	 	backQuery = Utility.deepCopy(baseQuery);
 	 	 	 	 	 	 	 	$('.viewmsg').click(function() {
 	 	 	 	 	 	 	 	 	 	Events.trigger('FUNCTION_EDITOR', {
 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	data: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	vim: true,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	callback: function() {},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	title: '当前数据源的指标和维度元数据',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	content: JSON.stringify(myself.metadata, '\t', 4)
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	this.selector = new Selector({
 	 	 	 	 	 	 	 	 	 	model: new Selector.Model({
 	 	 	 	 	 	 	 	 	 	 	 	multiple: false,
 	 	 	 	 	 	 	 	 	 	 	 	singleRequireSelected: true,
 	 	 	 	 	 	 	 	 	 	 	 	placeholder: '请选择数据源',
 	 	 	 	 	 	 	 	 	 	 	 	datasets: [{
 	 	 	 	 	 	 	 	 	 	 	 	 	 	id: 'a',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	text: 'A BDC',
 	 	 	 	 	 	 	 	 	 	 	 	 	 	disable: false,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	icon: ''
 	 	 	 	 	 	 	 	 	 	 	 	}],
 	 	 	 	 	 	 	 	 	 	 	 	updated: this.datasourceUpdate.bind(this)
 	 	 	 	 	 	 	 	 	 	})
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	var placeholders = [
 	 	 	 	 	 	 	 	 	 	"MDX模式，请先选择数据源，然后在这里输入MDX查询",
 	 	 	 	 	 	 	 	 	 	"QUERYMODEL模式，请先选择数据源，然后在这里修改查询"
 	 	 	 	 	 	 	 	];
 	 	 	 	 	 	 	 	this._coder.on('keyHandled', function(instance, name, event) {
 	 	 	 	 	 	 	 	 	 	if (window.event) {
 	 	 	 	 	 	 	 	 	 	 	 	event.cancelBubble = true;
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	event.stopPropagation();
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	$('.text-content').attr('placeholder', isMdxMode ? placeholders[0] : placeholders[1]);
 	 	 	 	 	 	 	 	$('.datasource>.list').append(this.selector.$el);
 	 	 	 	 	 	 	 	this.getDatasourcesList();
 	 	 	 	 	 	 	 	this.loader = new Loader({
 	 	 	 	 	 	 	 	 	 	container: this.selector.$el,
 	 	 	 	 	 	 	 	 	 	layout: 'absolute'
 	 	 	 	 	 	 	 	});

 	 	 	 	 	 	 	 	$('.btn.apply').on('click', function() {
 	 	 	 	 	 	 	 	 	 	var _baseQuery = Utility.deepCopy(baseQuery);
 	 	 	 	 	 	 	 	 	 	var value = myself._coder.getDoc().getValue();
 	 	 	 	 	 	 	 	 	 	var component = new Saiku();
 	 	 	 	 	 	 	 	 	 	var query = new Component();
 	 	 	 	 	 	 	 	 	 	var page = new Dashboard();
 	 	 	 	 	 	 	 	 	 	var element = $('.CodeMirror-scroll');
 	 	 	 	 	 	 	 	 	 	query.parent = page;
 	 	 	 	 	 	 	 	 	 	query.execute = component.execute.bind(query);
 	 	 	 	 	 	 	 	 	 	if (!isMdxMode) {
 	 	 	 	 	 	 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	var top = element.scrollTop();
 	 	 	 	 	 	 	 	 	 	 	 	 	 	value = JSON.parse(value);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	myself._coder.getDoc().setValue(JSON.stringify(value, '\t', 4));
 	 	 	 	 	 	 	 	 	 	 	 	 	 	element.scrollTop(top);
 	 	 	 	 	 	 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	Events.trigger('ERROR_LOG', {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	controls: {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	include: ['Alert']
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	data: "配置格式有误"
 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	$(this).blur();
 	 	 	 	 	 	 	 	 	 	Events.COMPONENT_QUERY_SUCCESS(query.id, 0, function(data) {
 	 	 	 	 	 	 	 	 	 	 	 	var datalist = new Array();
 	 	 	 	 	 	 	 	 	 	 	 	var raw = data.data;
 	 	 	 	 	 	 	 	 	 	 	 	var colModel = [];
 	 	 	 	 	 	 	 	 	 	 	 	if (!raw) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	//TODO
 	 	 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	raw.metadata.every(function(item) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	this.push({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	dataIndx: item.colName,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	name: item.colName,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	title: item.colName,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	type: item.colType.toLowerCase()
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}, colModel);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	if (colModel.length == 0) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	raw.resultset[0].every(function(v, ii) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	this.push({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	dataIndx: ii,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	name: ii,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	title: ''
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	}, colModel);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	raw.resultset.every(function(item, i) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	var node = {};
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	item.every(function(o, ii) {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	node[this[ii].dataIndx] = o.f ? o.f : o;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	}, this);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	datalist.push(node);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	return true;
 	 	 	 	 	 	 	 	 	 	 	 	 	 	}, colModel);
 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	//console.log(data.data);
 	 	 	 	 	 	 	 	 	 	 	 	settings.colModel = colModel;
 	 	 	 	 	 	 	 	 	 	 	 	settings.dataModel.data = datalist;
 	 	 	 	 	 	 	 	 	 	 	 	settings.numberCell = {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	show: true
 	 	 	 	 	 	 	 	 	 	 	 	};
 	 	 	 	 	 	 	 	 	 	 	 	settings.cellClick = function() {};
 	 	 	 	 	 	 	 	 	 	 	 	settings.refresh = function() {};
 	 	 	 	 	 	 	 	 	 	 	 	settings.headerCellClick = function() {};
 	 	 	 	 	 	 	 	 	 	 	 	settings.width = '100%';
 	 	 	 	 	 	 	 	 	 	 	 	settings.height = '100%';
 	 	 	 	 	 	 	 	 	 	 	 	//console.log(settings);
 	 	 	 	 	 	 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	$('.ctable>div').pqGrid('destroy');
 	 	 	 	 	 	 	 	 	 	 	 	} catch (e) {}
 	 	 	 	 	 	 	 	 	 	 	 	$('.data-content').show().find('.ctable').animate({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	height: 500
 	 	 	 	 	 	 	 	 	 	 	 	}, 200, function() {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	$('.ctable>div').pqGrid(settings);
 	 	 	 	 	 	 	 	 	 	 	 	 	 	Events.off_COMPONENT_QUERY_SUCCESS(query.id);
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	if (isMdxMode) {
 	 	 	 	 	 	 	 	 	 	 	 	_baseQuery.type = "MDX";
 	 	 	 	 	 	 	 	 	 	 	 	_baseQuery.mdx = value;
 	 	 	 	 	 	 	 	 	 	 	 	query.set({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	query: _baseQuery
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	} else {
 	 	 	 	 	 	 	 	 	 	 	 	query.set({
 	 	 	 	 	 	 	 	 	 	 	 	 	 	query: value
 	 	 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	query.execute();
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	$('.data-content').on('click', function(event) {
 	 	 	 	 	 	 	 	 	 	var target = $(event.target);
 	 	 	 	 	 	 	 	 	 	var ctable;
 	 	 	 	 	 	 	 	 	 	if (target.closest('.ctable').length) {
 	 	 	 	 	 	 	 	 	 	 	 	event.stopPropagation();
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	ctable = $(this).find('.ctable');
 	 	 	 	 	 	 	 	 	 	try {
 	 	 	 	 	 	 	 	 	 	 	 	ctable.pqGrid('destroy');
 	 	 	 	 	 	 	 	 	 	} catch (e) {
 	 	 	 	 	 	 	 	 	 	 	 	//TODO
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	ctable.animate({
 	 	 	 	 	 	 	 	 	 	 	 	height: 0
 	 	 	 	 	 	 	 	 	 	}, 200, function() {
 	 	 	 	 	 	 	 	 	 	 	 	target.hide();
 	 	 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	 	 	});
 	 	 	 	 	 	}
 	 	 	 	};

 	 	 	 	UI.init();

 	 	 	 	// if (isMdxMode) {
 	 	 	 	// 	_coder.getDoc().setValue(baseMDX);
 	 	 	 	// } else {
 	 	 	 	// 	_coder.getDoc().setValue(JSON.stringify(Utility.deepCopy(baseQuery), '\t', 8));
 	 	 	 	// }

 	 	})({
 	 	 	 	 	 	"cube": {
 	 	 	 	 	 	 	 	"uniqueName": "[SteelWheels].[SteelWheels].[SteelWheels].[SteelWheelsSales]",
 	 	 	 	 	 	 	 	"name": "SteelWheelsSales",
 	 	 	 	 	 	 	 	"connection": "SteelWheels",
 	 	 	 	 	 	 	 	"catalog": "SteelWheels",
 	 	 	 	 	 	 	 	"schema": "SteelWheels",
 	 	 	 	 	 	 	 	"caption": "SteelWheelsSales",
 	 	 	 	 	 	 	 	"visible": true
 	 	 	 	 	 	},
 	 	 	 	 	 	"queryModel": {
 	 	 	 	 	 	 	 	"axes": {
 	 	 	 	 	 	 	 	 	 	"FILTER": {
 	 	 	 	 	 	 	 	 	 	 	 	"mdx": null,
 	 	 	 	 	 	 	 	 	 	 	 	"filters": [],
 	 	 	 	 	 	 	 	 	 	 	 	"sortOrder": null,
 	 	 	 	 	 	 	 	 	 	 	 	"sortEvaluationLiteral": null,
 	 	 	 	 	 	 	 	 	 	 	 	"hierarchizeMode": null,
 	 	 	 	 	 	 	 	 	 	 	 	"location": "FILTER",
 	 	 	 	 	 	 	 	 	 	 	 	"hierarchies": [],
 	 	 	 	 	 	 	 	 	 	 	 	"nonEmpty": false
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	"COLUMNS": {
 	 	 	 	 	 	 	 	 	 	 	 	"mdx": null,
 	 	 	 	 	 	 	 	 	 	 	 	"filters": [],
 	 	 	 	 	 	 	 	 	 	 	 	"sortOrder": null,
 	 	 	 	 	 	 	 	 	 	 	 	"sortEvaluationLiteral": null,
 	 	 	 	 	 	 	 	 	 	 	 	"hierarchizeMode": null,
 	 	 	 	 	 	 	 	 	 	 	 	"location": "COLUMNS",
 	 	 	 	 	 	 	 	 	 	 	 	"hierarchies": [],
 	 	 	 	 	 	 	 	 	 	 	 	"nonEmpty": true
 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	"ROWS": {
 	 	 	 	 	 	 	 	 	 	 	 	"mdx": null,
 	 	 	 	 	 	 	 	 	 	 	 	"filters": [],
 	 	 	 	 	 	 	 	 	 	 	 	"sortOrder": null,
 	 	 	 	 	 	 	 	 	 	 	 	"sortEvaluationLiteral": null,
 	 	 	 	 	 	 	 	 	 	 	 	"hierarchizeMode": null,
 	 	 	 	 	 	 	 	 	 	 	 	"location": "ROWS",
 	 	 	 	 	 	 	 	 	 	 	 	"hierarchies": [{
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"name": "[Time]",
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"levels": {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"Years": {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"name": "Years",
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"caption": "Years",
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"mdx": null,
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"selection": {
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"type": "INCLUSION",
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"members": [],
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"parameterName": null
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"aggregators": [],
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	"filters": []
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"cmembers": {},
 	 	 	 	 	 	 	 	 	 	 	 	 	 	"filters": []
 	 	 	 	 	 	 	 	 	 	 	 	}],
 	 	 	 	 	 	 	 	 	 	 	 	"nonEmpty": true
 	 	 	 	 	 	 	 	 	 	}
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	"visualTotals": false,
 	 	 	 	 	 	 	 	"visualTotalsPattern": null,
 	 	 	 	 	 	 	 	"lowestLevelsOnly": false,
 	 	 	 	 	 	 	 	"details": {
 	 	 	 	 	 	 	 	 	 	"axis": "COLUMNS",
 	 	 	 	 	 	 	 	 	 	"location": "BOTTOM",
 	 	 	 	 	 	 	 	 	 	"measures": []
 	 	 	 	 	 	 	 	},
 	 	 	 	 	 	 	 	"calculatedMeasures": [],
 	 	 	 	 	 	 	 	"calculatedMembers": []
 	 	 	 	 	 	},
 	 	 	 	 	 	"queryType": "OLAP",
 	 	 	 	 	 	"properties": {
 	 	 	 	 	 	 	 	"saiku.olap.query.automatic_execution": true,
 	 	 	 	 	 	 	 	"saiku.olap.query.nonempty": true,
 	 	 	 	 	 	 	 	"saiku.olap.query.nonempty.rows": true,
 	 	 	 	 	 	 	 	"saiku.olap.query.nonempty.columns": true,
 	 	 	 	 	 	 	 	"saiku.ui.render.mode": "chart",
 	 	 	 	 	 	 	 	"saiku.ui.render.type": "table",
 	 	 	 	 	 	 	 	"saiku.olap.query.filter": true,
 	 	 	 	 	 	 	 	"saiku.olap.result.formatter": "flattened",
 	 	 	 	 	 	 	 	"org.saiku.query.explain": true,
 	 	 	 	 	 	 	 	"org.saiku.connection.scenario": false,
 	 	 	 	 	 	 	 	"saiku.olap.query.drillthrough": true,
 	 	 	 	 	 	 	 	"datafor.query.location": null
 	 	 	 	 	 	},
 	 	 	 	 	 	"parameters": {},
 	 	 	 	 	 	"plugins": {},
 	 	 	 	 	 	"mdx": null,
 	 	 	 	 	 	"name": "54655AFB-34A1-0B8E-80F0-284D4A45591B",
 	 	 	 	 	 	"metadata": {},
 	 	 	 	 	 	"type": "QUERYMODEL"
 	 	 	 	},
 	 	 	 	"WITH SET [~ROWS] AS {[Time].[Years].Members} SELECT NON EMPTY {[Measures].[Quantity]} ON COLUMNS, NON EMPTY [~ROWS] ON ROWS FROM [SteelWheelsSales]"
 	 	);
});